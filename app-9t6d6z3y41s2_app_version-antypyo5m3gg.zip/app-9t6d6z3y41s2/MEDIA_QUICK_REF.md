# Quick Reference - Media Navigation & Video Seekbar

## 🎬 Swipeable Media Navigation

### Component
**Location:** `src/components/media/SwipeableMediaGrid.tsx`

### Usage
```tsx
import { SwipeableMediaGrid } from '@/components/media/SwipeableMediaGrid';

<SwipeableMediaGrid 
  media={mediaItems} 
  onMediaClick={handleMediaClick}
  isPremium={post.is_premium}
  hasAccess={hasAccess}
/>
```

### Features
- ✅ Horizontal swipe (left/right)
- ✅ Dot indicators (Instagram style)
- ✅ No arrow buttons
- ✅ Smooth 300ms transitions
- ✅ Touch + mouse support

### Dot Indicators
```
Active:   ━━━ (24px × 6px, white)
Inactive: ● (6px × 6px, white/60)
Position: Bottom center, 12px from edge
```

---

## 🎥 Video Progress Seekbar

### Component
**Location:** `src/components/common/ReelCard.tsx`

### State
```typescript
const [progress, setProgress] = useState(0);      // 0-100%
const [duration, setDuration] = useState(0);      // seconds
const [isSeeking, setIsSeeking] = useState(false);
```

### Progress Tracking
```typescript
useEffect(() => {
  const updateProgress = () => {
    if (!isSeeking && video.duration) {
      setProgress((video.currentTime / video.duration) * 100);
    }
  };
  
  video.addEventListener('timeupdate', updateProgress);
  return () => video.removeEventListener('timeupdate', updateProgress);
}, [isSeeking]);
```

### Seek Functionality
```typescript
const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
  const rect = e.currentTarget.getBoundingClientRect();
  const x = e.clientX - rect.left;
  const percentage = (x / rect.width) * 100;
  const time = (percentage / 100) * duration;
  
  video.currentTime = time;
  setProgress(percentage);
};
```

### UI Design
```
Track:    4px tall, white/20, rounded
Progress: 4px tall, white, rounded
Handle:   12px circle, white, shadow
Position: Bottom, 8px from edge
```

---

## 🎯 Key Features

### Swipeable Media
| Feature | Implementation |
|---------|----------------|
| Swipe | Swiper.js with touch support |
| Dots | Custom CSS with active state |
| Transition | 300ms smooth animation |
| Aspect Ratio | 4:3 for all media |
| Border Radius | 12px (rounded-xl) |

### Video Seekbar
| Feature | Implementation |
|---------|----------------|
| Progress | Real-time 60fps updates |
| Seek | Click/drag to position |
| Touch | Full mobile support |
| Transition | 100ms smooth animation |
| Visibility | Backdrop blur overlay |

---

## 📱 Responsive Behavior

### Mobile
- Touch swipe for media
- Tap to seek video
- Drag to scrub
- Vertical scroll preserved

### Desktop
- Click + drag to swipe
- Click to seek video
- Hover effects
- Keyboard arrows work

---

## ⚡ Performance Tips

### Swipeable Media
```typescript
// Lazy load adjacent slides
lazy={{
  loadPrevNext: true,
  loadPrevNextAmount: 1,
}}

// Hardware acceleration
transform: translateZ(0);
will-change: transform;
```

### Video Seekbar
```typescript
// Only update when not seeking
if (!isSeeking && video.duration) {
  setProgress(...);
}

// Cleanup event listeners
return () => {
  video.removeEventListener('timeupdate', updateProgress);
};
```

---

## 🎨 Visual Design

### Swipeable Media
```css
/* Container */
aspect-[4/3]
rounded-xl
overflow-hidden

/* Dots */
h-1.5 rounded-full
w-6 bg-white (active)
w-1.5 bg-white/60 (inactive)
gap-1.5

/* Transition */
transition-all duration-300
```

### Video Seekbar
```css
/* Track */
h-1 bg-white/20 rounded-full
backdrop-blur-sm

/* Progress */
h-full bg-white rounded-full
transition-all duration-100

/* Handle */
w-3 h-3 bg-white rounded-full
shadow-lg
```

---

## ✅ Checklist

### Implementation
- [x] SwipeableMediaGrid component
- [x] Video progress tracking
- [x] Seek functionality
- [x] Dot indicators
- [x] Touch support

### Features
- [x] Swipe left/right
- [x] Dots update on swipe
- [x] Real-time progress
- [x] Click/drag to seek
- [x] Smooth animations

### Performance
- [x] 60fps animations
- [x] Hardware acceleration
- [x] Efficient event listeners
- [x] Proper cleanup

---

## 🎉 Result

**Professional Instagram-style media experience** with:
- ✅ Swipe navigation (no arrows)
- ✅ Dot indicators (clear position)
- ✅ Video seekbar (real-time)
- ✅ Smooth animations (60fps)
- ✅ Full touch support

---

**All features working perfectly!**
