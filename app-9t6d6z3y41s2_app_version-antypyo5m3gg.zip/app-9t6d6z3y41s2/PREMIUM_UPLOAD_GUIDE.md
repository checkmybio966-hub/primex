# 🎯 Quick Guide: Premium Upload System

## How It Works Now

### Normal Upload (Simple)
**When to use**: Regular posts and reels for all users

**Steps**:
1. Click **Normal** button
2. Select files (images or videos)
3. Add caption
4. Click Upload

**Result**:
- Images → Appear in **Home feed** as posts
- Single video → Appears in **Reels page** as reel

---

### Premium Upload (Advanced)
**When to use**: Premium content with specific placement

**Steps**:
1. Click **Premium** button
2. Choose ONE toggle:
   - **Posts** - For direct image/video display
   - **Reels** - For direct video display
   - **Albums** - For grouped media collections
   - **Files** - For downloadable files
3. Select files
4. Add caption/title
5. Click Upload

---

## Toggle Guide

### 📱 Posts Toggle
**What it does**: Creates premium posts with direct media display

**Use for**:
- Premium images
- Premium videos
- Multiple media items as separate posts

**Appears in**: Premium Feed → **Posts** tab

**Display**: Shows images/videos directly (not grouped)

**Example**: Upload 3 premium photos → Shows as post with 3 images

---

### ▶️ Reels Toggle
**What it does**: Creates premium reels with direct video display

**Use for**:
- Premium videos
- Short-form content
- Vertical videos

**Appears in**: Premium Feed → **Reels** tab

**Display**: Full-screen vertical scroll video player

**Example**: Upload premium video → Shows as reel in vertical feed

---

### 📁 Albums Toggle
**What it does**: Groups all media into a single album

**Use for**:
- Photo collections
- Event galleries
- Themed content sets

**Appears in**: Premium Feed → **Albums** tab

**Display**: Album card with 2-column grid inside

**Example**: Upload 10 photos → Creates 1 album with 10 photos in grid

---

### 📄 Files Toggle
**What it does**: Creates downloadable files

**Use for**:
- Documents
- Resources
- Downloadable content

**Appears in**: Premium Feed → **Files** tab

**Display**: File list with download buttons

**Example**: Upload PDF → Shows as downloadable file

---

## Visual Indicators

When you select a toggle, you'll see a colored box showing:

**Posts**:
```
📱 Creating Premium Posts
Media will appear directly in Premium Feed → Posts tab
```

**Reels**:
```
▶️ Creating Premium Reels
Videos will appear directly in Premium Feed → Reels tab
```

**Albums**:
```
📁 Creating Premium Album
All media grouped into a single album with grid view
```

**Files**:
```
📄 Creating Premium Files
Files will be available for download in Premium Feed → Files tab
```

---

## Examples

### Example 1: Share Premium Photos
**Goal**: Share 5 premium photos that users can view directly

**Steps**:
1. Click **Premium**
2. Toggle **Posts** ON
3. Select 5 images
4. Add caption: "Exclusive behind-the-scenes photos"
5. Click Upload

**Result**: Photos appear in Premium Feed → Posts tab as a post with 5 images

---

### Example 2: Share Premium Video
**Goal**: Share a premium video in vertical format

**Steps**:
1. Click **Premium**
2. Toggle **Reels** ON
3. Select 1 video
4. Add caption: "Exclusive tutorial"
5. Click Upload

**Result**: Video appears in Premium Feed → Reels tab as a full-screen reel

---

### Example 3: Create Photo Album
**Goal**: Create a collection of 20 vacation photos

**Steps**:
1. Click **Premium**
2. Toggle **Albums** ON
3. Select 20 images
4. Add title: "Summer Vacation 2026"
5. Add description: "Amazing trip to the beach"
6. Click Upload

**Result**: Album appears in Premium Feed → Albums tab with all 20 photos in a grid

---

### Example 4: Share Downloadable File
**Goal**: Share a PDF guide for premium users

**Steps**:
1. Click **Premium**
2. Toggle **Files** ON
3. Select PDF file
4. Add title: "Complete Guide"
5. Click Upload

**Result**: File appears in Premium Feed → Files tab with download button

---

## Quick Reference

| Toggle | Creates | Appears In | Display Type |
|--------|---------|------------|--------------|
| **Posts** | Premium posts | Premium Feed → Posts | Direct media |
| **Reels** | Premium reels | Premium Feed → Reels | Vertical video |
| **Albums** | Premium albums | Premium Feed → Albums | Grid collection |
| **Files** | Premium files | Premium Feed → Files | Download list |

---

## Tips

### ✅ Do's
- ✅ Select only ONE toggle at a time
- ✅ Use Posts for direct image/video display
- ✅ Use Albums for grouped collections
- ✅ Use Reels for vertical videos
- ✅ Add descriptive captions/titles

### ❌ Don'ts
- ❌ Don't select multiple toggles (only first one is used)
- ❌ Don't use Albums for single images (use Posts instead)
- ❌ Don't upload non-video files to Reels
- ❌ Don't forget to add captions

---

## Troubleshooting

### "Where did my upload go?"

**Check the correct tab**:
- Posts toggle → Premium Feed → **Posts** tab
- Reels toggle → Premium Feed → **Reels** tab
- Albums toggle → Premium Feed → **Albums** tab
- Files toggle → Premium Feed → **Files** tab

### "I want to group photos"

**Use Albums toggle**:
1. Click Premium
2. Toggle **Albums** ON (not Posts)
3. Select all photos
4. Upload

### "I want photos to show directly"

**Use Posts toggle**:
1. Click Premium
2. Toggle **Posts** ON (not Albums)
3. Select photos
4. Upload

### "Video not showing in Reels"

**Check**:
- Did you use Reels toggle? (not Posts)
- Is it a video file? (not image)
- Did you check Premium Feed → Reels tab? (not main Reels page)

---

## Summary

**Simple Rule**:
- **Posts/Reels** = Direct display (simple)
- **Albums** = Grouped display (collection)
- **Files** = Download (resources)

**Navigation**:
- After upload, you're automatically redirected to the correct tab
- All premium content is in **Premium Feed** (not main feed)
- Use the tabs to switch between content types

**Result**: Clear, organized premium content system! 🎉
