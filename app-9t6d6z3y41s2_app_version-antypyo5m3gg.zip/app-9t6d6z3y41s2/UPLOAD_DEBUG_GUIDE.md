# Premium Albums Upload Debug Guide - Critical Issue Fix

## Problem Description
Albums are being uploaded but NOT appearing anywhere in the app. This is a complete silent failure where:
- User selects multiple images (e.g., 4 files)
- Upload process appears to complete
- No crash or visible error
- But NO album is created and nothing appears in UI

## Root Cause Analysis

The issue could be at any of these points:
1. **Upload Failure** - Files not actually uploading
2. **URL Generation Failure** - Upload completes but URLs are empty
3. **Database Save Not Executing** - Upload completes but save never called
4. **Database Save Failing Silently** - Save called but fails without error
5. **Wrong Collection Path** - Saving to wrong location
6. **Fetch Not Working** - Data saved but not fetched
7. **UI Not Updating** - Data fetched but UI not rendering

## Fixes Implemented

### 1. Critical Validation Before Save ✅

**Added validation to prevent empty saves:**

```typescript
// CRITICAL VALIDATION: Ensure we have media items
if (!mediaItems || mediaItems.length === 0) {
  throw new Error('Cannot create album: No media URLs generated');
}

// CRITICAL VALIDATION: Ensure all URLs are valid
const invalidUrls = mediaItems.filter(item => !item.url || item.url.trim() === '');
if (invalidUrls.length > 0) {
  throw new Error(`Cannot create album: ${invalidUrls.length} media item(s) have invalid URLs`);
}
```

**Result**: Album creation will FAIL LOUDLY if media URLs are empty or invalid.

### 2. Comprehensive Logging ✅

**Added detailed logging at every step:**

```
[VALIDATION] ✓ Upload validation passed
[DATABASE] ═══════════════════════════════════════
[DATABASE] PREPARING TO SAVE ALBUM TO DATABASE
[DATABASE] ═══════════════════════════════════════
[DATABASE] Album details: {...}
[DATABASE] Collection: albums
[DATABASE] Calling api.createAlbum()...
[API] ═══════════════════════════════════════
[API] createAlbum() CALLED
[API] User authenticated: xxx
[API] Album data to insert: {...}
[API] Calling supabase.from("albums").insert()...
[API] Insert completed
[API] ✓✓✓ ALBUM CREATED SUCCESSFULLY ✓✓✓
[DATABASE] ✓✓✓ ALBUM SAVED SUCCESSFULLY ✓✓✓
[VERIFICATION] Fetching album back to confirm...
[VERIFICATION] ✓ Album confirmed in database
```

**Result**: Every step is logged with clear markers. Easy to identify where failure occurs.

### 3. Post-Save Verification ✅

**Added verification step after save:**

```typescript
// VERIFICATION: Fetch the album back to confirm it exists
const verifyAlbums = await api.getAlbums(false, 1, 0);
const savedAlbum = verifyAlbums.find(a => a.id === result.data?.id);
if (savedAlbum) {
  console.log('[VERIFICATION] ✓ Album confirmed in database');
} else {
  console.warn('[VERIFICATION] ⚠️ Album not found in immediate fetch');
}
```

**Result**: Confirms album was actually saved to database.

### 4. Test Album Function ✅

**Added debug function to create test album with dummy data:**

```typescript
const createTestAlbum = async () => {
  const testAlbum = {
    title: `Test Album - ${new Date().toLocaleTimeString()}`,
    description: 'This is a test album created with dummy data',
    media_items: [
      { url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4', type: 'image' },
      { url: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e', type: 'image' },
      { url: 'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d', type: 'image' }
    ],
    thumbnail_url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4',
    is_premium: true
  };

  const result = await api.createAlbum(testAlbum);
  // ... logging and navigation
};
```

**Result**: Can test database save without uploading files. If test album appears, problem is upload. If not, problem is fetch/UI.

### 5. Fetch All Albums Debug Function ✅

**Added function to fetch ALL albums without filter:**

```typescript
const fetchAllAlbumsDebug = async () => {
  const allAlbums = await api.getAlbums(false, 50, 0); // No premium filter
  
  console.log('[DEBUG] Total albums in database:', allAlbums.length);
  console.log('[DEBUG] Premium albums:', allAlbums.filter(a => a.is_premium).length);
  console.log('[DEBUG] Normal albums:', allAlbums.filter(a => !a.is_premium).length);
  
  setAlbums(allAlbums); // Show all albums
};
```

**Result**: Can see ALL albums in database, regardless of premium status. Helps identify if albums are saved but not fetched due to filter.

### 6. Enhanced API Logging ✅

**Added comprehensive logging in api.createAlbum():**

```typescript
console.log('[API] ═══════════════════════════════════════');
console.log('[API] createAlbum() CALLED');
console.log('[API] User authenticated:', user.id);
console.log('[API] Album data to insert:', {...});
console.log('[API] Calling supabase.from("albums").insert()...');
console.log('[API] Insert completed');
console.log('[API] Error:', error);
console.log('[API] Data:', data);

if (error) {
  console.error('[API] ❌ FAILED TO CREATE ALBUM');
  console.error('[API] Error code:', error.code);
  console.error('[API] Error message:', error.message);
  console.error('[API] Error details:', error.details);
  console.error('[API] Error hint:', error.hint);
  throw error;
}

console.log('[API] ✓✓✓ ALBUM CREATED SUCCESSFULLY ✓✓✓');
console.log('[API] Album ID:', data.id);
console.log('[API] Album Title:', data.title);
console.log('[API] Is Premium:', data.is_premium);
```

**Result**: Complete visibility into API function execution. Can see exact error if save fails.

### 7. Debug UI Components ✅

**Added debug button on Upload page (admin only):**
- Yellow "Create Test Album" button
- Creates album with dummy Unsplash images
- Bypasses file upload completely
- Tests database save and UI display

**Added debug panel on Premium Feed (admin only):**
- Shows count of posts, reels, albums, files
- Lists recent albums with details
- "Fetch All Albums" button to remove filter
- Debug tips and instructions

**Result**: Easy-to-use debug tools for troubleshooting.

## How to Debug

### Step 1: Check Console Logs

Open browser console (F12) and look for:

**Success Pattern:**
```
[VALIDATION] ✓ Upload validation passed
[DATABASE] PREPARING TO SAVE ALBUM TO DATABASE
[API] createAlbum() CALLED
[API] Insert completed
[API] ✓✓✓ ALBUM CREATED SUCCESSFULLY ✓✓✓
[VERIFICATION] ✓ Album confirmed in database
```

**Failure Patterns:**

**Upload Failure:**
```
[UPLOAD FAILED] File image.jpg: Network timeout
[VALIDATION] ✓ Upload validation passed: {successfully_uploaded: 0}
❌ Error: All file uploads failed
```
→ **Problem**: Files not uploading
→ **Fix**: Check network, file size, storage quota

**Empty URLs:**
```
[VALIDATION] ✓ Upload validation passed: {media_urls: []}
❌ Error: Cannot create album: No media URLs generated
```
→ **Problem**: Upload completes but URLs are empty
→ **Fix**: Check storage bucket, public URL generation

**Database Error:**
```
[API] Insert completed
[API] Error: {code: "42501", message: "permission denied"}
❌ Error: Failed to create album: permission denied
```
→ **Problem**: Database save failing
→ **Fix**: Check RLS policies, user authentication

**No Data Returned:**
```
[API] Insert completed
[API] Error: null
[API] Data: null
❌ Error: No data returned from insert
```
→ **Problem**: Insert succeeds but no data returned
→ **Fix**: Check .select('*').single() in API function

### Step 2: Use Test Album Function

1. Go to **Upload** page
2. Look for yellow **"Create Test Album"** button (admin only)
3. Click button
4. Check console logs
5. Check if album appears in Premium Feed → Albums

**If test album appears:**
→ Problem is in file upload process
→ Check upload logs, file validation, storage

**If test album does NOT appear:**
→ Problem is in fetch or UI rendering
→ Check fetch logs, RLS policies, UI state

### Step 3: Use Debug Panel

1. Go to **Premium Feed**
2. Click **"Debug"** button (admin only)
3. Check album count
4. Click **"Fetch All Albums"** button
5. Check console logs

**If "Fetch All Albums" shows albums:**
→ Albums are in database
→ Problem is premium filter
→ Check is_premium flag, RLS policies

**If "Fetch All Albums" shows 0 albums:**
→ No albums in database
→ Problem is upload or save
→ Go back to Step 1 and 2

### Step 4: Check Database Directly

Run SQL query in Supabase SQL Editor:

```sql
-- Check all albums
SELECT 
  id, 
  title, 
  is_premium, 
  jsonb_array_length(media_items) as media_count,
  created_at 
FROM albums 
ORDER BY created_at DESC 
LIMIT 10;
```

**If albums exist:**
→ Problem is fetch or RLS
→ Check RLS policies
→ Check user role

**If no albums:**
→ Problem is upload or save
→ Check console logs from Step 1

### Step 5: Check RLS Policies

Run SQL query:

```sql
SELECT 
  policyname, 
  cmd, 
  qual 
FROM pg_policies 
WHERE tablename = 'albums';
```

**Expected policy:**
```
"View albums based on premium status and user role"
cmd: SELECT
qual: (is_premium = false OR is_premium IS NULL) OR 
      (is_premium = true AND auth.uid() IN (...))
```

**If policy is different:**
→ RLS policy may be blocking access
→ Run fix migration (see below)

## Common Issues and Fixes

### Issue 1: All Uploads Fail

**Symptoms:**
```
[UPLOAD FAILED] File image.jpg: Network timeout
[VALIDATION] successfully_uploaded: 0
```

**Causes:**
- Network connection issues
- File too large
- Storage quota exceeded
- Wrong storage bucket

**Fixes:**
- Check internet connection
- Reduce file size (max 10MB images, 50MB videos)
- Check Supabase storage quota
- Verify bucket name is 'primex_images'

### Issue 2: Empty Media URLs

**Symptoms:**
```
[VALIDATION] media_urls: []
❌ Cannot create album: No media URLs generated
```

**Causes:**
- Upload succeeds but getPublicUrl() fails
- Storage bucket not public
- Wrong bucket name

**Fixes:**
```sql
-- Make bucket public
UPDATE storage.buckets 
SET public = true 
WHERE name = 'primex_images';
```

### Issue 3: Database Save Fails

**Symptoms:**
```
[API] Error: {code: "42501", message: "permission denied"}
```

**Causes:**
- RLS policy blocking INSERT
- User not authenticated
- Wrong user role

**Fixes:**
```sql
-- Check INSERT policy
SELECT * FROM pg_policies 
WHERE tablename = 'albums' 
AND cmd = 'INSERT';

-- Should allow admins to insert
CREATE POLICY "Admins can insert albums"
ON albums FOR INSERT
WITH CHECK (
  auth.uid() IN (
    SELECT id FROM profiles WHERE role = 'admin'
  )
);
```

### Issue 4: Albums Saved But Not Visible

**Symptoms:**
- Console shows "✓✓✓ ALBUM CREATED SUCCESSFULLY"
- Database query shows albums exist
- But UI shows "No Premium Albums Yet"

**Causes:**
- RLS policy blocking SELECT
- Premium filter too restrictive
- User role incorrect

**Fixes:**
1. Click "Fetch All Albums" in debug panel
2. Check if albums appear
3. If yes, problem is premium filter
4. Check user role:
```sql
SELECT id, username, role 
FROM profiles 
WHERE id = auth.uid();
```
5. If role is not 'admin' or 'premium_user', update:
```sql
UPDATE profiles 
SET role = 'admin' 
WHERE id = auth.uid();
```

### Issue 5: Real-Time Not Working

**Symptoms:**
- Album created successfully
- But doesn't appear until manual refresh

**Causes:**
- Real-time not enabled for albums table
- WebSocket connection failed

**Fixes:**
```sql
-- Enable real-time
ALTER PUBLICATION supabase_realtime ADD TABLE albums;
```

## Testing Checklist

### Test 1: Upload Real Files
- [ ] Select 4 images
- [ ] Turn ON Premium toggle
- [ ] Turn ON Albums toggle
- [ ] Click Upload
- [ ] Check console logs
- [ ] Verify success messages
- [ ] Check album appears in Premium Feed

### Test 2: Create Test Album
- [ ] Go to Upload page
- [ ] Click "Create Test Album" button
- [ ] Check console logs
- [ ] Verify album appears in Premium Feed
- [ ] Click album to view details

### Test 3: Debug Panel
- [ ] Go to Premium Feed
- [ ] Click "Debug" button
- [ ] Check album count
- [ ] Click "Fetch All Albums"
- [ ] Verify albums appear

### Test 4: Database Verification
- [ ] Run SQL query to check albums
- [ ] Verify albums exist with correct data
- [ ] Check is_premium flag
- [ ] Check media_items array

### Test 5: RLS Policies
- [ ] Run SQL query to check policies
- [ ] Verify SELECT policy exists
- [ ] Verify INSERT policy exists
- [ ] Test with different user roles

## Success Indicators

You'll know the issue is fixed when:

1. ✅ Console shows all success logs
2. ✅ No error messages in console
3. ✅ Album appears in Premium Feed immediately
4. ✅ Test album function works
5. ✅ Debug panel shows correct count
6. ✅ Database query shows albums
7. ✅ Real-time updates work
8. ✅ Album opens when clicked
9. ✅ All media displays correctly
10. ✅ No manual refresh needed

## Summary

The fixes implemented provide:

1. **Validation** - Prevents empty saves with clear error messages
2. **Logging** - Complete visibility into every step
3. **Verification** - Confirms album was saved
4. **Test Function** - Bypasses upload to test save/display
5. **Debug Tools** - Easy troubleshooting for admins
6. **Error Handling** - Fails loudly instead of silently

**Result**: No more silent failures. Every issue will be logged and visible, making it easy to identify and fix the root cause.
