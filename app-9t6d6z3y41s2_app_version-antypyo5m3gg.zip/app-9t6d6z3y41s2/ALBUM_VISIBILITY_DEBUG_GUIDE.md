# Premium Albums Visibility Fix - Debugging Guide

## Problem
Uploaded premium albums were not appearing in the Premium Albums section even though uploads completed successfully.

## Root Causes Fixed

### 1. API Response Not Checked
**Issue**: The `createAlbum` function wasn't returning the created data or checking for errors properly.

**Before:**
```typescript
return supabase.from('albums').insert({...album, user_id: user.id});
```

**After:**
```typescript
const { data, error } = await supabase.from('albums')
  .insert({...album, user_id: user.id})
  .select('*')
  .single();

if (error) throw error;
return { data, error: null };
```

### 2. No Real-Time Updates
**Issue**: The Premium Feed page wasn't listening for database changes.

**Fix**: Added Supabase real-time subscription:
```typescript
const albumsChannel = api.supabase
  .channel('albums-changes')
  .on('postgres_changes', {
    event: '*',
    schema: 'public',
    table: 'albums',
  }, () => {
    fetchPremiumContent(); // Refresh when changes occur
  })
  .subscribe();
```

### 3. Insufficient Logging
**Issue**: No way to debug what was happening during upload and fetch.

**Fix**: Added comprehensive logging:
- `[API]` - API function calls and responses
- `[DATABASE]` - Database operations
- `[FETCH]` - Data fetching operations
- `[REALTIME]` - Real-time subscription events
- `[RENDER]` - Component rendering

### 4. No Manual Refresh Option
**Issue**: Users couldn't manually refresh to see new albums.

**Fix**: Added refresh button to Premium Feed page.

## How to Debug Album Visibility Issues

### Step 1: Check Upload Logs
After uploading an album, check the browser console for:

```
[DATABASE] Creating album with details: {
  title: "Premium Album - 1/1/2026",
  description: null,
  media_items_count: 5,
  is_premium: true,
  thumbnail_url: "https://..."
}
[DATABASE] ✓ Album created successfully: {
  id: "abc-123-def",
  title: "Premium Album - 1/1/2026",
  is_premium: true,
  media_count: 5
}
```

**What to look for:**
- ✅ `is_premium: true` - Confirms premium flag is set
- ✅ Album ID is generated
- ✅ Media items are included
- ❌ Any error messages

### Step 2: Check Fetch Logs
Navigate to Premium Feed → Albums tab and check console:

```
[API] Fetching albums - premiumOnly: true, limit: 20, offset: 0
[API] ✓ Fetched 3 albums {
  premiumOnly: true,
  albums: [
    { id: "abc-123", title: "Album 1", is_premium: true, media_count: 5 },
    { id: "def-456", title: "Album 2", is_premium: true, media_count: 3 },
    { id: "ghi-789", title: "Album 3", is_premium: true, media_count: 8 }
  ]
}
```

**What to look for:**
- ✅ `premiumOnly: true` - Confirms filter is applied
- ✅ Albums array contains your new album
- ✅ Each album has `is_premium: true`
- ❌ Empty array or missing album

### Step 3: Check Real-Time Subscription
After upload, you should see:

```
[REALTIME] Albums change detected: {
  eventType: "INSERT",
  new: { id: "abc-123", title: "...", is_premium: true, ... }
}
[FETCH] Fetching premium content...
[API] Fetching albums - premiumOnly: true, limit: 20, offset: 0
```

**What to look for:**
- ✅ Real-time event fires after upload
- ✅ Automatic refresh is triggered
- ❌ No real-time event (subscription issue)

### Step 4: Check Render Logs
When albums are displayed:

```
[RENDER] Rendering album card: {
  id: "abc-123",
  title: "Premium Album - 1/1/2026",
  is_premium: true,
  media_count: 5
}
```

**What to look for:**
- ✅ Album is being rendered
- ✅ All data is present
- ❌ Album not in render logs (state issue)

## Common Issues and Solutions

### Issue 1: Album Created but Not Fetched
**Symptoms:**
- Upload logs show success
- Fetch logs show empty array or missing album

**Possible Causes:**
1. **RLS Policy Issue**: Album policies might be blocking access
2. **Premium Flag Mismatch**: `is_premium` might be false instead of true
3. **User Not Premium**: Fetch requires premium access

**Solution:**
```sql
-- Check if album exists in database
SELECT id, title, is_premium, user_id, created_at 
FROM albums 
WHERE title LIKE '%Premium Album%' 
ORDER BY created_at DESC 
LIMIT 5;

-- Check RLS policies
SELECT * FROM albums WHERE is_premium = true;
```

### Issue 2: Album Fetched but Not Rendered
**Symptoms:**
- Fetch logs show album in array
- No render logs for the album

**Possible Causes:**
1. **State Not Updated**: React state not updating
2. **Key Conflict**: Duplicate keys in list
3. **Conditional Rendering**: Component hidden by condition

**Solution:**
- Check React DevTools for state
- Verify unique keys in map function
- Check conditional rendering logic

### Issue 3: Real-Time Not Working
**Symptoms:**
- No `[REALTIME]` logs after upload
- Manual refresh shows album

**Possible Causes:**
1. **Subscription Not Active**: Channel not subscribed
2. **Table Not Enabled**: Real-time not enabled for albums table
3. **Network Issue**: WebSocket connection failed

**Solution:**
```sql
-- Enable real-time for albums table
ALTER PUBLICATION supabase_realtime ADD TABLE albums;
```

### Issue 4: Upload Succeeds but is_premium is False
**Symptoms:**
- Upload logs show `is_premium: false`
- Album appears in non-premium section

**Possible Causes:**
1. **Toggle Not Set**: Premium toggle not enabled during upload
2. **Wrong Upload Type**: Using "Normal" instead of "Premium"
3. **Category Not Selected**: Albums category not toggled on

**Solution:**
- Verify Premium upload type is selected
- Ensure Albums toggle is ON
- Check `isPremium` variable in upload logs

## Testing Checklist

### Before Upload
- [ ] Premium upload type selected
- [ ] Albums toggle is ON
- [ ] Files selected (at least 1)
- [ ] Browser console open

### During Upload
- [ ] Check `[DATABASE] Creating album` log
- [ ] Verify `is_premium: true` in log
- [ ] Wait for success message
- [ ] Check `[DATABASE] ✓ Album created` log

### After Upload
- [ ] Navigate to Premium Feed → Albums tab
- [ ] Check `[FETCH]` logs
- [ ] Check `[REALTIME]` logs
- [ ] Verify album appears in list
- [ ] Click album to verify it opens
- [ ] Check album detail page loads correctly

### If Album Not Visible
- [ ] Click "Refresh" button
- [ ] Check console for errors
- [ ] Verify user has premium access
- [ ] Check database directly (SQL query)
- [ ] Review all console logs

## Manual Database Verification

If albums still don't appear, check the database directly:

```sql
-- Get all albums with details
SELECT 
  id,
  title,
  is_premium,
  jsonb_array_length(media_items) as media_count,
  user_id,
  created_at
FROM albums
ORDER BY created_at DESC
LIMIT 10;

-- Get only premium albums
SELECT 
  id,
  title,
  is_premium,
  jsonb_array_length(media_items) as media_count
FROM albums
WHERE is_premium = true
ORDER BY created_at DESC;

-- Check if specific album exists
SELECT * FROM albums WHERE title LIKE '%Premium Album%';
```

## Quick Fix Steps

If albums are not appearing:

1. **Immediate Fix**: Click the "Refresh" button on Premium Feed page
2. **Check Console**: Look for any error messages
3. **Verify Upload**: Check `[DATABASE]` logs for successful creation
4. **Verify Fetch**: Check `[API]` logs for correct filtering
5. **Check Access**: Ensure user has premium or admin role
6. **Database Check**: Run SQL query to verify album exists
7. **Clear Cache**: Hard refresh browser (Ctrl+Shift+R)
8. **Re-upload**: Try uploading again with logging enabled

## Success Indicators

You'll know everything is working when you see:

1. ✅ Upload completes with success message
2. ✅ `[DATABASE] ✓ Album created successfully` in console
3. ✅ `is_premium: true` in creation log
4. ✅ `[REALTIME] Albums change detected` after upload
5. ✅ Album appears in Premium Feed → Albums tab
6. ✅ Album count shows correct number
7. ✅ Clicking album opens detail page
8. ✅ All media displays in 2-column grid

## Support

If issues persist after following this guide:

1. Export console logs (right-click → Save as...)
2. Take screenshots of:
   - Upload page with toggles
   - Premium Feed Albums tab
   - Browser console logs
3. Run database queries and save results
4. Check Supabase dashboard for:
   - Albums table data
   - RLS policies
   - Real-time settings
