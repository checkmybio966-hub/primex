# Primex Payment Flow - Visual Guide

## 🔄 Complete User Journey

```
┌─────────────────────────────────────────────────────────────────┐
│                     LOGIN PAGE                                   │
│                                                                  │
│  ┌────────────────────────────────────────────────────────┐    │
│  │  🔒 Sign In                                             │    │
│  │                                                         │    │
│  │  Username: [________________]                          │    │
│  │                                                         │    │
│  │  Password: [________________] 👁                       │    │
│  │            ← Password Toggle                           │    │
│  │                                                         │    │
│  │  [Sign In]                                             │    │
│  └────────────────────────────────────────────────────────┘    │
│                                                                  │
│  Choose Your Plan                                               │
│                                                                  │
│  ┌────────────────────────────────────────────────────────┐    │
│  │  ✨ Premium Plan ✨              ₹299 INR              │    │
│  │                                  [Get Access] ──────┐   │    │
│  └────────────────────────────────────────────────────────┘    │
│                                                          │       │
│  ┌────────────────────────────────────────────────────────┐    │
│  │  💎 Exclusive Plan 💎            Premium Content      │    │
│  │                                  [Get Access] ──────┐ │    │
│  └────────────────────────────────────────────────────────┘    │
│                                                          │ │     │
└──────────────────────────────────────────────────────────┼─┼────┘
                                                           │ │
                                                           ▼ ▼
┌─────────────────────────────────────────────────────────────────┐
│                   QR PAYMENT PAGE                                │
│                                                                  │
│  ← Back                                                          │
│                                                                  │
│  ┌────────────────────────────────────────────────────────┐    │
│  │                                                         │    │
│  │              ✨ Premium Plan                           │    │
│  │                                                         │    │
│  │  ┌─────────────────────────────────────────────┐      │    │
│  │  │  Payment for: @username                     │      │    │
│  │  └─────────────────────────────────────────────┘      │    │
│  │                                                         │    │
│  │              Amount: ₹299 INR                          │    │
│  │                                                         │    │
│  │  ┌─────────────────────────────────────────────┐      │    │
│  │  │                                             │      │    │
│  │  │          ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓                 │      │    │
│  │  │          ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓                 │      │    │
│  │  │          ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓                 │      │    │
│  │  │          ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓                 │      │    │
│  │  │          ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓                 │      │    │
│  │  │             QR CODE                         │      │    │
│  │  │                                             │      │    │
│  │  └─────────────────────────────────────────────┘      │    │
│  │                                                         │    │
│  │  ┌─────────────────────────────────────────────┐      │    │
│  │  │  Scan QR code with your payment app        │      │    │
│  │  │  and complete the payment                   │      │    │
│  │  └─────────────────────────────────────────────┘      │    │
│  │                                                         │    │
│  │              [✓ Pay Now]                               │    │
│  │                   │                                     │    │
│  └───────────────────┼─────────────────────────────────────┘    │
│                      │                                          │
└──────────────────────┼──────────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────────┐
│                   SUCCESS TOAST                                  │
│                                                                  │
│  ┌────────────────────────────────────────────────────────┐    │
│  │  ✓ Payment successfully completed,                     │    │
│  │    waiting for access                                  │    │
│  └────────────────────────────────────────────────────────┘    │
│                                                                  │
│                      ↓                                           │
│                                                                  │
│              Navigate back to LOGIN PAGE                         │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🎬 Reels Delete Feature

```
┌─────────────────────────────────────────────────────────────────┐
│                     REELS PAGE                                   │
│                                                                  │
│  ┌────────────────────────────────────────────────────────┐    │
│  │  ← Back                              🗑️ ← Admin Only   │    │
│  │                                      Delete Button      │    │
│  │                                                         │    │
│  │                                                         │    │
│  │                                                         │    │
│  │                  VIDEO CONTENT                         │    │
│  │                                                         │    │
│  │                                                         │    │
│  │                                                         │    │
│  │  @username                                    ❤️ 123   │    │
│  │  Caption text here...                        💬 45     │    │
│  │                                              👁️ 1.2K   │    │
│  │                                                         │    │
│  └────────────────────────────────────────────────────────┘    │
│                                                                  │
│  Admin clicks 🗑️                                                │
│         ↓                                                        │
│  Instant deletion (no confirmation)                             │
│         ↓                                                        │
│  Toast: "Reel deleted successfully"                             │
│         ↓                                                        │
│  UI updates immediately (reel disappears)                       │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔐 Password Toggle Feature

```
┌─────────────────────────────────────────────────────────────────┐
│                   PASSWORD FIELD                                 │
│                                                                  │
│  HIDDEN STATE (default):                                         │
│  ┌────────────────────────────────────────────────────────┐    │
│  │  Password: [••••••••••••••••] 👁️                       │    │
│  └────────────────────────────────────────────────────────┘    │
│                                                                  │
│  User clicks 👁️ (Eye icon)                                      │
│         ↓                                                        │
│                                                                  │
│  VISIBLE STATE:                                                  │
│  ┌────────────────────────────────────────────────────────┐    │
│  │  Password: [password123] 👁️‍🗨️                          │    │
│  └────────────────────────────────────────────────────────┘    │
│                                                                  │
│  User clicks 👁️‍🗨️ (EyeOff icon)                                │
│         ↓                                                        │
│                                                                  │
│  Back to HIDDEN STATE                                            │
└─────────────────────────────────────────────────────────────────┘
```

---

## 💳 Plans Comparison

```
┌─────────────────────────────────────────────────────────────────┐
│                   PLANS SECTION                                  │
│                                                                  │
│  ┌────────────────────────────────────────────────────────┐    │
│  │  ✨  Premium Plan ✨                                    │    │
│  │                                                         │    │
│  │  Features:                                              │    │
│  │  • Unlimited posts                                      │    │
│  │  • Upload reels                                         │    │
│  │  • Access premium features                              │    │
│  │  • No restrictions                                      │    │
│  │                                                         │    │
│  │  Price: ₹299 INR                    [Get Access]       │    │
│  └────────────────────────────────────────────────────────┘    │
│                                                                  │
│  ┌────────────────────────────────────────────────────────┐    │
│  │  💎  Exclusive Plan 💎                                  │    │
│  │                                                         │    │
│  │  Features:                                              │    │
│  │  • All Premium features                                 │    │
│  │  • Exclusive content access                             │    │
│  │  • Priority support                                     │    │
│  │  • Special badge                                        │    │
│  │                                                         │    │
│  │  Premium Content                    [Get Access]       │    │
│  └────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🎨 UI Components Breakdown

### Delete Button (Admin Only)
```
┌──────────────┐
│      🗑️      │  ← Circular button
│              │     40px diameter
└──────────────┘     Red background
                     White icon
                     Top-right position
                     Backdrop blur
```

### Password Toggle
```
┌─────────────────────────────┐
│ Password: [••••••] 👁️       │  ← Eye icon
└─────────────────────────────┘     Right side
                                    20px icon
                                    Muted color
                                    Hover effect
```

### Plan Card
```
┌─────────────────────────────────────┐
│  ┌──┐                               │
│  │✨│  Premium Plan ✨               │  ← Icon + Name
│  └──┘                               │
│       ₹299 INR                      │  ← Price
│                                     │
│                    [Get Access]    │  ← Button
└─────────────────────────────────────┘
     Gradient background
     Rounded corners (16px)
     Hover shadow effect
```

### QR Payment Card
```
┌─────────────────────────────────────┐
│         ✨ Premium Plan              │  ← Header
│                                     │
│  ┌─────────────────────────────┐   │
│  │  Payment for: @username     │   │  ← User info
│  └─────────────────────────────┘   │
│                                     │
│         Amount: ₹299 INR            │  ← Price
│                                     │
│  ┌─────────────────────────────┐   │
│  │                             │   │
│  │       QR CODE IMAGE         │   │  ← QR Code
│  │       256x256px             │   │
│  │                             │   │
│  └─────────────────────────────┘   │
│                                     │
│  ┌─────────────────────────────┐   │
│  │  Payment Instructions       │   │  ← Instructions
│  └─────────────────────────────┘   │
│                                     │
│         [✓ Pay Now]                 │  ← Action button
└─────────────────────────────────────┘
```

---

## 📱 Responsive Behavior

### Mobile View (< 768px)
```
┌─────────────────┐
│   LOGIN PAGE    │
│                 │
│  [Username]     │
│  [Password] 👁️  │
│  [Sign In]      │
│                 │
│  Plans:         │
│  ┌───────────┐  │
│  │ Premium   │  │
│  │ ₹299      │  │
│  │ [Access]  │  │
│  └───────────┘  │
│  ┌───────────┐  │
│  │ Exclusive │  │
│  │ [Access]  │  │
│  └───────────┘  │
└─────────────────┘
```

### Desktop View (> 768px)
```
┌─────────────────────────────────┐
│        LOGIN PAGE               │
│                                 │
│  ┌─────────────────────────┐   │
│  │  Username: [_________]  │   │
│  │  Password: [_________]👁️│   │
│  │  [Sign In]              │   │
│  └─────────────────────────┘   │
│                                 │
│  Choose Your Plan               │
│  ┌─────────────────────────┐   │
│  │ ✨ Premium  ₹299 [Access]│   │
│  └─────────────────────────┘   │
│  ┌─────────────────────────┐   │
│  │ 💎 Exclusive    [Access]│   │
│  └─────────────────────────┘   │
└─────────────────────────────────┘
```

---

## 🔄 State Management

### Password Toggle State
```typescript
const [showPassword, setShowPassword] = useState(false);

// Toggle function
const togglePassword = () => setShowPassword(!showPassword);

// Input type
type={showPassword ? "text" : "password"}

// Icon
{showPassword ? <EyeOff /> : <Eye />}
```

### Delete Reel State
```typescript
const [reels, setReels] = useState<Post[]>([]);

// Delete function
const handleDelete = async (reelId: string) => {
  await api.deletePost(reelId);
  setReels(prev => prev.filter(r => r.id !== reelId));
};

// Instant UI update (no refetch needed)
```

### Payment Flow State
```typescript
// Navigate with state
navigate('/qr-payment', { 
  state: { 
    plan: 'premium', 
    price: 299 
  } 
});

// Access state in QR page
const { plan, price } = location.state;
```

---

## ✅ Testing Checklist

### Admin Delete Feature
- [ ] Admin sees delete button on all reels
- [ ] Non-admin does not see delete button
- [ ] Click delete removes reel instantly
- [ ] Toast shows "Reel deleted successfully"
- [ ] UI updates without page refresh
- [ ] Works on both normal and premium reels

### Password Toggle
- [ ] Eye icon visible on password field
- [ ] Click eye shows password text
- [ ] Icon changes to EyeOff when visible
- [ ] Click EyeOff hides password again
- [ ] Smooth transition between states

### Plans Section
- [ ] Premium plan shows ₹299 INR
- [ ] Exclusive plan shows "Premium Content"
- [ ] Both cards have "Get Access" button
- [ ] Click navigates to QR payment page
- [ ] Correct plan data passed in state

### QR Payment Page
- [ ] Username displays correctly
- [ ] Plan name and icon show correctly
- [ ] Price displays (₹299 for Premium)
- [ ] QR code image loads
- [ ] Payment instructions display
- [ ] "Pay Now" button works
- [ ] Success toast appears
- [ ] Navigates back to login

---

**Visual Guide Complete** ✅  
**All Features Documented** ✅  
**Ready for Implementation** ✅
