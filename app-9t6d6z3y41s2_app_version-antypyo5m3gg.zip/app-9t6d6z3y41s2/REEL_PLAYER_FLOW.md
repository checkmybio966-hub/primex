# Premium Reel Player - Visual Flow Diagram

## 🎬 User Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    PREMIUM FEED PAGE                        │
│                                                             │
│  ┌────────┐  ┌────────┐  ┌────────┐  ┌────────┐          │
│  │ Reel 1 │  │ Reel 2 │  │ Reel 3 │  │ Reel 4 │          │
│  │  🔒    │  │        │  │  🔒    │  │        │          │
│  │ [Thumb]│  │ [Thumb]│  │ [Thumb]│  │ [Thumb]│          │
│  └────────┘  └────────┘  └────────┘  └────────┘          │
│                                                             │
│  ┌────────┐  ┌────────┐  ┌────────┐  ┌────────┐          │
│  │ Reel 5 │  │ Reel 6 │  │ Reel 7 │  │ Reel 8 │          │
│  │        │  │  🔒    │  │        │  │  🔒    │          │
│  │ [Thumb]│  │ [Thumb]│  │ [Thumb]│  │ [Thumb]│          │
│  └────────┘  └────────┘  └────────┘  └────────┘          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
                            │
                            │ User clicks Reel 3
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                   PREMIUM CHECK                             │
│                                                             │
│         Is reel premium?                                    │
│                │                                            │
│         ┌──────┴──────┐                                     │
│         │             │                                     │
│        YES           NO                                     │
│         │             │                                     │
│         ↓             ↓                                     │
│   Is user premium?   Play video                            │
│         │                                                   │
│    ┌────┴────┐                                              │
│   YES       NO                                              │
│    │         │                                              │
│    ↓         ↓                                              │
│  Play    Show Lock                                          │
│  Video   Screen                                             │
│                                                             │
└─────────────────────────────────────────────────────────────┘
                            │
                            ↓
```

---

## 🎯 Component Interaction

```
┌─────────────────────────────────────────────────────────────┐
│                  PremiumReelCard                            │
│  ┌───────────────────────────────────────────────────────┐ │
│  │                                                       │ │
│  │  State: { isPlayerOpen: false, isHovered: false }    │ │
│  │                                                       │ │
│  │  ┌─────────────────────────────────────────────┐    │ │
│  │  │         Thumbnail Image                     │    │ │
│  │  │                                             │    │ │
│  │  │  onMouseEnter → setIsHovered(true)          │    │ │
│  │  │                 + Preload video             │    │ │
│  │  │                                             │    │ │
│  │  │  onClick → setIsPlayerOpen(true)            │    │ │
│  │  │                                             │    │ │
│  │  └─────────────────────────────────────────────┘    │ │
│  │                                                       │ │
│  └───────────────────────────────────────────────────────┘ │
│                            │                                │
│                            │ isPlayerOpen = true            │
│                            ↓                                │
│  ┌───────────────────────────────────────────────────────┐ │
│  │          FullscreenReelPlayer                         │ │
│  │  ┌─────────────────────────────────────────────────┐ │ │
│  │  │                                                 │ │ │
│  │  │  useEffect(() => {                              │ │ │
│  │  │    if (isOpen) {                                │ │ │
│  │  │      1. Request fullscreen                      │ │ │
│  │  │      2. Autoplay video                          │ │ │
│  │  │      3. Show loading state                      │ │ │
│  │  │    }                                            │ │ │
│  │  │  }, [isOpen])                                   │ │ │
│  │  │                                                 │ │ │
│  │  │  [X] Close                              #3      │ │ │
│  │  │                                                 │ │ │
│  │  │         [Video Playing]                         │ │ │
│  │  │                                                 │ │ │
│  │  │  👤 Username  🔒 Premium                       │ │ │
│  │  │  Caption text here...                          │ │ │
│  │  │                                                 │ │ │
│  │  └─────────────────────────────────────────────────┘ │ │
│  │                                                       │ │
│  │  onClose → setIsPlayerOpen(false)                    │ │
│  │            + Exit fullscreen                          │ │
│  │            + Pause video                              │ │
│  │                                                       │ │
│  └───────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔐 Premium Access Flow

### Scenario 1: Premium User Clicks Premium Reel
```
User clicks reel
      ↓
Check: hasAccess = !reel.is_premium || isPremium || isAdmin
      ↓
Result: true (isPremium = true)
      ↓
Open fullscreen player
      ↓
Request fullscreen
      ↓
Show thumbnail (loading state)
      ↓
Autoplay video
      ↓
Video plays successfully
      ↓
User watches reel
```

### Scenario 2: Regular User Clicks Premium Reel
```
User clicks reel
      ↓
Check: hasAccess = !reel.is_premium || isPremium || isAdmin
      ↓
Result: false (isPremium = false, reel.is_premium = true)
      ↓
Open fullscreen player
      ↓
Request fullscreen
      ↓
Show lock screen overlay
      ↓
Display:
  - Lock icon
  - "Premium Content" title
  - "Upgrade to Premium" message
  - [Upgrade to Premium] button
  - [Close] link
      ↓
User clicks "Upgrade to Premium"
      ↓
Navigate to /premium
      ↓
Close player
```

### Scenario 3: Any User Clicks Normal Reel
```
User clicks reel
      ↓
Check: hasAccess = !reel.is_premium || isPremium || isAdmin
      ↓
Result: true (reel.is_premium = false)
      ↓
Open fullscreen player
      ↓
Request fullscreen
      ↓
Show thumbnail (loading state)
      ↓
Autoplay video
      ↓
Video plays successfully
      ↓
User watches reel
```

---

## ⚡ Performance Flow

### Video Preloading
```
User hovers over card
      ↓
onMouseEnter triggered
      ↓
setIsHovered(true)
      ↓
Call onPreload()
      ↓
Create video element
      ↓
Set video.src = reel.media_url
      ↓
Set video.preload = 'metadata'
      ↓
Browser preloads video metadata
      ↓
User clicks card
      ↓
Video starts playing faster (100ms vs 500ms)
```

### Loading States
```
Player opens
      ↓
isLoading = true
      ↓
Show:
  - Spinner (center)
  - Thumbnail (background)
      ↓
Video element created
      ↓
video.src = reel.media_url
video.poster = reel.thumbnail_url
      ↓
Video starts loading
      ↓
onLoadedData event fires
      ↓
setIsLoading(false)
      ↓
Hide spinner
      ↓
Video plays
```

---

## 🎨 State Transitions

### Card States
```
IDLE
  │
  │ onMouseEnter
  ↓
HOVERED
  │ - Scale: 1.0 → 1.02
  │ - Play button: opacity 0 → 1
  │ - Border: transparent → primary
  │ - Preload video
  │
  │ onMouseLeave
  ↓
IDLE
  │
  │ onClick
  ↓
OPENING
  │ - Fade out card
  │ - Open player
  │
  ↓
PLAYER_OPEN
```

### Player States
```
CLOSED
  │
  │ isOpen = true
  ↓
OPENING
  │ - Request fullscreen
  │ - Fade in (300ms)
  │
  ↓
LOADING
  │ - Show spinner
  │ - Show thumbnail
  │ - Load video
  │
  ↓
PLAYING
  │ - Hide spinner
  │ - Play video
  │ - Show controls
  │
  │ User clicks close / ESC / Exit fullscreen
  ↓
CLOSING
  │ - Pause video
  │ - Exit fullscreen
  │ - Fade out (300ms)
  │
  ↓
CLOSED
```

---

## 🎯 Event Flow

### Click Event
```
User clicks card
      ↓
PremiumReelCard.handleClick()
      ↓
setIsPlayerOpen(true)
      ↓
FullscreenReelPlayer renders
      ↓
useEffect (isOpen changed)
      ↓
Request fullscreen
      ↓
Autoplay video
```

### Close Event
```
User presses ESC
      ↓
FullscreenReelPlayer.handleEscape()
      ↓
onClose()
      ↓
PremiumReelCard.setIsPlayerOpen(false)
      ↓
FullscreenReelPlayer unmounts
      ↓
useEffect cleanup
      ↓
Pause video
      ↓
Exit fullscreen
```

### Fullscreen Exit Event
```
User exits fullscreen (browser button)
      ↓
fullscreenchange event
      ↓
FullscreenReelPlayer.handleFullscreenChange()
      ↓
Check: document.fullscreenElement === null
      ↓
onClose()
      ↓
Player closes
```

---

## 📊 Data Flow

### Props Passing
```
PremiumFeedPage
      ↓
reels.map((reel, index) => (
      ↓
  <PremiumReelCard
    reel={reel}           ← Post data
    position={index}      ← Position in grid
    onPreload={...}       ← Preload callback
  />
      ↓
  <FullscreenReelPlayer
    reel={reel}           ← Same Post data
    isOpen={isPlayerOpen} ← State from card
    onClose={...}         ← Close callback
    position={position}   ← Same position
  />
))
```

### State Management
```
PremiumReelCard
  ├─ isPlayerOpen: boolean
  │    ↓ Controls player visibility
  │    ↓ Passed to FullscreenReelPlayer
  │
  └─ isHovered: boolean
       ↓ Controls hover effects
       ↓ Triggers preload
```

```
FullscreenReelPlayer
  ├─ muted: boolean
  │    ↓ Controls audio
  │    ↓ Toggled on tap
  │
  ├─ isLoading: boolean
  │    ↓ Controls loading UI
  │    ↓ Set false on video load
  │
  └─ showVolumeIcon: boolean
       ↓ Controls volume icon visibility
       ↓ Shows for 1 second on toggle
```

---

## 🎉 Complete Flow Example

```
1. User opens Premium Feed
   ↓
2. Grid of PremiumReelCards renders
   ↓
3. User hovers over Reel #3
   ↓
4. Card scales up, play button appears
   ↓
5. Video metadata preloads
   ↓
6. User clicks card
   ↓
7. FullscreenReelPlayer opens
   ↓
8. Browser enters fullscreen
   ↓
9. Thumbnail shows (loading state)
   ↓
10. Video loads (fast, already preloaded)
    ↓
11. Video autoplays
    ↓
12. User watches reel
    ↓
13. User taps screen
    ↓
14. Audio unmutes
    ↓
15. Volume icon shows briefly
    ↓
16. User presses ESC
    ↓
17. Player closes
    ↓
18. Browser exits fullscreen
    ↓
19. Back to grid view
```

---

**Visual flow complete!**
