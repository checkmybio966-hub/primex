# Swiper Class Name Error - Fix Documentation

## ❌ Error

```
InvalidCharacterError: Failed to execute 'remove' on 'DOMTokenList'
The token provided contains invalid characters:
('swiper-pagination-horizontal !bottom-3')
```

---

## 🔍 Root Cause

The error occurred because Tailwind's `!important` modifier (using `!` prefix) was used inside Swiper's pagination configuration strings. The `!` character is invalid in DOM class tokens when combined with other classes in a single string.

### Problematic Code
```typescript
pagination={{
  clickable: true,
  bulletClass: 'swiper-pagination-bullet !bg-white/60 !w-2 !h-2 !mx-1',
  bulletActiveClass: 'swiper-pagination-bullet-active !bg-white !w-2 !h-2 !scale-125',
  horizontalClass: 'swiper-pagination-horizontal !bottom-3',
}}
```

**Issues:**
1. `!bg-white/60` - Invalid: `!` character in class name
2. `!w-2` - Invalid: `!` character in class name
3. `!bottom-3` - Invalid: `!` character in class name
4. Multiple classes in single string with spaces

---

## ✅ Solution

Disabled Swiper's built-in pagination and implemented custom dot indicators instead.

### Fixed Code
```typescript
pagination={{
  clickable: true,
  enabled: false,  // Disable built-in pagination
}}
```

### Custom Dot Indicators
```typescript
{/* Custom Dot Indicators (Instagram Style) */}
<div className="absolute bottom-3 left-0 right-0 z-10 flex items-center justify-center gap-1.5 pointer-events-none">
  {media.map((_, index) => (
    <div
      key={index}
      className={cn(
        "h-1.5 rounded-full transition-all duration-300",
        index === activeIndex
          ? "w-6 bg-white"
          : "w-1.5 bg-white/60"
      )}
    />
  ))}
</div>
```

---

## 🎯 Why This Works

### 1. No Invalid Characters
- Custom implementation uses standard Tailwind classes
- No `!` modifiers in class strings
- Proper className prop usage

### 2. Better Control
- Full control over dot styling
- Easy to customize
- No Swiper CSS conflicts

### 3. Cleaner Code
```typescript
// ❌ BAD: Invalid characters
bulletClass: 'swiper-pagination-bullet !bg-white/60'

// ✅ GOOD: Standard Tailwind
className="bg-white/60 w-2 h-2"
```

---

## 📋 Key Learnings

### DOMTokenList Rules
1. **No spaces in single token**: Each class must be separate
2. **No special characters**: `!`, `@`, `#` are invalid in class names
3. **Use className prop**: For React/JSX components

### Tailwind Important Modifier
```typescript
// ❌ WRONG: In string for DOM manipulation
'!bg-white'

// ✅ CORRECT: In className prop
className="!bg-white"

// ✅ BEST: Avoid !important, use proper specificity
className="bg-white"
```

### Swiper Configuration
```typescript
// ❌ WRONG: Custom classes with invalid characters
pagination={{
  bulletClass: '!bg-white !w-2'
}}

// ✅ CORRECT: Disable and use custom implementation
pagination={{
  enabled: false
}}
```

---

## 🎨 Custom Dot Indicators Benefits

### 1. Full Styling Control
```typescript
className={cn(
  "h-1.5 rounded-full transition-all duration-300",
  index === activeIndex
    ? "w-6 bg-white"           // Active: Long bar
    : "w-1.5 bg-white/60"      // Inactive: Small dot
)}
```

### 2. Instagram-Style Design
- Active: 24px × 6px white bar
- Inactive: 6px × 6px semi-transparent dot
- Smooth 300ms transitions
- Perfect positioning

### 3. No CSS Conflicts
- No Swiper CSS overrides needed
- Clean Tailwind classes
- Easy to maintain

### 4. Better Performance
- No DOM manipulation by Swiper
- Direct React rendering
- Optimized re-renders

---

## 🔧 Implementation Steps

### Step 1: Disable Swiper Pagination
```typescript
<Swiper
  modules={[Pagination]}
  pagination={{
    clickable: true,
    enabled: false,  // Disable built-in
  }}
>
```

### Step 2: Add Custom Dots
```typescript
<div className="absolute bottom-3 left-0 right-0 z-10 flex items-center justify-center gap-1.5 pointer-events-none">
  {media.map((_, index) => (
    <div
      key={index}
      className={cn(
        "h-1.5 rounded-full transition-all duration-300",
        index === activeIndex ? "w-6 bg-white" : "w-1.5 bg-white/60"
      )}
    />
  ))}
</div>
```

### Step 3: Track Active Index
```typescript
const [activeIndex, setActiveIndex] = useState(0);

<Swiper
  onSlideChange={(swiper) => {
    setActiveIndex(swiper.activeIndex);
  }}
>
```

---

## ✅ Verification

### Before Fix
```
❌ Error: InvalidCharacterError
❌ Pagination not working
❌ Console errors
```

### After Fix
```
✅ No errors
✅ Custom dots working
✅ Smooth transitions
✅ Instagram-style design
```

---

## 📊 Comparison

| Aspect | Built-in Pagination | Custom Dots |
|--------|-------------------|-------------|
| **Errors** | ❌ Class name errors | ✅ No errors |
| **Styling** | ⚠️ Limited control | ✅ Full control |
| **Design** | ⚠️ Generic | ✅ Instagram-style |
| **Performance** | ⚠️ DOM manipulation | ✅ React rendering |
| **Maintenance** | ⚠️ CSS overrides | ✅ Clean Tailwind |

---

## 🎉 Result

**Fixed the runtime error** and improved the implementation with:
- ✅ No invalid characters
- ✅ Clean Tailwind classes
- ✅ Custom Instagram-style dots
- ✅ Better performance
- ✅ Full styling control
- ✅ Smooth transitions

---

**Status:** ✅ Fixed  
**Error:** ✅ Resolved  
**Implementation:** ✅ Improved  
**Last Updated:** 2026-02-22
