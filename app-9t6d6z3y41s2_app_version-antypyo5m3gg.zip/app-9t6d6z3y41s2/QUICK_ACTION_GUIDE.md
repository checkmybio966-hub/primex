# 🚀 Quick Action Guide - Albums Not Showing

## Immediate Actions

### 1. Open Browser Console
**Press F12** (or right-click → Inspect → Console)

### 2. Navigate to Albums Tab
Go to **Premium Feed** → Click **Albums** tab

### 3. Check Console Output

**Look for this pattern:**
```
[MOUNT] Has Access: true
[FETCH] Albums: 7
[STATE] Albums length: 7
```

**✅ If you see this:** Albums should appear in UI

**❌ If albums still don't show:** Continue to Step 4

### 4. Click Refresh Button

**If you see albums:** Click the **🔄 Refresh** button next to album count

**If you see "No Premium Albums Yet":** Click **🔄 Refresh Albums** button

### 5. Check Console Again

Look for:
```
[MANUAL REFRESH] User clicked refresh button
[FETCH] Fetching premium content...
[FETCH] Albums: X
```

**✅ If X > 0 and albums appear:** Fixed!

**❌ If X = 0:** Continue to Step 6

### 6. Use Debug Fetch (Admin Only)

Click **🔍 Fetch All Albums (No Filter)** button

Check console:
```
[DEBUG] Total albums in database: X
[DEBUG] Premium albums: Y
```

**If X > 0:** Albums exist, problem is filter or RLS
**If X = 0:** No albums in database

## Quick Fixes

### Fix 1: User Access Issue

**Symptom:** `[MOUNT] Has Access: false`

**Fix:** Run in Supabase SQL Editor:
```sql
UPDATE profiles 
SET role = 'admin', 
    subscription_status = 'active' 
WHERE id = auth.uid();
```

Then refresh page.

### Fix 2: RLS Policy Issue

**Symptom:** `[FETCH] Albums: 0` but database has albums

**Fix:** Run in Supabase SQL Editor:
```sql
DROP POLICY IF EXISTS "View albums based on premium status and user role" ON albums;

CREATE POLICY "View albums based on premium status and user role"
ON albums FOR SELECT
USING (
  (is_premium = false OR is_premium IS NULL)
  OR
  (is_premium = true AND auth.uid() IN (
    SELECT id FROM profiles WHERE role IN ('admin', 'premium_user')
  ))
);
```

Then click refresh button.

### Fix 3: No Albums in Database

**Symptom:** `[DEBUG] Total albums in database: 0`

**Fix:** Create test album:
1. Go to Upload page
2. Click **Create Test Album** button (yellow, admin only)
3. Check if album appears

### Fix 4: State Not Updating

**Symptom:** `[FETCH] Albums: 7` but `[STATE] Albums length: 0`

**Fix:** Hard refresh browser:
- Windows/Linux: **Ctrl + Shift + R**
- Mac: **Cmd + Shift + R**

## Console Log Reference

### Success Pattern ✅
```
[MOUNT] Has Access: true
[FETCH] Albums: 7
[STATE] Albums length: 7
```
→ Albums should appear

### No Access ❌
```
[MOUNT] Has Access: false
```
→ Fix user role (Fix 1)

### Empty Fetch ❌
```
[FETCH] Albums: 0
```
→ Check RLS or database (Fix 2 or 3)

### State Mismatch ❌
```
[FETCH] Albums: 7
[STATE] Albums length: 0
```
→ Hard refresh (Fix 4)

## Button Guide

### 🔄 Refresh (Next to Album Count)
- Visible when albums are showing
- Manually triggers fetch
- Use to refresh album list

### 🔄 Refresh Albums (Empty State)
- Visible when no albums showing
- Manually triggers fetch
- Use to retry loading

### 🔍 Fetch All Albums (Admin Only)
- Removes premium filter
- Shows ALL albums in database
- Use to debug filter issues

### Create Test Album (Admin Only)
- Creates album with dummy data
- Bypasses file upload
- Use to test database and UI

## Troubleshooting Flowchart

```
Albums not showing?
    ↓
Open Console (F12)
    ↓
Check [MOUNT] logs
    ↓
Has Access = true? ──NO──→ Run Fix 1
    ↓ YES
Click "Refresh Albums"
    ↓
Check [FETCH] logs
    ↓
Albums > 0? ──NO──→ Click "Fetch All Albums"
    ↓ YES              ↓
Albums appear? ──NO──→ Run Fix 4
    ↓ YES
✅ FIXED!
```

## Documentation Files

- **`ALBUMS_NOT_SHOWING_FIX.md`** - Complete troubleshooting guide
- **`ALBUMS_FIX_FINAL_SUMMARY.md`** - Detailed fix summary
- **`QUICK_ACTION_GUIDE.md`** - This file

## Support

If issues persist after trying all fixes:

1. Export console logs (right-click in console → Save as)
2. Take screenshots of:
   - Console output
   - Albums tab UI
   - Supabase database query results
3. Check all documentation files
4. Verify database has albums with `is_premium=true`

## Summary

**Most Common Issue:** User role not set correctly

**Quick Fix:** Run Fix 1 SQL query

**Verification:** Check console shows `[MOUNT] Has Access: true`

**Result:** Albums should appear immediately

---

**Remember:** Always check browser console first! It shows exactly what's happening at every step.
