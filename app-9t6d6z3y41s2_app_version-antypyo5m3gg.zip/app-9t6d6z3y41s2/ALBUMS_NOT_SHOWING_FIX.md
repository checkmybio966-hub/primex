# Premium Albums Not Showing - Complete Fix

## Problem
Premium Albums tab shows "No Premium Albums Yet" even though albums exist in the database.

## Solution Implemented

### 1. Enhanced Logging System ✅

Added comprehensive logging at every step to identify where the issue occurs:

**Mount Logging:**
```
[MOUNT] ═══════════════════════════════════════
[MOUNT] PremiumFeedPage mounted
[MOUNT] User: admin
[MOUNT] User ID: xxx
[MOUNT] User Role: admin
[MOUNT] Is Admin: true
[MOUNT] Is Premium: true
[MOUNT] Has Access: true
[MOUNT] ✓ Has access - fetching content
```

**Fetch Logging:**
```
[FETCH] ═══════════════════════════════════════
[FETCH] Fetching premium content...
[FETCH] Calling API functions...
[FETCH] ✓ Premium content fetched successfully
[FETCH] Albums: 7
[FETCH] Albums data: [{id, title, is_premium, media_count}, ...]
[STATE] State updated with fetched data
[STATE] Albums state length: 7
```

**State Change Logging:**
```
[STATE] ═══════════════════════════════════════
[STATE] Albums state changed
[STATE] Albums length: 7
[STATE] Albums: [{id, title, is_premium}, ...]
```

### 2. Manual Refresh Buttons ✅

Added refresh buttons in multiple locations:

**When Albums Are Visible:**
- Refresh button next to album count
- Click to manually trigger fetch

**When No Albums (Empty State):**
- "🔄 Refresh Albums" button
- "🔍 Fetch All Albums (No Filter)" button (admin only)
- "Create Album" button (admin only)

### 3. Debug Functions ✅

**fetchAllAlbumsDebug():**
- Fetches ALL albums without premium filter
- Shows total count, premium count, normal count
- Updates UI with all albums
- Helps identify if albums exist but filter is wrong

### 4. State Monitoring ✅

Added useEffect to monitor albums state changes:
- Logs every time albums array changes
- Shows current length and album details
- Helps identify if state is updating correctly

## How to Debug

### Step 1: Open Browser Console (F12)

Look for the logging sequence when page loads:

**Expected Success Pattern:**
```
[MOUNT] PremiumFeedPage mounted
[MOUNT] Has Access: true
[MOUNT] ✓ Has access - fetching content
[FETCH] Fetching premium content...
[API] Fetching albums - premiumOnly: true
[API] ✓ Fetched 7 albums
[FETCH] ✓ Premium content fetched successfully
[FETCH] Albums: 7
[STATE] Albums state changed
[STATE] Albums length: 7
```

**If you see this, albums should appear in UI.**

### Step 2: Check What You See

**Pattern A: No Access**
```
[MOUNT] Has Access: false
[MOUNT] ❌ No access - skipping fetch
```
**Problem**: User doesn't have premium access
**Fix**: Check user role in database, should be 'admin' or 'premium_user'

**Pattern B: Fetch Returns 0**
```
[FETCH] Albums: 0
[STATE] Albums length: 0
```
**Problem**: API returns empty array
**Possible Causes**:
1. RLS policy blocking access
2. Premium filter too restrictive
3. No albums with is_premium=true

**Fix**: Click "Fetch All Albums (No Filter)" button

**Pattern C: Fetch Returns Data But UI Shows Empty**
```
[FETCH] Albums: 7
[STATE] Albums length: 7
```
But UI shows "No Premium Albums Yet"

**Problem**: State has data but render logic is wrong
**Fix**: Check if `loading` is stuck on true, check conditional rendering

### Step 3: Use Manual Refresh

1. Go to Premium Feed → Albums tab
2. If empty, click "🔄 Refresh Albums" button
3. Watch console logs
4. Check if albums appear

### Step 4: Use Debug Fetch (Admin Only)

1. Click "🔍 Fetch All Albums (No Filter)" button
2. This removes the `is_premium=true` filter
3. Shows ALL albums in database
4. Check console for:
```
[DEBUG] Total albums in database: X
[DEBUG] Premium albums: Y
[DEBUG] Normal albums: Z
```

**If this shows albums:**
- Albums exist in database
- Problem is premium filter or RLS

**If this shows 0 albums:**
- No albums in database at all
- Need to create albums

### Step 5: Check Database Directly

Run SQL query in Supabase:

```sql
-- Check all albums
SELECT 
  id,
  title,
  is_premium,
  jsonb_array_length(media_items) as media_count,
  created_at,
  user_id
FROM albums
ORDER BY created_at DESC
LIMIT 10;
```

**If albums exist:**
- Problem is frontend fetch or RLS
- Continue to Step 6

**If no albums:**
- Need to create albums
- Use Upload page or Test Album function

### Step 6: Check RLS Policies

Run SQL query:

```sql
SELECT 
  policyname,
  cmd,
  qual
FROM pg_policies
WHERE tablename = 'albums'
AND cmd = 'SELECT';
```

**Expected policy:**
```
"View albums based on premium status and user role"
qual: (is_premium = false OR is_premium IS NULL) OR 
      (is_premium = true AND auth.uid() IN (
        SELECT id FROM profiles WHERE role IN ('admin', 'premium_user')
      ))
```

**If policy is different or missing:**
- RLS is blocking access
- Run fix migration (see below)

### Step 7: Check User Role

Run SQL query:

```sql
SELECT 
  id,
  username,
  role,
  subscription_status
FROM profiles
WHERE id = auth.uid();
```

**Expected for admin:**
```
role: 'admin'
subscription_status: 'active'
```

**Expected for premium user:**
```
role: 'premium_user'
subscription_status: 'active'
```

**If role is 'user':**
- User doesn't have premium access
- Update role:
```sql
UPDATE profiles
SET role = 'admin'
WHERE id = auth.uid();
```

## Common Issues and Fixes

### Issue 1: "No Access" in Console

**Symptoms:**
```
[MOUNT] Has Access: false
```

**Cause**: User role is not 'admin' or 'premium_user'

**Fix:**
```sql
UPDATE profiles
SET role = 'admin',
    subscription_status = 'active'
WHERE id = auth.uid();
```

Then refresh page.

### Issue 2: Fetch Returns 0 Albums

**Symptoms:**
```
[FETCH] Albums: 0
[API] ✓ Fetched 0 albums
```

**Possible Causes:**
1. No albums with `is_premium=true`
2. RLS policy blocking
3. Wrong user ID

**Fix:**

**A. Check if albums exist:**
```sql
SELECT COUNT(*) FROM albums WHERE is_premium = true;
```

**B. If count > 0, check RLS:**
```sql
-- Test RLS policy
SELECT * FROM albums WHERE is_premium = true;
```

**C. If query returns empty, RLS is blocking. Fix policy:**
```sql
DROP POLICY IF EXISTS "View albums based on premium status and user role" ON albums;

CREATE POLICY "View albums based on premium status and user role"
ON albums FOR SELECT
USING (
  (is_premium = false OR is_premium IS NULL)
  OR
  (is_premium = true AND auth.uid() IN (
    SELECT id FROM profiles WHERE role IN ('admin', 'premium_user')
  ))
);
```

### Issue 3: Fetch Returns Data But UI Empty

**Symptoms:**
```
[FETCH] Albums: 7
[STATE] Albums length: 7
```
But UI shows "No Premium Albums Yet"

**Cause**: Render logic issue or loading stuck

**Fix:**

**A. Check if loading is stuck:**
Look for:
```
[FETCH] Loading state set to false
```

If missing, loading might be stuck on true.

**B. Force refresh:**
Click "🔄 Refresh Albums" button

**C. Hard refresh browser:**
Ctrl+Shift+R (Windows/Linux)
Cmd+Shift+R (Mac)

### Issue 4: Albums Appear Then Disappear

**Symptoms:**
- Albums flash briefly then disappear
- Or albums show on refresh but not on navigation

**Cause**: Real-time subscription or state management issue

**Fix:**

**A. Check real-time logs:**
```
[REALTIME] Setting up albums subscription
[REALTIME] Albums change detected
```

**B. Disable real-time temporarily:**
Comment out real-time subscription code

**C. Check for state resets:**
Look for multiple `[STATE] Albums length: 0` after successful fetch

### Issue 5: Only Some Albums Show

**Symptoms:**
- Database has 7 albums
- UI shows only 3 albums

**Cause**: Pagination or limit issue

**Fix:**

Check API call:
```typescript
api.getAlbums(true, 20, 0)
//            ^    ^^  ^
//            |    |   offset
//            |    limit
//            premiumOnly
```

Increase limit:
```typescript
api.getAlbums(true, 100, 0)
```

## Testing Checklist

After implementing fixes:

- [ ] Open browser console (F12)
- [ ] Navigate to Premium Feed → Albums tab
- [ ] Check console logs show success pattern
- [ ] Verify albums appear in UI
- [ ] Click an album to verify it opens
- [ ] Click refresh button to verify it works
- [ ] (Admin) Click "Fetch All Albums" to verify debug function works
- [ ] Create new album and verify it appears instantly
- [ ] Check real-time updates work

## Success Indicators

You'll know it's working when:

1. ✅ Console shows `[MOUNT] Has Access: true`
2. ✅ Console shows `[FETCH] Albums: X` (X > 0)
3. ✅ Console shows `[STATE] Albums length: X` (X > 0)
4. ✅ UI shows album count banner
5. ✅ UI shows album cards
6. ✅ Clicking album opens detail page
7. ✅ Refresh button works
8. ✅ New albums appear instantly
9. ✅ No errors in console
10. ✅ Real-time updates work

## Quick Reference

### Console Commands

**Check albums in database:**
```javascript
// In browser console
const { data } = await window.supabase
  .from('albums')
  .select('*')
  .eq('is_premium', true);
console.log('Albums:', data);
```

**Check user role:**
```javascript
const { data: { user } } = await window.supabase.auth.getUser();
const { data: profile } = await window.supabase
  .from('profiles')
  .select('*')
  .eq('id', user.id)
  .single();
console.log('Profile:', profile);
```

### SQL Queries

**Check albums:**
```sql
SELECT id, title, is_premium, created_at 
FROM albums 
WHERE is_premium = true 
ORDER BY created_at DESC;
```

**Check user:**
```sql
SELECT id, username, role, subscription_status 
FROM profiles 
WHERE id = auth.uid();
```

**Fix user role:**
```sql
UPDATE profiles 
SET role = 'admin', subscription_status = 'active' 
WHERE id = auth.uid();
```

**Fix RLS policy:**
```sql
DROP POLICY IF EXISTS "View albums based on premium status and user role" ON albums;

CREATE POLICY "View albums based on premium status and user role"
ON albums FOR SELECT
USING (
  (is_premium = false OR is_premium IS NULL)
  OR
  (is_premium = true AND auth.uid() IN (
    SELECT id FROM profiles WHERE role IN ('admin', 'premium_user')
  ))
);
```

## Summary

The enhanced logging system provides complete visibility into:
1. User authentication and access
2. Data fetching process
3. State updates
4. Render logic

The manual refresh buttons allow:
1. Force refresh when needed
2. Debug fetch without filter
3. Easy troubleshooting

With these tools, you can:
1. Identify exactly where the issue occurs
2. Test different scenarios
3. Fix the root cause
4. Verify the fix works

**Result**: No more mystery about why albums aren't showing. Every step is logged and visible.
