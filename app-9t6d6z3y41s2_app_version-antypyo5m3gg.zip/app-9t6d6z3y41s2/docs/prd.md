# Requirements Document

## 1. Application Overview

### 1.1 Application Name
Primex

### 1.2 Application Description
A complete structured social media system with premium subscription features, supporting posts, reels, user management, and admin controls. Dark theme with mobile-responsive design and real-time updates. Features role-based admin access system using Firebase Authentication. Includes Premium Content Section with Posts, Reels, Albums, and Files tabs, Folder-Based File Manager with strict role-based access control and view-only functionality, auto-sliding banner on home page supporting images and videos with a Buy Now button, admin banner upload management, and Firebase Cloud Messaging (FCM) push notifications for all users when admin uploads new content. Enhanced media handling with full-screen viewer using Swiper.js carousel, multi-media carousel with swipe gestures, and pinch-to-zoom image support. Includes a multiple media upload system with preview grid, per-file progress tracking. Home feed renders normal posts as full-width cards with Instagram-style dynamic smart media layout (1 image = full width; 2 images = side by side; 3 images = left large + right 2 stacked; 4+ images = 2x2 grid with +X more overlay) and premium posts in a 2-column grid. Files section uses Pinterest-style staggered grid layout with ExoPlayer-based video preview and full-screen viewer. Normal Reels use full-screen vertical swipe (ViewPager2) with smooth single-reel-at-a-time scrolling, video preloading, thumbnail preview before playback, a persistent sound icon button at top-right corner, a video progress seekbar at the bottom, invisible double-tap seek gestures, a comments bottom sheet, and admin delete functionality. Premium Reels are displayed in a 2-column grid and support click-to-open full-screen reel player with premium access control, a video progress seekbar, persistent sound icon button at top-right corner, and invisible double-tap seek gestures. Admin can delete images, videos, posts, and reels from both Firebase Storage and Firestore. Navigation bar includes Home, Reels, Upload (admin only), Premium, and Profile tabs — fixed at bottom, always visible, never scrolls or hides. Search feature on Home page (top-right icon) allows searching post descriptions; results visible only to premium users and admin. Login page includes password show/hide toggle, and a Plans Section below the login button displaying Premium and Exclusive plans with Get Access buttons leading to a QR-based payment flow. UI/UX follows a compact, professional, Instagram-like design system with standardized typography, tight spacing, button styles, and color palette. Premium Albums feature provides a card-based vertical layout in the Albums tab, where each admin upload automatically creates a new premium album card; clicking a card opens a dedicated album page with a fixed 2-column media grid supporting images and videos with full-screen viewer.

### 1.3 Reference Files
1. User uploaded images: 3470.jpg, 3471.jpg, 8000.jpg

---

## 2. Project Structure

### 2.1 File Organization
```
PrimeX/
│
├── index.html
├── login.html
├── admin.html
├── premium.html
├── exclusive.html
├── albums.html
├── album-detail.html
├── files.html
├── notifications.html
├── qr.html
├── upload.html
├── search.html
├── firebase.js
├── app.js
├── admin.js
├── upload.js
├── search.js
├── notifications.js
├── albums.js
└── styles/
    ├── global.css
    ├── components.css
    └── layout.css
```

---

## 3. Global Design System

### 3.1 Typography Scale

All text across the app must use a single consistent font family (system-ui or Inter via Google Fonts) with the following compacted scale:

| Role | Size | Weight | Usage |
|---|---|---|---|
| Heading | 14sp–16sp | 700 | Page titles, section headers |
| Subheading | 13sp–14sp | 600 | Card titles, tab labels |
| Body | 12sp | 400 | Post captions, descriptions, list items |
| Small | 11sp | 400 | Timestamps, badges, labels, metadata |

- Line height: 1.4 for body text, 1.2 for headings
- Letter spacing: normal for body, slight tracking for headings if needed
- No mixed font families across any page or component

#### CSS Design Tokens
```css
:root {
  --font-family: 'Inter', system-ui, -apple-system, sans-serif;

  --text-heading: 16px;
  --text-subheading: 14px;
  --text-body: 12px;
  --text-small: 11px;

  --font-weight-bold: 700;
  --font-weight-semibold: 600;
  --font-weight-regular: 400;

  --line-height-heading: 1.2;
  --line-height-body: 1.4;
}
```

#### Android Dimens (res/values/dimens.xml)
```xml
<resources>
  <dimen name=\"text_heading\">16sp</dimen>
  <dimen name=\"text_subheading\">14sp</dimen>
  <dimen name=\"text_body\">12sp</dimen>
  <dimen name=\"text_small\">11sp</dimen>

  <dimen name=\"icon_standard\">24dp</dimen>
  <dimen name=\"icon_small\">20dp</dimen>
  <dimen name=\"icon_cancel\">28dp</dimen>

  <dimen name=\"button_height\">42dp</dimen>
  <dimen name=\"space_xs\">4dp</dimen>
  <dimen name=\"space_sm\">6dp</dimen>
  <dimen name=\"space_md\">12dp</dimen>
  <dimen name=\"space_lg\">16dp</dimen>
  <dimen name=\"space_xl\">20dp</dimen>

  <dimen name=\"screen_padding\">12dp</dimen>
  <dimen name=\"element_gap\">6dp</dimen>
  <dimen name=\"element_gap_md\">8dp</dimen>
</resources>
```

### 3.2 Spacing System

| Token | Value | Usage |
|---|---|---|
| --space-xs | 4dp/px | Icon padding, tight inline gaps |
| --space-sm | 6dp/px | Inner card padding, small gaps, element spacing |
| --space-md | 12dp/px | Section padding, screen padding, card margins |
| --space-lg | 16dp/px | Section separators |
| --space-xl | 20dp/px | Large section gaps |

```css
:root {
  --space-xs: 4px;
  --space-sm: 6px;
  --space-md: 12px;
  --space-lg: 16px;
  --space-xl: 20px;
}
```

### 3.3 Color Palette

```css
:root {
  --color-bg-primary: #0f0f0f;
  --color-bg-secondary: #1a1a1a;
  --color-bg-card: #111111;
  --color-bg-elevated: #222222;

  --color-border: #2a2a2a;
  --color-border-subtle: #1e1e1e;

  --color-text-primary: #ffffff;
  --color-text-secondary: #aaaaaa;
  --color-text-muted: #666666;

  --color-accent: #3b82f6;
  --color-accent-hover: #2563eb;
  --color-accent-gradient: linear-gradient(135deg, #3b82f6, #6366f1);

  --color-success: #22c55e;
  --color-error: #ef4444;
  --color-warning: #f59e0b;

  --color-badge-admin: #ef4444;
  --color-badge-premium: #f59e0b;
}
```

### 3.4 Border Radius

```css
:root {
  --radius-sm: 6px;
  --radius-md: 10px;
  --radius-lg: 14px;
  --radius-full: 9999px;
}
```

### 3.5 Elevation / Shadow

```css
:root {
  --shadow-card: 0 1px 4px rgba(0, 0, 0, 0.35);
  --shadow-elevated: 0 2px 10px rgba(0, 0, 0, 0.5);
}
```

---

## 4. Component Design Standards

### 4.1 Button System

| Property | Value |
|---|---|
| Height | 42dp/px |
| Max Height | 44dp/px |
| Corner radius | 10px–14px |
| Padding | 0 12px |
| Font size | 12sp/px |
| Font weight | 600 |
| Min width | 90dp/px |

Buttons must never exceed 44dp/px in height.

#### Button Variants
```css
.btn-primary {
  height: 42px;
  padding: 0 var(--space-md);
  background: var(--color-accent);
  color: var(--color-text-primary);
  border: none;
  border-radius: var(--radius-md);
  font-size: var(--text-body);
  font-weight: var(--font-weight-semibold);
  font-family: var(--font-family);
  cursor: pointer;
  transition: background 0.2s ease, transform 0.1s ease;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-sm);
  min-width: 90px;
}
.btn-primary:hover { background: var(--color-accent-hover); }
.btn-primary:active { transform: scale(0.98); }

.btn-gradient {
  height: 42px;
  padding: 0 var(--space-md);
  background: var(--color-accent-gradient);
  color: var(--color-text-primary);
  border: none;
  border-radius: var(--radius-lg);
  font-size: var(--text-body);
  font-weight: var(--font-weight-semibold);
  font-family: var(--font-family);
  cursor: pointer;
  transition: opacity 0.2s ease;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 90px;
}
.btn-gradient:hover { opacity: 0.9; }

.btn-secondary {
  height: 42px;
  padding: 0 var(--space-md);
  background: transparent;
  color: var(--color-text-primary);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  font-size: var(--text-body);
  font-weight: var(--font-weight-semibold);
  font-family: var(--font-family);
  cursor: pointer;
  transition: border-color 0.2s ease, background 0.2s ease;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 90px;
}
.btn-secondary:hover {
  border-color: var(--color-accent);
  background: rgba(59, 130, 246, 0.08);
}

.btn-danger {
  height: 42px;
  padding: 0 var(--space-md);
  background: var(--color-error);
  color: white;
  border: none;
  border-radius: var(--radius-md);
  font-size: var(--text-body);
  font-weight: var(--font-weight-semibold);
  font-family: var(--font-family);
  cursor: pointer;
  transition: opacity 0.2s ease;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 90px;
}
.btn-danger:hover { opacity: 0.85; }

.btn-action {
  height: 26px;
  padding: 0 var(--space-sm);
  background: transparent;
  color: var(--color-text-muted);
  border: none;
  border-radius: var(--radius-sm);
  font-size: var(--text-small);
  font-weight: var(--font-weight-semibold);
  font-family: var(--font-family);
  cursor: pointer;
  transition: color 0.2s ease;
}
.btn-action:hover { color: var(--color-error); }
```

### 4.2 Input Fields

```css
.input-field {
  height: 42px;
  width: 100%;
  padding: 0 var(--space-sm);
  background: var(--color-bg-elevated);
  color: var(--color-text-primary);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  font-size: var(--text-body);
  font-family: var(--font-family);
  outline: none;
  transition: border-color 0.2s ease;
  box-sizing: border-box;
}
.input-field::placeholder { color: var(--color-text-muted); }
.input-field:focus { border-color: var(--color-accent); }
textarea.input-field {
  height: auto;
  min-height: 72px;
  padding: var(--space-sm);
  resize: vertical;
  line-height: var(--line-height-body);
}
```

### 4.3 Card Component

```css
.card {
  background: var(--color-bg-card);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  padding: var(--space-sm);
  box-shadow: var(--shadow-card);
}
.card-elevated {
  background: var(--color-bg-elevated);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-lg);
  padding: var(--space-sm);
  box-shadow: var(--shadow-elevated);
}
```

### 4.4 Icon Standards

- Standard icons render at 24dp × 24dp
- Small icons render at 20dp × 20dp
- Cancel/close icons render at 28dp × 28dp
- Reel action panel icons render at 24dp × 24dp
- Icon container padding: 4dp on all sides
- Icon color: var(--color-text-secondary) by default; var(--color-accent) when active

```css
.icon {
  width: 24px;
  height: 24px;
  flex-shrink: 0;
  color: var(--color-text-secondary);
}
.icon-small {
  width: 20px;
  height: 20px;
  flex-shrink: 0;
  color: var(--color-text-secondary);
}
.icon-cancel {
  width: 28px;
  height: 28px;
  flex-shrink: 0;
  color: white;
}
.icon-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 30px;
  height: 30px;
  border-radius: var(--radius-full);
  background: transparent;
  border: none;
  cursor: pointer;
  transition: background 0.2s ease;
  color: var(--color-text-secondary);
}
.icon-btn:hover {
  background: var(--color-bg-elevated);
  color: var(--color-text-primary);
}
.icon-btn.active { color: var(--color-accent); }
```

### 4.5 Badge Components

```css
.badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 16px;
  padding: 0 var(--space-xs);
  border-radius: var(--radius-sm);
  font-size: 10px;
  font-weight: var(--font-weight-semibold);
  font-family: var(--font-family);
  line-height: 1;
}
.badge-admin { background: var(--color-badge-admin); color: white; }
.badge-premium { background: var(--color-badge-premium); color: white; }
.badge-lock { color: var(--color-badge-premium); font-size: 12px; }
.notif-badge {
  position: absolute;
  top: 2px;
  right: 2px;
  min-width: 14px;
  height: 14px;
  padding: 0 2px;
  background: var(--color-error);
  color: white;
  border-radius: var(--radius-full);
  font-size: 9px;
  font-weight: var(--font-weight-bold);
  display: flex;
  align-items: center;
  justify-content: center;
  pointer-events: none;
}
```

### 4.6 Toggle Switch

```css
.toggle-wrapper {
  display: flex;
  align-items: center;
  gap: var(--space-sm);
  cursor: pointer;
}
.toggle-label {
  font-size: var(--text-body);
  color: var(--color-text-secondary);
  font-family: var(--font-family);
}
.toggle-input {
  appearance: none;
  width: 36px;
  height: 20px;
  background: var(--color-bg-elevated);
  border-radius: var(--radius-full);
  position: relative;
  cursor: pointer;
  transition: background 0.2s ease;
  border: 1px solid var(--color-border);
  flex-shrink: 0;
}
.toggle-input:checked {
  background: var(--color-accent);
  border-color: var(--color-accent);
}
.toggle-input::after {
  content: '';
  position: absolute;
  top: 2px;
  left: 2px;
  width: 14px;
  height: 14px;
  background: white;
  border-radius: 50%;
  transition: transform 0.2s ease;
}
.toggle-input:checked::after { transform: translateX(16px); }
```

### 4.7 Tab Bar Component

Used in the Premium Section and Upload Section.

```css
.tab-bar {
  display: flex;
  align-items: center;
  border-bottom: 1px solid var(--color-border);
  background: var(--color-bg-secondary);
  overflow-x: auto;
  scrollbar-width: none;
  flex-shrink: 0;
}
.tab-bar::-webkit-scrollbar { display: none; }
.tab-item {
  flex: 1;
  min-width: 60px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: var(--text-body);
  font-weight: var(--font-weight-semibold);
  font-family: var(--font-family);
  color: var(--color-text-muted);
  background: transparent;
  border: none;
  border-bottom: 2px solid transparent;
  cursor: pointer;
  transition: color 0.2s ease, border-color 0.2s ease;
  white-space: nowrap;
  padding: 0 var(--space-sm);
}
.tab-item.active {
  color: var(--color-accent);
  border-bottom-color: var(--color-accent);
}
```

### 4.8 Album Card Component

Used exclusively in the Premium Albums tab vertical list.

```css
.album-card {
  background: var(--color-bg-card);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-lg);
  overflow: hidden;
  box-shadow: var(--shadow-card);
  cursor: pointer;
  transition: opacity 0.2s ease, transform 0.15s ease;
  display: flex;
  flex-direction: column;
  width: 100%;
}
.album-card:hover {
  opacity: 0.92;
  transform: translateY(-1px);
}
.album-card:active { transform: scale(0.99); }
.album-card-thumbnail {
  width: 100%;
  height: 180px;
  object-fit: cover;
  display: block;
  pointer-events: none;
  user-select: none;
  -webkit-user-select: none;
  background: var(--color-bg-elevated);
}
.album-card-thumbnail-video-wrapper {
  width: 100%;
  height: 180px;
  position: relative;
  overflow: hidden;
  background: var(--color-bg-elevated);
}
.album-card-thumbnail-video-wrapper img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  pointer-events: none;
  user-select: none;
  -webkit-user-select: none;
}
.album-card-thumbnail-play-icon {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 32px;
  height: 32px;
  background: rgba(0, 0, 0, 0.55);
  border-radius: var(--radius-full);
  display: flex;
  align-items: center;
  justify-content: center;
  pointer-events: none;
}
.album-card-body {
  padding: var(--space-sm) var(--space-md);
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.album-card-title {
  font-size: var(--text-subheading);
  font-weight: var(--font-weight-semibold);
  color: var(--color-text-primary);
  font-family: var(--font-family);
  line-height: var(--line-height-heading);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.album-card-meta {
  font-size: var(--text-small);
  color: var(--color-text-muted);
  font-family: var(--font-family);
  display: flex;
  align-items: center;
  gap: var(--space-xs);
}
.album-card-badge {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  height: 16px;
  padding: 0 var(--space-xs);
  background: var(--color-badge-premium);
  color: white;
  border-radius: var(--radius-sm);
  font-size: 10px;
  font-weight: var(--font-weight-semibold);
  font-family: var(--font-family);
}
```

---

## 5. Page-Level Layout Standards

### 5.1 Global Page Structure

```css
* {
  box-sizing: border-box;
}
body {
  margin: 0;
  padding: 0;
  background: var(--color-bg-primary);
  color: var(--color-text-primary);
  font-family: var(--font-family);
  font-size: var(--text-body);
  line-height: var(--line-height-body);
  -webkit-font-smoothing: antialiased;
  overflow-x: hidden;
}
.page-container {
  width: 100%;
  max-width: 480px;
  margin: 0 auto;
  padding: 0;
  min-height: 100vh;
  min-height: 100dvh;
  background: var(--color-bg-primary);
  position: relative;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
```

### 5.2 Safe Area and System Insets Handling

#### Web (CSS)
```css
.page-container {
  padding-top: env(safe-area-inset-top);
  padding-bottom: env(safe-area-inset-bottom);
}
.bottom-nav {
  padding-bottom: env(safe-area-inset-bottom);
}
```

#### Android — WindowInsets (Critical Fix)

All system inset handling must be done manually via WindowInsetsCompat. Do NOT use android:fitsSystemWindows=true on any layout root, parent view, CoordinatorLayout, or RecyclerView.

```kotlin
ViewCompat.setOnApplyWindowInsetsListener(binding.root) { view, insets ->
    val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
    binding.topNavBar.setPadding(0, systemBars.top, 0, 0)
    binding.bottomNavBar.setPadding(0, 0, 0, systemBars.bottom)
    WindowInsetsCompat.CONSUMED
}
```

#### Android — Activity Setup
```kotlin
WindowCompat.setDecorFitsSystemWindows(window, false)
```

#### Android — XML Root Layout Rules
- Root layout: android:layout_width=match_parent and android:layout_height=match_parent
- Do NOT set android:fitsSystemWindows=true on root layout, CoordinatorLayout, RecyclerView, or any parent container
- Bottom navigation bar XML: app:layout_constraintBottom_toBottomOf=parent (ConstraintLayout)
- RecyclerView must be constrained above the bottom navigation bar

### 5.3 Android Root Layout — Stable Bottom Nav (ConstraintLayout)

```xml
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android=\"http://schemas.android.com/apk/res/android\"
    xmlns:app=\"http://schemas.android.com/apk/res-auto\"
    android:layout_width=\"match_parent\"
    android:layout_height=\"match_parent\"
    android:fitsSystemWindows=\"false\"
    android:background=\"@color/bg_primary\">

    <LinearLayout
        android:id=\"@+id/topNavBar\"
        android:layout_width=\"0dp\"
        android:layout_height=\"44dp\"
        android:background=\"@color/bg_secondary\"
        android:orientation=\"horizontal\"
        android:gravity=\"center_vertical\"
        android:paddingStart=\"12dp\"
        android:paddingEnd=\"12dp\"
        app:layout_constraintTop_toTopOf=\"parent\"
        app:layout_constraintStart_toStartOf=\"parent\"
        app:layout_constraintEnd_toEndOf=\"parent\" />

    <androidx.recyclerview.widget.RecyclerView
        android:id=\"@+id/feedRecyclerView\"
        android:layout_width=\"0dp\"
        android:layout_height=\"0dp\"
        android:overScrollMode=\"never\"
        android:scrollbars=\"none\"
        android:clipToPadding=\"false\"
        app:layout_constraintTop_toBottomOf=\"@id/topNavBar\"
        app:layout_constraintBottom_toTopOf=\"@id/bottomNavBar\"
        app:layout_constraintStart_toStartOf=\"parent\"
        app:layout_constraintEnd_toEndOf=\"parent\" />

    <com.google.android.material.bottomnavigation.BottomNavigationView
        android:id=\"@+id/bottomNavBar\"
        android:layout_width=\"0dp\"
        android:layout_height=\"wrap_content\"
        android:background=\"@color/bg_secondary\"
        app:elevation=\"8dp\"
        app:layout_constraintBottom_toBottomOf=\"parent\"
        app:layout_constraintStart_toStartOf=\"parent\"
        app:layout_constraintEnd_toEndOf=\"parent\" />

</androidx.constraintlayout.widget.ConstraintLayout>
```

### 5.4 Top Navigation Bar

```css
.top-nav {
  position: sticky;
  top: 0;
  z-index: 100;
  height: 44px;
  background: var(--color-bg-secondary);
  border-bottom: 1px solid var(--color-border);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 var(--space-md);
  gap: var(--space-sm);
  flex-shrink: 0;
}
.top-nav-logo {
  font-size: var(--text-heading);
  font-weight: var(--font-weight-bold);
  color: var(--color-accent);
  letter-spacing: 1px;
  flex: 1;
  text-align: center;
}
.top-nav-actions {
  display: flex;
  align-items: center;
  gap: var(--space-xs);
}
```

### 5.5 Bottom Navigation Bar

The bottom navigation bar must always be visible and must never hide or move when scrolling. Fixed at the bottom at all times. Equal spacing between all icons. Active tab highlighted with accent color.

#### Tab Configuration

- Admin users see 5 tabs: Home, Reels, Upload (+), Premium, Profile
- Non-admin users see 4 tabs: Home, Reels, Premium, Profile
- The Upload tab (+ icon, center position) is rendered ONLY when currentUser.email === admin@primex.com
- Tab visibility is evaluated on auth state change and applied immediately

```
Bottom Nav Tabs — Admin view (left to right):
1. Home      — house icon
2. Reels     — play icon
3. Upload    — plus icon (center, accent-colored) — admin only
4. Premium   — star/crown icon
5. Profile   — person icon

Bottom Nav Tabs — Non-admin view (left to right):
1. Home      — house icon
2. Reels     — play icon
3. Premium   — star/crown icon
4. Profile   — person icon
```

```css
.bottom-nav {
  position: fixed;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 100%;
  max-width: 480px;
  height: calc(52px + env(safe-area-inset-bottom));
  background: var(--color-bg-secondary);
  border-top: 1px solid var(--color-border);
  display: flex;
  align-items: center;
  justify-content: space-around;
  z-index: 100;
  padding: 0 var(--space-xs);
  padding-bottom: env(safe-area-inset-bottom);
  flex-shrink: 0;
}
.bottom-nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 2px;
  flex: 1;
  height: 52px;
  background: transparent;
  border: none;
  cursor: pointer;
  color: var(--color-text-muted);
  font-size: 9px;
  font-family: var(--font-family);
  font-weight: var(--font-weight-semibold);
  transition: color 0.2s ease;
}
.bottom-nav-item.active { color: var(--color-accent); }
.bottom-nav-item .icon { width: 24px; height: 24px; color: inherit; }
.bottom-nav-item.upload-tab .icon { color: var(--color-accent); }
```

### 5.6 Page Content Area

```css
.page-content {
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
  padding: var(--space-sm);
  padding-bottom: calc(52px + env(safe-area-inset-bottom) + var(--space-sm));
  -webkit-overflow-scrolling: touch;
}
```

---

## 6. Firebase Configuration

### 6.1 firebase.js
```javascript
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js';
import { getFirestore } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';

const firebaseConfig = {
  apiKey: 'YOUR_API_KEY',
  authDomain: 'primex-ac4ba.firebaseapp.com',
  projectId: 'primex-ac4ba',
  storageBucket: 'primex-ac4ba.firebasestorage.app',
  messagingSenderId: '685283037728',
  appId: '1:685283037728:web:7ba03ca1e4e314961de245'
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
```

---

## 7. Database Structure

### 7.1 Users Collection
```
{
  uid: string,
  email: string,
  role: 'user' | 'admin' | 'premium',
  isPremium: boolean,
  status: 'approved',
  createdAt: timestamp,
  fcmToken: string
}
```

### 7.2 Posts Collection
```
{
  id: uniqueId,
  userId: string,
  username: string,
  isPremium: boolean,
  isPremiumOnly: boolean,
  isExclusive: boolean,
  isAlbum: boolean,
  type: 'post' | 'reel',
  mediaItems: [
    {
      mediaUrl: string,
      mediaType: 'image' | 'video',
      thumbnailUrl: string
    }
  ],
  mediaUrl: string,
  mediaType: 'image' | 'video',
  thumbnailUrl: string,
  caption: string,
  likes: number,
  comments: number,
  views: number,
  createdAt: timestamp
}
```

### 7.3 Comments Collection
```
{
  id: uniqueId,
  postId: string,
  userId: string,
  username: string,
  text: string,
  createdAt: timestamp
}
```

### 7.4 Folders Collection
```
{
  id: uniqueId,
  folderName: string,
  createdBy: string,
  createdAt: timestamp,
  updatedAt: timestamp
}
```

### 7.5 Files Collection
```
{
  id: uniqueId,
  folderId: string,
  fileName: string,
  fileUrl: string,
  fileType: 'image' | 'video' | 'document',
  uploadedBy: string,
  uploadedAt: timestamp
}
```

### 7.6 Payment Requests Collection
```
{
  id: uniqueId,
  userId: string,
  username: string,
  planType: 'premium' | 'exclusive',
  status: 'pending' | 'approved' | 'rejected',
  requestedAt: timestamp
}
```

### 7.7 Settings Collection
```
{
  premiumQR: string,
  qrUpdatedAt: timestamp
}
```

### 7.8 Banners Collection
```
{
  id: uniqueId,
  mediaUrl: string,
  mediaType: 'image' | 'video',
  thumbnailUrl: string,
  uploadedBy: string,
  uploadedAt: timestamp,
  order: number
}
```

### 7.9 Notifications Collection
```
{
  id: uniqueId,
  title: string,
  message: string,
  contentType: 'banner' | 'reel' | 'album' | 'file',
  createdAt: timestamp,
  readBy: []
}
```

### 7.10 Albums Collection
```
{
  id: uniqueId,
  title: string,
  thumbnailUrl: string,
  thumbnailType: 'image' | 'video',
  mediaCount: number,
  isPremiumOnly: boolean,
  createdBy: string,
  createdAt: timestamp
}
```

### 7.11 Album Media Collection
```
{
  id: uniqueId,
  albumId: string,
  mediaUrl: string,
  mediaType: 'image' | 'video',
  thumbnailUrl: string,
  order: number,
  uploadedAt: timestamp
}
```

---

## 8. Role System

### 8.1 Role Types

#### Admin
- Email: admin@primex.com
- Full access to all features
- Access to Admin Panel
- Access to Upload Section (Normal Upload + Premium Upload)
- Upload tab visible in bottom navigation
- Access to Premium Section (Posts, Reels, Albums, Files tabs)
- Access to Files Section (Full Control: Create/Rename/Delete folders, Upload/Edit/Delete files)
- Can post premium-only content in both Posts and Reels
- Can manually assign premium role to users
- Can upload banner images and videos
- Can send FCM notifications to all users on content upload
- Can select and upload multiple images and videos simultaneously
- Can delete any image, video, post, reel, album, or album media item (removes from both Firebase Storage and Firestore)
- Delete icon visible on all reels (normal and premium) — admin only
- Can create new premium albums via Albums toggle in Premium Upload
- Search results visible

#### Premium User
- Role: premium
- Access to Premium Section (Posts, Reels, Albums, Files tabs — View Only)
- Access to Files Section (View Only: Open folders, View files)
- Can view premium-only posts and reels
- Can open premium reels in full-screen reel player
- Can view all premium albums and open album detail pages
- Cannot create/rename/delete folders
- Cannot upload/edit/delete files
- Cannot download any files or media
- Upload tab NOT visible in bottom navigation
- Search results visible (premium access)
- All regular user features
- Receives FCM push notifications

#### Normal User
- Role: user
- No access to Premium Section
- No access to Files Section
- No access to Albums Section
- See upgrade prompt on premium content
- Tapping a premium reel shows lock screen with Upgrade to Premium prompt
- Upload tab NOT visible in bottom navigation
- Search returns no results (hidden from normal users)
- Limited features
- Receives FCM push notifications

### 8.2 Role Assignment Logic

1. Check user.email from Firebase Auth
2. If email === admin@primex.com: Set role = admin, grant full admin access, show Upload tab in navigation
3. If user.role === premium: Grant premium access, show Premium tab in bottom navigation, view-only access to Files, search results visible
4. If user.role === user: Apply user restrictions, hide premium content, hide search results

### 8.3 Route Protection

```javascript
import { getAuth, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js';
import { db } from './firebase.js';
import { doc, getDoc } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';

const auth = getAuth();

function checkAccess(requiredRole) {
  onAuthStateChanged(auth, async (user) => {
    if (user) {
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      const userData = userDoc.data();
      if (requiredRole === 'admin' && user.email !== 'admin@primex.com') {
        window.location.href = 'index.html';
      } else if (requiredRole === 'premium' && userData.role !== 'premium' && user.email !== 'admin@primex.com') {
        window.location.href = 'index.html';
      }
    } else {
      window.location.href = 'index.html';
    }
  });
}
```

---

## 9. Login Page (login.html)

### 9.1 Overview
The login page provides email/password authentication with a password visibility toggle and a Plans Section below the login button for users to initiate premium or exclusive plan purchases.

### 9.2 Login Form Layout
```
login.html
├── App Logo / Name (centered, top)
├── Email input (input-field)
├── Password input wrapper
│   ├── Password input (input-field, type=password)
│   └── Eye icon toggle button (right side of input)
├── Login button (btn-primary, full width)
└── Plans Section
    ├── Section label: Choose a Plan
    ├── Premium Plan card
    │   ├── Label: Premium Plan
    │   ├── Price: ₹299 INR
    │   └── Button: Get Access (btn-gradient)
    └── Exclusive Plan card
        ├── Label: Exclusive Plan
        └── Button: Get Access (btn-gradient)
```

### 9.3 Password Show/Hide Toggle
- Password input field has a relative wrapper containing the input and an eye icon button positioned on the right
- Default state: password is hidden (type=password); eye icon shows closed eye
- On toggle click: switch input type to text; icon changes to open eye
- On second toggle click: revert to type=password; icon reverts to closed eye
- Toggle button does not submit the form

### 9.4 Plans Section
- Displayed below the login button, separated by a visible divider
- Section heading: Choose a Plan (text-subheading, centered)
- Two plan cards displayed vertically with 6dp gap

#### Premium Plan Card
- Label: Premium Plan
- Price display: ₹299 INR (text-body, color-text-secondary)
- Button: Get Access (btn-gradient, full width)
- On click: navigate to qr.html with planType=premium as query parameter

#### Exclusive Plan Card
- Label: Exclusive Plan
- No price displayed
- Button: Get Access (btn-gradient, full width)
- On click: navigate to qr.html with planType=exclusive as query parameter

---

## 10. QR Payment Page (qr.html)

### 10.1 Overview
The QR payment page is accessible from two entry points:
1. Tapping the Buy Now button on any home banner slide
2. Tapping Get Access on a plan card from the login page

### 10.2 Layout
```
qr.html
├── Top navigation bar with back button
├── Username display (if accessed from login plans flow)
├── QR Code image (centered, fetched from Settings Collection)
├── Caption: Scan to pay
├── Pay Now button (btn-primary, full width)
└── If no QR set: placeholder text QR code not available
```

### 10.3 Pay Now Button Behavior
- On click:
  1. Create a payment request document in the Payment Requests Collection with planType field set to the value from the query parameter
  2. Navigate back to login.html
  3. Display a success message on the login page: Payment successfully completed, waiting for access
  4. Success message auto-dismisses after 3 seconds

---

## 11. Home Page

### 11.1 Top Navigation Bar — Home Page

The home page top nav contains:
- Left: App logo/name (Primex, accent color)
- Right: Search icon (magnifying glass, 24dp) — tapping navigates to search.html
- Right: Notification bell icon with unread badge

```css
.home-top-nav {
  position: sticky;
  top: 0;
  z-index: 100;
  height: 44px;
  background: var(--color-bg-secondary);
  border-bottom: 1px solid var(--color-border);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 var(--space-md);
  flex-shrink: 0;
}
.home-top-nav-logo {
  font-size: var(--text-heading);
  font-weight: var(--font-weight-bold);
  color: var(--color-accent);
  letter-spacing: 1px;
  flex: 1;
}
.home-top-nav-actions {
  display: flex;
  align-items: center;
  gap: var(--space-xs);
}
```

### 11.2 Banner System (Swiper.js-Based)

- Auto-sliding banner at top of home feed above posts grid
- Supports image and video media types
- Implemented with Swiper.js
- Each banner slide includes a small Buy Now button on the bottom-left that navigates to qr.html
- Banner height: 160dp–190dp
- Auto-slides every 3–5 seconds; loop enabled; touch/swipe support; pagination dots
- Video slides autoplay via HTML5 video element; pause when scrolled out of viewport (IntersectionObserver)
- No download controls on any banner media
- Banner videos display thumbnail (poster attribute) before autoplay — no gray placeholder
- Only the currently active banner slide video plays; all others are paused
- Fetch from Banners Collection ordered by order field ascending
- Real-time onSnapshot listener for instant updates

```css
#banner-container {
  width: 100%;
  margin-bottom: var(--space-sm);
}
.banner-swiper {
  width: 100%;
  border-radius: var(--radius-md);
  overflow: hidden;
}
.banner-slide {
  width: 100%;
  position: relative;
}
.banner-media {
  width: 100%;
  height: 180px;
  object-fit: cover;
  display: block;
  pointer-events: none;
  user-select: none;
  -webkit-user-select: none;
}
.banner-buy-btn {
  position: absolute;
  bottom: var(--space-xs);
  left: var(--space-xs);
  z-index: 10;
  height: 22px;
  padding: 0 var(--space-sm);
  background: rgba(0, 0, 0, 0.45);
  color: white;
  border: 1px solid rgba(255, 255, 255, 0.35);
  border-radius: var(--radius-full);
  font-size: 10px;
  font-weight: var(--font-weight-semibold);
  font-family: var(--font-family);
  cursor: pointer;
  backdrop-filter: blur(4px);
  -webkit-backdrop-filter: blur(4px);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
}
```

### 11.3 Home Feed — Instagram-Style Dynamic Smart Post Layout

- Normal posts: full-width cards with smart media layout (1/2/3/4+ items)
- Premium posts: 2-column Twitter-style grid
- GridLayoutManager with SpanSizeLookup (normal = span 2, premium = span 1)
- RecyclerView overscroll bounce disabled
- Paginated loading: 20 posts per page, infinite scroll
- Video cells display thumbnailUrl as static image with play icon overlay — no gray placeholder

---

## 12. Search Feature (search.html)

### 12.1 Overview
A search page accessible from the search icon on the Home page top navigation bar. Allows searching post descriptions (captions). Search results are restricted by role: only premium users and admin can see results. Normal users see no results.

### 12.2 Access Entry Point
- Search icon (magnifying glass, 24dp) in the top-right area of the Home page top nav bar
- Tapping the icon navigates to search.html
- search.html is accessible to all logged-in users but results are gated by role

### 12.3 Search Page Layout
```
search.html
├── Top navigation bar
│   ├── Back button (left)
│   └── Title: Search
├── Search input bar (full width, sticky below top nav)
│   ├── Search icon (left inside input)
│   └── Text input (placeholder: Search posts...)
├── Results area
│   ├── [Premium/Admin] Matching post cards
│   ├── [Normal user] Empty state: No results found
│   └── [No query] Empty state: Type to search posts
└── Bottom navigation (fixed)
```

### 12.4 Search Logic
- Search field: posts collection, caption field (post descriptions)
- Query: case-insensitive substring match on caption
- Trigger: search executes on input change with 300ms debounce
- Scope: all posts (normal and premium) where type == post
- Results ordered by createdAt descending

### 12.5 Access Control for Search Results

```javascript
function renderSearchResults(results, currentUser) {
  if (currentUser.role !== 'premium' && currentUser.email !== 'admin@primex.com') {
    showEmptyState('No results found');
    return;
  }
  if (results.length === 0) {
    showEmptyState('No posts match your search');
    return;
  }
  renderPostCards(results);
}
```

- Premium users and admin: results rendered as post cards (same card style as home feed)
- Normal users: results area shows empty state message — No results found — regardless of actual matches
- Unauthenticated users: redirect to login.html

### 12.6 Search Result Card
- Same card component as home feed post cards
- Shows: thumbnail (first media item), caption snippet, username, timestamp
- Tapping a card opens the full-screen Swiper.js viewer at index 0
- Premium-only post cards show lock overlay for non-premium users (same as home feed behavior)

### 12.7 Search Input CSS
```css
.search-bar-wrapper {
  position: sticky;
  top: 44px;
  z-index: 90;
  background: var(--color-bg-primary);
  padding: var(--space-sm) var(--space-md);
  border-bottom: 1px solid var(--color-border);
}
.search-input-container {
  position: relative;
  width: 100%;
}
.search-input-icon {
  position: absolute;
  left: var(--space-sm);
  top: 50%;
  transform: translateY(-50%);
  width: 16px;
  height: 16px;
  color: var(--color-text-muted);
  pointer-events: none;
}
.search-input {
  height: 38px;
  width: 100%;
  padding: 0 var(--space-sm) 0 32px;
  background: var(--color-bg-elevated);
  color: var(--color-text-primary);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-full);
  font-size: var(--text-body);
  font-family: var(--font-family);
  outline: none;
  transition: border-color 0.2s ease;
  box-sizing: border-box;
}
.search-input::placeholder { color: var(--color-text-muted); }
.search-input:focus { border-color: var(--color-accent); }
.search-results-area {
  padding: var(--space-sm);
  padding-bottom: calc(52px + env(safe-area-inset-bottom) + var(--space-sm));
}
.search-empty-state {
  text-align: center;
  color: var(--color-text-muted);
  font-size: var(--text-body);
  font-family: var(--font-family);
  padding: var(--space-xl) var(--space-md);
}
```

---

## 13. Upload Section — Admin Only (upload.html)

### 13.1 Access Control
- Check if currentUser.email === admin@primex.com
- If not admin → Redirect to index.html
- Upload tab in bottom navigation is only rendered for admin

### 13.2 Upload Section Layout
```
upload.html
├── Top navigation bar
│   └── Title: Upload
├── Two section cards
│   ├── Normal Upload card
│   └── Premium Upload card
└── Bottom navigation (fixed)
```

### 13.3 Normal Upload

#### Overview
Admin uploads content that appears in the normal (public) home feed. No category restrictions. Supports multiple images and videos simultaneously.

#### Layout
```
Normal Upload
├── Section heading: Normal Upload
├── Media picker (multiple images and videos)
├── Preview grid (thumbnails generated immediately for video files)
├── Per-file progress bars
├── Caption field (textarea.input-field)
└── Upload button (btn-primary, full width)
```

#### Upload Flow
1. Admin selects files (images and/or videos, no size restriction beyond 100MB per video)
2. Preview grid renders immediately for all selected files
3. For each video: generateVideoThumbnail() called immediately on selection
4. On upload:
   - For each video: upload thumbnail to /thumbnails/{fileName}.jpg first, then upload video to /posts/{fileName}
   - For each image: compress client-side (canvas API, maxWidth: 1280, quality: 0.8), then upload to /posts/{fileName}
5. Per-file progress bar updates in real time
6. After all uploads: write Firestore document to posts collection with type=post, isPremiumOnly=false, isExclusive=false, isAlbum=false
7. Redirect to Home after upload

### 13.4 Premium Upload

#### Overview
Admin uploads content routed to premium categories. Auto-detects content type: single video → reel; multiple images → post or album based on toggle selection. All uploaded content is premium-only.

#### Layout
```
Premium Upload
├── Section heading: Premium Upload
├── Media picker (multiple images and videos)
├── Preview grid (thumbnails generated immediately for video files)
├── Per-file progress bars
├── Caption field (textarea.input-field)
├── Category Toggle Row (single line, mutually exclusive)
│   ├── [Posts] toggle
│   ├── [Reels] toggle
│   ├── [Albums] toggle
│   └── [Files] toggle
│       └── Target Folder selector (shown only when Files toggle is ON)
└── Upload button (btn-primary, full width)
```

#### Category Toggle Row
- All four category toggles displayed in a single horizontal row
- Labels: Posts, Reels, Albums, Files
- Toggles are mutually exclusive — activating one deactivates the others
- Active toggle highlighted with accent color background
- Default: no toggle selected; Upload button disabled until a category is selected
- When Files toggle is ON: Target Folder selector dropdown appears below the toggle row, listing all existing folders from the Folders Collection

```css
.upload-category-row {
  display: flex;
  align-items: center;
  gap: var(--space-xs);
  flex-wrap: nowrap;
  overflow-x: auto;
  scrollbar-width: none;
  padding: var(--space-xs) 0;
}
.upload-category-row::-webkit-scrollbar { display: none; }
.upload-category-btn {
  flex-shrink: 0;
  height: 32px;
  padding: 0 var(--space-sm);
  background: var(--color-bg-elevated);
  color: var(--color-text-muted);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-full);
  font-size: var(--text-small);
  font-weight: var(--font-weight-semibold);
  font-family: var(--font-family);
  cursor: pointer;
  transition: background 0.2s ease, color 0.2s ease, border-color 0.2s ease;
  white-space: nowrap;
}
.upload-category-btn.active {
  background: var(--color-accent);
  color: white;
  border-color: var(--color-accent);
}
.folder-selector-wrapper {
  display: none;
  margin-top: var(--space-xs);
}
.folder-selector-wrapper.visible { display: block; }
.folder-selector {
  height: 42px;
  width: 100%;
  padding: 0 var(--space-sm);
  background: var(--color-bg-elevated);
  color: var(--color-text-primary);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  font-size: var(--text-body);
  font-family: var(--font-family);
  outline: none;
  cursor: pointer;
}
```

#### Albums Toggle — Auto-Create Album Flow
- When Albums toggle is ON and admin uploads files:
  1. System uses the caption field value as the album title; if caption is empty, auto-generate title as Album + timestamp
  2. First media item's thumbnail is used as the album card thumbnail
  3. After all media files are uploaded to Firebase Storage:
     - Create a new document in the Albums Collection with title, thumbnailUrl, thumbnailType, mediaCount, isPremiumOnly=true, createdBy, createdAt
     - Create individual documents in the Album Media Collection for each uploaded file, each with albumId referencing the new album, mediaUrl, mediaType, thumbnailUrl, order (sequential index), uploadedAt
  4. Write a post document to the posts collection with isAlbum=true, isPremiumOnly=true for backward compatibility
  5. Trigger FCM notification to all users
  6. The new album card appears immediately in the Premium Albums tab via real-time onSnapshot listener

#### Auto-Detection Logic
- When Reels toggle is ON and admin selects a single video file: content saved as type=reel, isPremiumOnly=true
- When Posts toggle is ON: content saved as type=post, isPremiumOnly=true, isExclusive=false, isAlbum=false
- When Albums toggle is ON: create new album in Albums Collection + Album Media Collection; post document saved with isAlbum=true, isPremiumOnly=true
- When Files toggle is ON: content saved to Files Collection under the selected folder (folderId set to selected folder)
- FCM notification triggered after upload for all premium categories

#### Upload Flow
1. Admin selects files
2. Preview grid renders immediately; video thumbnails generated on selection
3. Admin selects category toggle (Posts / Reels / Albums / Files)
4. If Files: admin selects target folder from dropdown
5. On upload:
   - Same upload flow as Normal Upload (thumbnail first for videos, then media file)
   - Per-file progress bars update in real time
6. After all uploads: write Firestore document(s) with correct flags based on selected category
7. Trigger FCM notification to all users
8. Show upload summary (e.g., 3 of 4 files uploaded successfully)

### 13.5 Shared Upload Rules
- Per-file status labels: Uploading / Uploaded / Failed / Retrying
- On failure: retry once automatically
- Limit video file size to 100MB; show validation error if exceeded
- Upload files in parallel using Promise.all
- Firestore document written only after all uploads complete
- Console log mediaType, mediaUrl, thumbnailUrl for each file after upload

---

## 14. Video Thumbnail Preview System

### 14.1 Overview
Every video across the entire app must display a thumbnail preview before playback begins. No gray placeholder, no black screen, and no blank loading state is acceptable at any point.

### 14.2 Thumbnail Generation
- When admin selects a video file, the system automatically generates a thumbnail by extracting the first frame at 1 second using the HTML5 video element and canvas API
- Thumbnail generation begins immediately on file selection, before the upload starts
- The captured frame is converted to a JPEG blob and uploaded to Firebase Storage under /thumbnails/{fileName}.jpg
- The resulting thumbnailUrl is saved to the corresponding Firestore document
- If thumbnail generation fails, seek to 0 seconds as fallback; if still fails, use a static placeholder image

### 14.3 Thumbnail Display Rules

| Context | Behavior |
|---|---|
| Home grid cell (video) | Render thumbnailUrl as static img element; overlay play icon; no gray placeholder |
| Reels feed (before autoplay) | Set thumbnailUrl as poster attribute on video element; show immediately |
| Full-screen viewer (video) | Set thumbnailUrl as poster; autoplay on open |
| Banner (video) | Set thumbnailUrl as poster; autoplay when in viewport |
| Files section (video) | Render thumbnailUrl as static img element; overlay play icon; ExoPlayer autoplays on tap |
| Premium Reels full-screen player | Set thumbnailUrl as poster; autoplay immediately on open |
| Upload preview grid | Show generated thumbnail immediately after file selection |
| Album card thumbnail (video) | Render thumbnailUrl as static img element with play icon overlay; no gray placeholder |
| Album detail grid cell (video) | Render thumbnailUrl as static img element with play icon overlay; no gray placeholder |

### 14.4 Implementation
```javascript
async function generateVideoThumbnail(file) {
  return new Promise((resolve) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.muted = true;
    video.playsInline = true;
    video.src = URL.createObjectURL(file);
    video.currentTime = 1;
    video.onloadeddata = () => {
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 360;
      canvas.getContext('2d').drawImage(video, 0, 0);
      canvas.toBlob((blob) => {
        URL.revokeObjectURL(video.src);
        resolve(blob);
      }, 'image/jpeg', 0.8);
    };
    video.onseeked = () => {
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 360;
      canvas.getContext('2d').drawImage(video, 0, 0);
      canvas.toBlob((blob) => {
        URL.revokeObjectURL(video.src);
        resolve(blob);
      }, 'image/jpeg', 0.8);
    };
    video.onerror = () => {
      URL.revokeObjectURL(video.src);
      resolve(null);
    };
  });
}
```

---

## 15. Normal Reels System

### 15.1 Overview
Full-screen vertical swipe reels using ViewPager2, Instagram-style. Exactly one reel is visible and playing at a time. Videos autoplay, preload adjacent reels, and show thumbnail preview before playback. Bottom navigation is hidden while on the reels page.

Clean UI: only the sound icon button (top-right) and the seekbar (bottom) are shown as overlay controls. A single close/back button (X icon, 28dp) at top-left. No fullscreen toggle button. No duplicate cancel icons. No default ActionBar back arrow.

A persistent sound icon button at top-right corner. A comments bottom sheet accessible via comment icon in the right-side action panel. A thick, visible video progress seekbar (4dp–5dp height) at the bottom. Invisible double-tap gesture enables 10-second forward/backward seek. Admin can delete any reel directly from the reel view.

### 15.2 Reels Page Structure
- Full-screen vertical ViewPager2 container
- Each reel occupies 100vh (100dvh on mobile)
- Swipe up → next reel; swipe down → previous reel
- Each swipe moves exactly one reel
- Only one reel is active and playing at any time
- Bottom navigation hidden on reels page
- Fetch posts where type == reel AND isExclusive != true AND isAlbum != true
- No default ActionBar back arrow; no extra overlay buttons; no fullscreen toggle button
- Exactly one close/back button (X icon, 28dp) at top-left; no duplicate cancel icons

### 15.3 Single ExoPlayer Instance Architecture

```kotlin
val player = ExoPlayer.Builder(context).build()
val mediaItem = MediaItem.fromUri(videoUrl)
player.setMediaItem(mediaItem)
player.prepare()
player.playWhenReady = true
player.volume = 0f
playerView.player = player
```

- Use a single ExoPlayer instance per reel — do NOT create a new player for every action
- Do NOT call prepare() or setMediaItem() during seek operations
- Do NOT recreate the player on mute/unmute, seekbar drag, or double-tap seek
- offscreenPageLimit = 1 in ViewPager2

### 15.4 Sound Icon Button — Top-Right Corner, Persistent

- Positioned at top-right corner; always visible
- Default state on reel load: muted → show mute icon
- When unmuted: show sound-on icon
- State resets to muted when swiping to a new reel
- Tapping the sound icon does NOT trigger any other gesture
- Tapping the reel screen body does NOT toggle sound

### 15.5 Invisible Double-Tap Seek Gesture — Audio-Safe

- Double-tap right half → seek forward 10 seconds
- Double-tap left half → seek backward 10 seconds
- Consecutive taps stack seek increments; 300ms debounce
- Mute state preserved across all seek operations
- player.seekTo() used exclusively — prepare() and setMediaItem() never called during seek

### 15.6 Video Progress Seekbar — Thick, Visible, Audio-Safe

- Track height: 4dp–5dp; thumb size: 12px × 12px
- Displayed at the very bottom of each reel
- Syncs with video in real time
- Mute state saved before seek and restored after seek
- Seekbar functionality completely independent of audio state

### 15.7 Right Side Action Buttons

Right side actions (top to bottom):
1. Like button — heart icon + like count
2. Comment button — comment icon + comment count → opens comments bottom sheet
3. Delete button — trash icon — visible only when currentUser.email === admin@primex.com

- Icons: 24dp × 24dp; 10dp gap between buttons

### 15.8 Reel Delete Flow (Admin Only)

- Confirmation modal before deletion
- On confirm: delete mediaUrl and thumbnailUrl from Firebase Storage, delete Firestore document
- UI removes reel immediately (optimistic update)
- On error: show error toast, restore reel in UI

---

## 16. Reels Comments System

### 16.1 Overview
Tapping the comment icon on a reel opens a bottom sheet displaying comments for that reel in real time and allows adding a new comment.

### 16.2 Comments Bottom Sheet Behavior
- Slides up from the bottom; covers approximately 60% of screen height
- Background dimmed (rgba(0,0,0,0.5))
- Tapping the dim area or close button dismisses the sheet
- Active reel video continues playing while sheet is open
- Comments ordered by createdAt ascending
- Real-time updates via Firestore onSnapshot
- Each comment shows: username, comment text, timestamp
- Input field at bottom for adding a new comment
- Empty state: No comments yet. Be the first to comment.

---

## 17. Full-Screen Media Viewer (Swiper.js)

### 17.1 Overview
When a user clicks any media cell, the full-screen Swiper.js viewer opens at the tapped media index. Navigation is swipe-only (left/right). No download button, no share button, no arrow buttons. Exactly one close (X) button at top-left (28dp). No duplicate cancel icons.

### 17.2 Swiper.js CDN
```html
<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css\" />
<script src=\"https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js\"></script>
```

### 17.3 Full-Screen Viewer Rules
- Opened when user clicks any media cell in a normal post, premium post, search result card, or album detail grid
- Viewer initializes at the index of the tapped media item
- Navigation: left/right swipe only via Swiper.js
- Exactly one close (X) button at top-left (28dp); no duplicate cancel icons
- Images support pinch-to-zoom
- Videos autoplay with poster set to thumbnailUrl; no download controls
- Position counter displayed at bottom center
- Bottom navigation remains fixed and visible while the viewer is open

---

## 18. Admin Panel (admin.html)

### 18.1 Access Control
- Check if currentUser.email === admin@primex.com
- If not admin → Redirect to index.html

### 18.2 Stats Grid
1. Subscribers — count users where status == approved
2. Total Posts — count posts where type == post
3. Total Views — sum of all post views
4. Total Likes — sum of all post likes
5. Premium Users — count users where role == premium OR role == admin
6. Pending Requests — count payment requests where status == pending

All stats update in real time via Firestore onSnapshot.

### 18.3 QR Code Management
- Upload QR Code image section
- Replace / Change QR anytime
- Save changes button (btn-primary, full width)
- Store in Settings Collection: { premiumQR: string, qrUpdatedAt: timestamp }
- Changes reflect instantly on QR page and Premium Page

### 18.4 Payment Requests Section
- Fetch payment requests where status == pending, order by latest
- Request card: username display, planType label, Approve / Reject buttons
- Approve: set isPremium=true, role=premium (or role=exclusive based on planType), send real-time notification, remove from pending
- Reject: set status=rejected, remove from pending
- Empty state: No pending payment requests

### 18.5 Banner Management
- File picker supporting images (jpg, png, gif, webp) and videos (mp4, webm)
- Upload to Firebase Storage under /banners/{fileName}
- For video banners: generate and upload thumbnail before saving
- Save metadata to Banners Collection
- After upload: Firestore real-time listener updates home banner instantly
- After upload: Trigger FCM notification to all users
- List existing banners with thumbnail, media type label, upload date, delete button
- Reorder option: up/down arrows to change order field

### 18.6 Delete Content (Admin)

- Admin can delete any image, video, post, reel, album, or album media item
- Confirmation modal before deletion
- On confirm: delete all mediaUrl and thumbnailUrl files from Firebase Storage, then delete Firestore document(s)
- For album deletion: delete all Album Media Collection documents for that albumId, delete all associated Storage files, then delete the Albums Collection document
- UI removes item immediately (optimistic update)
- On error: show error toast, restore item in UI

### 18.7 Create User
- Email input (input-field), role select (input-field styled), Create button (btn-primary)
- On create: save to users collection with role, isPremium, status: approved, createdAt

---

## 19. Premium Section — Tabbed Layout (premium.html)

### 19.1 Access Control
- Check if currentUser.role === premium OR currentUser.email === admin@primex.com
- If not premium/admin → Redirect to index.html with upgrade prompt

### 19.2 Premium Section Layout
```
premium.html
├── Top navigation bar
│   └── Title: Premium
├── Tab Bar (sticky below top nav)
│   ├── Posts tab
│   ├── Reels tab
│   ├── Albums tab
│   └── Files tab
├── Tab Content Area (scrollable)
│   ├── Posts tab content
│   ├── Reels tab content
│   ├── Albums tab content
│   └── Files tab content
└── Bottom navigation (fixed)
```

### 19.3 Tab Bar Behavior
- Four tabs: Posts, Reels, Albums, Files
- Tabs displayed in a single horizontal row using the tab-bar component (Section 4.7)
- Tab switching is instant with no lag; content area updates without full page reload
- Active tab highlighted with accent color and bottom border
- Tab bar is sticky below the top navigation bar
- Each tab content area is independently scrollable

### 19.4 Posts Tab
- Fetch posts where (isPremiumOnly == true OR isExclusive == true) AND type == post
- Includes both old and new premium post content
- Display in 2-column Twitter-style grid (same as home feed premium grid)
- Each card: thumbnail at natural aspect ratio, premium badge, lock overlay for non-premium
- Tapping a card opens full-screen Swiper.js viewer
- Paginated loading: 20 items per page, infinite scroll

### 19.5 Reels Tab
- Fetch posts where (isPremiumOnly == true OR isExclusive == true) AND type == reel
- Includes both old and new premium reel content
- Display in 2-column grid (same as Section 21 Premium Reels grid)
- Each card: thumbnailUrl at natural aspect ratio, premium badge, play icon overlay
- Tapping a card opens full-screen reel player (premium access check applied)
- Paginated loading: 20 items per page, infinite scroll

### 19.6 Albums Tab — Premium Albums Card-Based Layout

#### Overview
The Albums tab displays all premium albums in a vertical card-based list. Each album is represented by a full-width card showing a thumbnail, album title, and media count. Tapping a card navigates to the dedicated Album Detail Page for that album.

#### Data Source
- Fetch all documents from the Albums Collection where isPremiumOnly == true
- Ordered by createdAt descending
- Real-time onSnapshot listener for instant updates when admin uploads new albums
- Lazy-loaded: data fetched only when Albums tab is first activated; cached in memory for the session

#### Albums Tab Layout
```
Albums Tab Content
├── Vertical list of album cards (full width, stacked vertically)
│   └── Each album card (.album-card)
│       ├── Thumbnail area (180px height, object-fit: cover)
│       │   ├── [image] img element with thumbnailUrl
│       │   └── [video] img element with thumbnailUrl + play icon overlay
│       └── Card body
│           ├── Premium badge (top-right of body)
│           ├── Album title (.album-card-title)
│           └── Media count (.album-card-meta) — e.g., 12 items
├── Empty state (if no albums): No premium albums yet
└── Paginated loading: 20 albums per page, infinite scroll
```

#### Album Card Behavior
- Each card uses the .album-card component defined in Section 4.8
- Thumbnail auto-selected: use thumbnailUrl from the Albums Collection document (set to first media item's thumbnail on upload)
- If thumbnailType === video: render thumbnailUrl as img element with play icon overlay (same pattern as video cells elsewhere)
- If thumbnailType === image: render thumbnailUrl as img element directly
- Media count label: display mediaCount value from Albums Collection, e.g., 12 items
- On card click: navigate to album-detail.html?albumId={id}
- Cards are equally spaced with var(--space-sm) gap between each card
- No uneven gaps; all cards are full width within the page content area
- Smooth press animation: scale(0.99) on active state, 0.15s ease

#### Albums Tab CSS
```css
.albums-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-sm);
  padding: var(--space-sm);
  padding-bottom: calc(52px + env(safe-area-inset-bottom) + var(--space-sm));
}
.albums-empty-state {
  text-align: center;
  color: var(--color-text-muted);
  font-size: var(--text-body);
  font-family: var(--font-family);
  padding: var(--space-xl) var(--space-md);
}
```

### 19.7 Files Tab
- Same content and behavior as the standalone Files section (Section 20)
- Folder list displayed; tapping a folder opens its contents
- Pinterest-style staggered 2-column grid for file items
- Admin: full folder and file management
- Premium users: view only

### 19.8 Performance Requirements
- Tab content is lazy-loaded: data for a tab is fetched only when that tab is first activated
- Once loaded, tab content is cached in memory for the session; no re-fetch on tab switch
- RecyclerView instances per tab use setHasFixedSize(false) and itemAnimator = null for smooth scrolling
- No NestedScrollView wrapping any RecyclerView
- Tab switching animation: instant (no slide or fade transition between tab content areas)

---

## 20. Album Detail Page (album-detail.html)

### 20.1 Overview
A dedicated page for viewing all media within a specific premium album. Accessible by tapping any album card in the Albums tab. Displays all media in a fixed 2-column grid with equal spacing. Supports both images and videos. Videos show a play icon overlay. Tapping any media item opens it in the full-screen Swiper.js viewer.

### 20.2 Access Control
- Check if currentUser.role === premium OR currentUser.email === admin@primex.com
- If not premium/admin → Redirect to index.html with upgrade prompt
- albumId query parameter required; if missing → redirect to premium.html

### 20.3 Page Layout
```
album-detail.html
├── Top navigation bar
│   ├── Back button (left, navigates back to premium.html Albums tab)
│   └── Album title (center, fetched from Albums Collection)
├── Page content area (scrollable)
│   └── 2-column fixed grid (.album-detail-grid)
│       └── Each grid cell (.album-detail-cell)
│           ├── [image] img element (thumbnailUrl, lazy-loaded)
│           └── [video] img element (thumbnailUrl) + play icon overlay
└── Bottom navigation (fixed)
```

### 20.4 2-Column Fixed Grid Layout

- Fixed 2-column grid; equal column widths
- Equal spacing between all cells: var(--space-xs) gap
- Each cell height determined by a fixed aspect ratio of 1:1 (square cells) for consistent alignment
- No uneven gaps; all cells perfectly aligned
- Images render with object-fit: cover within the square cell
- Videos render thumbnailUrl with object-fit: cover within the square cell, with a centered play icon overlay
- No gray placeholder, no black screen for any cell

```css
.album-detail-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--space-xs);
  padding: var(--space-xs);
  padding-bottom: calc(52px + env(safe-area-inset-bottom) + var(--space-xs));
}
.album-detail-cell {
  position: relative;
  aspect-ratio: 1 / 1;
  overflow: hidden;
  border-radius: var(--radius-md);
  background: var(--color-bg-elevated);
  cursor: pointer;
  transition: opacity 0.15s ease;
}
.album-detail-cell:hover { opacity: 0.88; }
.album-detail-cell:active { opacity: 0.75; }
.album-detail-cell img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  pointer-events: none;
  user-select: none;
  -webkit-user-select: none;
}
.album-detail-play-icon {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 32px;
  height: 32px;
  background: rgba(0, 0, 0, 0.55);
  border-radius: var(--radius-full);
  display: flex;
  align-items: center;
  justify-content: center;
  pointer-events: none;
}
```

### 20.5 Data Loading
- On page load: read albumId from URL query parameter
- Fetch album document from Albums Collection to get album title
- Fetch all documents from Album Media Collection where albumId == albumId, ordered by order ascending
- Render grid cells immediately as data loads
- Lazy loading: use IntersectionObserver to load thumbnailUrl images only when cells enter the viewport
- Paginated loading: 40 items per page, load more on scroll to bottom

### 20.6 Media Click Behavior
- On cell tap: open full-screen Swiper.js viewer (Section 17) initialized at the tapped cell's index
- Viewer slides through all media items in the album in order
- Images support pinch-to-zoom
- Videos autoplay with thumbnailUrl as poster; no download controls
- Exactly one close (X) button at top-left (28dp); no duplicate cancel icons
- Position counter displayed at bottom center

### 20.7 Performance
- Thumbnail images lazy-loaded via IntersectionObserver; full media loaded only on tap
- Grid renders immediately with placeholder background color (var(--color-bg-elevated)) while thumbnails load
- No lag on scroll even with large albums (40+ items)
- itemAnimator = null on RecyclerView equivalent for smooth scrolling

---

## 21. Folder-Based File Manager — Pinterest-Style Layout (files.html)

### 21.1 Access Control
- Check if currentUser.role === premium OR currentUser.email === admin@primex.com
- If not → Redirect to index.html with upgrade prompt

### 21.2 Pinterest-Style Staggered Grid Layout

- 2-column staggered grid
- Each item height determined by media's natural aspect ratio
- Images render at natural aspect ratio
- Videos render with thumbnailUrl as static preview at natural aspect ratio, with play icon overlay
- No blank or gray screen for any item

```css
.files-staggered-grid {
  columns: 2;
  column-gap: var(--space-xs);
  padding: var(--space-xs);
}
.files-staggered-item {
  break-inside: avoid;
  margin-bottom: var(--space-xs);
  border-radius: var(--radius-md);
  overflow: hidden;
  background: var(--color-bg-elevated);
  cursor: pointer;
  position: relative;
  transition: opacity 0.2s ease;
}
.files-staggered-item:hover { opacity: 0.88; }
.files-staggered-item img {
  width: 100%;
  height: auto;
  display: block;
  pointer-events: none;
  user-select: none;
  -webkit-user-select: none;
}
```

### 21.3 Media Click Behavior

#### Images
- On tap: open full-screen viewer overlay with pinch-to-zoom support
- Swipe between media items within the same folder
- Exactly one close (X) button at top-left (28dp)

#### Videos
- On tap: show thumbnail preview first (already visible as static img)
- Transition smoothly from thumbnail to ExoPlayer video playback
- ExoPlayer autoplays in full-screen viewer
- Thumbnail remains visible until ExoPlayer signals STATE_READY
- On STATE_READY: crossfade thumbnail out, video in (200ms)

### 21.4 Role-Based Access
- Admin: Create, rename, delete folders; upload, edit, delete files; view files; FCM notification on file upload
- Premium Users: Open folders, view files only; no management; no download
- Normal Users: No access, redirect with upgrade prompt

---

## 22. Premium Reels — 2-Column Grid with Click-to-Open Full-Screen Player

### 22.1 Overview
Premium reels displayed in a 2-column RecyclerView grid. Tapping a card opens a full-screen reel player overlay. Access gated by premium role.

Clean UI in the full-screen player: only the sound icon button (top-right) and the seekbar (bottom) as overlay controls. Exactly one close (X) button at top-left (28dp). No fullscreen toggle button. No duplicate cancel icons. No default ActionBar back arrow.

### 22.2 Premium Reels Grid Layout

- 2-column grid; each card shows thumbnailUrl at natural aspect ratio
- 6dp gap between cards; rounded corners (--radius-md)
- No fixed height — height determined by thumbnail's natural aspect ratio
- Lock/premium badge on each card
- Tapping a card triggers premium access check and opens full-screen player

### 22.3 Click Behavior on Premium Reel Cards
- If role === premium OR email === admin@primex.com: open full-screen reel player
- If role === user: show lock screen overlay with Upgrade to Premium button

### 22.4 Full-Screen Reel Player Overlay

```
Full-Screen Reel Player
├── Full-screen video element (100vw × 100dvh)
├── Poster/thumbnail displayed before autoplay (thumbnailUrl as poster attribute)
├── Sound icon button (top-right corner — always visible)
├── Close button (top-left, X icon, 28dp — single instance only)
├── Minimal controls overlay (bottom)
│   ├── Username
│   ├── Caption
│   └── Video progress seekbar (thick, 4dp–5dp, audio-safe)
└── Invisible double-tap seek (audio-safe)
```

- Video autoplays immediately on open, muted by default
- thumbnailUrl set as poster attribute — no gray placeholder, no black screen
- Bottom navigation hidden while player is open
- All seek operations preserve current mute/unmute state
- player.seekTo() used exclusively — prepare() and setMediaItem() never called during seek

---

## 23. Firebase Cloud Messaging (FCM) Notification System

### 23.1 Trigger Events
Push notification sent to all registered users when admin uploads:
- Banner (image or video)
- Reels (via Premium Upload)
- Albums content (via Premium Upload — Albums toggle)
- Files (new file uploaded to any folder)

### 23.2 Notification Content
- Title: New Update
- Message: Admin uploaded new content
- Content type label included in payload for routing

### 23.3 FCM Implementation
- FCM token stored in users/{uid}.fcmToken on login
- Notification document saved to notifications collection on admin upload
- FCM dispatch handled via Firebase Cloud Functions
- Notification badge count via onSnapshot on notifications collection, counting unread items
- Foreground notifications shown as in-app toast
- Background notifications handled by firebase-messaging-sw.js service worker

---

## 24. Notification Screen (notifications.html)

### 24.1 Behavior
- Accessible to all logged-in users via notification bell icon
- List ordered by latest first
- Unread items: blue left border + subtle background tint
- Viewing screen marks all notifications as read, resets badge count
- Empty state: No notifications yet

---

## 25. Download Prevention System

### 25.1 Global CSS
```css
img, video {
  pointer-events: none;
  user-select: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}
img { -webkit-touch-callout: none; }
```

### 25.2 JavaScript Protection
```javascript
document.addEventListener('contextmenu', (e) => {
  if (e.target.tagName === 'IMG' || e.target.tagName === 'VIDEO') {
    e.preventDefault();
    return false;
  }
});
document.addEventListener('touchend', (e) => {
  if (e.target.tagName === 'IMG' || e.target.tagName === 'VIDEO') {
    e.preventDefault();
  }
});
const videos = document.querySelectorAll('video');
videos.forEach(video => {
  video.setAttribute('controlsList', 'nodownload');
  video.setAttribute('disablePictureInPicture', 'true');
  video.removeAttribute('download');
});
const images = document.querySelectorAll('img');
images.forEach(img => {
  img.removeAttribute('download');
  img.setAttribute('draggable', 'false');
});
```

### 25.3 Firebase Storage Rules
```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /files/{folderId}/{fileName} {
      allow read: if request.auth != null &&
        (get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'premium' ||
         get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin');
      allow write: if request.auth != null &&
        request.auth.token.email == 'admin@primex.com';
    }
    match /albums/{albumId}/{fileName} {
      allow read: if request.auth != null &&
        (get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'premium' ||
         get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin');
      allow write: if request.auth != null &&
        request.auth.token.email == 'admin@primex.com';
    }
    match /posts/{fileName} {
      allow read: if request.auth != null;
      allow write: if request.auth != null;
    }
    match /thumbnails/{fileName} {
      allow read: if request.auth != null;
      allow write: if request.auth != null &&
        request.auth.token.email == 'admin@primex.com';
    }
    match /banners/{fileName} {
      allow read: if true;
      allow write: if request.auth != null &&
        request.auth.token.email == 'admin@primex.com';
    }
  }
}
```

---

## 26. Upgrade System

### 26.1 Upgrade Prompt
- Display locations: Premium Section (normal users), Files Section (normal users), premium-only posts in home feed grid, search results page (normal users)
- Use btn-gradient with text: Upgrade to Premium
- On click: redirect to premium payment page

---

## 27. Popup / Modal Component

```css
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.7);
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--space-sm);
}
.modal-container {
  background: var(--color-bg-elevated);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-lg);
  padding: var(--space-md);
  width: 100%;
  max-width: 320px;
  box-shadow: var(--shadow-elevated);
}
.modal-title {
  font-size: var(--text-subheading);
  font-weight: var(--font-weight-bold);
  color: var(--color-text-primary);
  font-family: var(--font-family);
  margin: 0 0 var(--space-xs) 0;
}
.modal-message {
  font-size: var(--text-body);
  color: var(--color-text-secondary);
  font-family: var(--font-family);
  margin: 0 0 var(--space-md) 0;
  line-height: var(--line-height-body);
}
.modal-actions {
  display: flex;
  gap: var(--space-sm);
  justify-content: flex-end;
}
```

---

## 28. Security Rules

### 28.1 Application Access
- Login page required for authentication
- Direct access to home feed after login
- Open access to login page

### 28.2 Admin Privileges
Only admin@primex.com can: access Upload Section (Normal Upload + Premium Upload), upload/replace QR code, approve premium requests, access Admin Dashboard, approve/reject users, delete any post/reel/image/video/album/album media item (from both Storage and Firestore), create new users, assign premium role, post premium-only/exclusive/album content, manage folders and files, control all settings, upload and manage banners, dispatch FCM notifications, upload multiple media files, delete reels directly from the reels view, create new premium albums via Albums toggle.

### 28.3 Premium Privileges
Only premium users and admin can: access Premium Section (all four tabs), access Files Section, access Albums Section (view album cards and album detail pages), access Exclusive content, view premium-only posts and reels, open premium reels in full-screen player, open folders and view files (no download), see search results.

### 28.4 Route Protection
- Admin, premium, files, albums, album-detail, exclusive, and upload routes protected
- Check email === admin@primex.com for admin
- Check role === premium for premium access
- Redirect non-authorized users
- Prevent direct URL access to folders and protected files
- Upload page (upload.html) redirects non-admin users to index.html
- album-detail.html redirects non-premium/non-admin users to index.html

---

## 29. Acceptance Criteria

1. All text across the app uses a single consistent font family with heading (14sp–16sp), subheading (13sp–14sp), body (12sp), and small (11sp) sizes applied correctly throughout
2. All buttons have a consistent height of 42dp/px (max 44dp/px), corner radius of 10px–14px, and equal padding on all sides
3. All spacing uses the fixed compacted scale: 4dp / 6dp / 12dp / 16dp / 20dp; no arbitrary spacing values appear anywhere
4. All input fields have a consistent height of 42dp/px, same width within their container, and matching border radius
5. All icons in reel action panels render at 24dp × 24dp; close/cancel icons render at 28dp × 28dp; small icons render at 20dp × 20dp
6. The color palette is limited to the defined tokens; no additional accent colors appear
7. All UI elements fit perfectly on screen; no content is cut off or overflows on any page
8. Bottom navigation is always visible and never hides or moves when scrolling on any page
9. Bottom navigation is fixed at the bottom with height 52dp; only page content scrolls
10. android:fitsSystemWindows is NOT set to true on any root layout, CoordinatorLayout, RecyclerView, or parent container
11. WindowCompat.setDecorFitsSystemWindows(window, false) is called in every Activity.onCreate()
12. System bar insets are applied manually via ViewCompat.setOnApplyWindowInsetsListener
13. RecyclerView overscroll bounce is disabled on all RecyclerView instances
14. Bottom navigation contains exactly 5 tabs for admin (Home, Reels, Upload, Premium, Profile) and 4 tabs for non-admin users (Home, Reels, Premium, Profile)
15. Upload tab (+ icon) is visible ONLY when currentUser.email === admin@primex.com; it is completely hidden for all other users
16. Upload tab visibility is evaluated on auth state change and applied immediately without requiring a page reload
17. Tapping the Upload tab navigates to upload.html; non-admin direct URL access to upload.html redirects to index.html
18. Upload section contains two clearly separated sections: Normal Upload and Premium Upload
19. Normal Upload supports multiple image and video selection with no category restriction; content is saved as public posts
20. Premium Upload supports multiple image and video selection with a single-line category toggle row showing Posts, Reels, Albums, Files
21. Category toggles in Premium Upload are mutually exclusive; activating one deactivates the others
22. Upload button in Premium Upload is disabled until a category toggle is selected
23. When Files toggle is ON in Premium Upload, a Target Folder selector dropdown appears listing all existing folders
24. When Files toggle is OFF, the Target Folder selector is hidden
25. When Albums toggle is ON and admin uploads files, a new album document is created in the Albums Collection and individual media documents are created in the Album Media Collection
26. The new album card appears immediately in the Premium Albums tab via real-time onSnapshot after upload
27. Album card thumbnail is auto-selected from the first uploaded media item's thumbnailUrl
28. Album title is set from the caption field; if caption is empty, title is auto-generated as Album + timestamp
29. Media count on each album card accurately reflects the number of media items in that album
30. Video thumbnail is automatically generated on file selection using the first frame at 1 second; thumbnail preview appears in the upload preview grid immediately
31. Both video file and thumbnail are uploaded before the Firestore document is written
32. thumbnailUrl is always stored alongside mediaUrl in every video Firestore document
33. Console logs mediaType, mediaUrl, and thumbnailUrl after each video upload for debugging
34. Per-file progress bars update in real time during upload; status labels show Uploading / Uploaded / Failed / Retrying
35. Failed uploads retry once automatically; upload summary shown after completion
36. Albums tab in Premium Section displays all premium albums as full-width vertical cards with equal spacing and no uneven gaps
37. Each album card shows: thumbnail (180px height, object-fit cover), premium badge, album title, and media count
38. Video album thumbnails display thumbnailUrl as img element with play icon overlay — no gray placeholder
39. Tapping an album card navigates to album-detail.html?albumId={id}
40. album-detail.html displays the album title in the top navigation bar
41. Album detail page displays all media in a fixed 2-column grid with 1:1 aspect ratio cells and equal var(--space-xs) gaps
42. All cells in the album detail grid are perfectly aligned with no uneven gaps
43. Video cells in the album detail grid display thumbnailUrl as img element with centered play icon overlay — no gray placeholder
44. Tapping any cell in the album detail grid opens the full-screen Swiper.js viewer at the correct tapped index
45. Full-screen viewer in album detail supports swipe navigation through all album media items in order
46. Thumbnail images in album detail grid are lazy-loaded via IntersectionObserver
47. Album detail page loads smoothly with no lag even for large albums (40+ items)
48. Back button on album detail page navigates back to premium.html with Albums tab active
49. Non-premium/non-admin users accessing album-detail.html directly are redirected to index.html
50. Search icon (magnifying glass, 24dp) is visible in the top-right area of the Home page top navigation bar for all logged-in users
51. Tapping the search icon navigates to search.html
52. Search input executes search on caption field of posts collection with 300ms debounce
53. Premium users and admin see matching post cards in search results
54. Normal users see no results (empty state: No results found) regardless of actual matches
55. Search result cards use the same card style as home feed post cards; tapping a card opens the full-screen viewer
56. Premium Section is restructured as a tabbed page with four tabs: Posts, Reels, Albums, Files
57. Tab bar is sticky below the top navigation bar; tab switching is instant with no lag
58. Each tab shows both old and new content; data is fetched from Firestore on first tab activation and cached for the session
59. Posts tab in Premium Section displays premium posts in a 2-column Twitter-style grid
60. Reels tab in Premium Section displays premium reels in a 2-column grid with natural aspect ratio thumbnails
61. Files tab in Premium Section displays the same folder-based file manager as the standalone Files section
62. No NestedScrollView wraps any RecyclerView in any tab content area
63. Home page displays an auto-sliding banner at the top of the feed supporting both images and videos; banner height is 160dp–190dp
64. Banner auto-slides every 3–5 seconds with indicator dots and touch/swipe support
65. Banner videos display thumbnail (poster) before autoplay — no gray placeholder
66. Each banner slide displays a small, rounded, semi-transparent Buy Now button on the bottom-left; tapping it navigates to qr.html
67. Feed uses GridLayoutManager with SpanSizeLookup; normal posts occupy span 2 (full width), premium posts occupy span 1 (half width)
68. Normal posts with 1/2/3/4+ media items display correct smart layout variants
69. Video cells in all smart layout variants display thumbnailUrl as a static image with a centered play icon overlay — no gray placeholder, no black screen
70. Tapping any media cell opens the full-screen Swiper.js viewer starting at the correct tapped index
71. Full-screen viewer navigation is swipe-only; no arrow buttons, no download button, no share button
72. Exactly one close (X) button (28dp) is shown at the top-left of the full-screen viewer; no duplicate cancel icons
73. Normal Reels page displays exactly one reel at a time in full-screen vertical layout using ViewPager2
74. Each swipe moves exactly one reel; fast scrolling and multi-reel jumps are disabled
75. Each reel video shows a thumbnail preview (poster) before autoplay — no gray placeholder, no black screen
76. Bottom navigation is hidden while on the reels page
77. Normal reel screen shows only the sound icon button (top-right) and seekbar (bottom) as overlay controls; no fullscreen toggle button
78. Exactly one close/back button (X icon, 28dp) at top-left of the reel screen; no duplicate cancel icons
79. Like button, comment button, and admin-only delete button appear on the right side action panel; icons are 24dp × 24dp with 10dp gap
80. Delete button on reels is visible only to admin
81. A persistent sound icon button (36dp circle) is always visible on each reel at top-right corner
82. Sound icon state resets to muted when swiping to a new reel
83. Double-tap seek preserves mute/unmute state; player.seekTo() used exclusively
84. A single ExoPlayer instance is used per reel; never recreated on seek, mute/unmute, or seekbar drag
85. Seekbar track height is 4dp–5dp; thumb size is 12px × 12px; updates in real time
86. Seekbar works correctly when the video is muted
87. Tapping the comment icon opens a comments bottom sheet; real-time comments displayed oldest first
88. Admin can delete any post, reel, image, video, album, or album media item; delete removes files from both Firebase Storage and Firestore
89. A confirmation modal appears before any delete action is executed
90. Premium reels grid uses 2-column layout; each card shows thumbnailUrl at natural aspect ratio with 6dp gap
91. Tapping a premium reel card opens full-screen reel player for premium users and admin
92. Non-premium users tapping a premium reel card see a lock screen overlay with Upgrade to Premium button
93. Files section displays media in a Pinterest-style staggered 2-column grid; item heights vary by natural aspect ratio
94. Video items in the Files section show thumbnailUrl as static preview with play icon overlay
95. Smooth crossfade transition from thumbnail to video occurs when ExoPlayer reaches STATE_READY
96. When admin uploads a banner, reel, album content, or file, a push notification is sent to all users via FCM
97. Notification bell icon shows unread badge count in real time
98. Viewing the notifications screen marks all notifications as read and resets badge count
99. No download button, right-click save, or long-press save is available on any media
100. Login page displays a password field with a functional eye icon toggle
101. Login page displays a Plans Section with Premium Plan (₹299 INR) and Exclusive Plan cards
102. qr.html displays the authenticated username at the top when accessed from the plans flow
103. qr.html Pay Now button creates a payment request in Firestore, navigates back to login.html, and shows success message auto-dismissing after 3 seconds
104. Dark theme and design system tokens are applied consistently across all pages and components
105. Overall UI is compacted 10–15%; more content is visible on screen without sacrificing readability
106. No extra margins, paddings, or duplicate buttons/icons exist anywhere in the app
107. All UI elements fit within screen bounds with no overflow on any page

---

## 30. Out of Scope (This Release)

- Native Android APK build or Android Studio project files
- PhotoView Android library
- Offline mode or service worker caching beyond FCM background notifications
- Multi-language / localization support
- Analytics or crash reporting integration
- FCM topic-based or segmented notification targeting
- Server-side video transcoding or compression
- XML layouts, Styles.xml, or Dimens.xml
- Chat system
- Discord-style upload feature in chat
- Swipe-between-premium-reels within the full-screen player
- Exclusive content as a standalone page (merged into Premium Section tabs)
- Separate Create screen (replaced by Upload Section accessible via admin-only bottom nav tab)
- Album editing after creation (rename, reorder, add/remove individual media items post-upload)