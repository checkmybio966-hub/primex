# Quick Reference - Audio Seek & Post Card Size Fixes

## 🔧 Audio Consistency Fix

### Problem
- Double-tap seek changes audio state unexpectedly
- Mute/unmute triggers during seek operations

### Solution
```typescript
if (isDoubleTap && tapSide !== 'center') {
  // Seek WITHOUT changing audio
  video.currentTime = newTime;
  lastTapRef.current = now; // ✅ Update here
} else if (!isDoubleTap) {
  // Single tap ONLY - toggle mute
  toggleMute();
  lastTapRef.current = now; // ✅ Update here
}
```

### Key Points
- ✅ Update `lastTapRef` in each branch
- ✅ Use `else if (!isDoubleTap)` for single tap
- ✅ Never call `toggleMute()` during seek
- ✅ Preserve audio state across all seek operations

---

## 📐 Post Card Size Fix

### Problem
- Fixed `aspect-[4/3]` ratio too restrictive
- Images cropped with `object-cover`
- Cards too small

### Solution

#### Container
```typescript
// Before: aspect-[4/3]
// After: max-h-[600px]
<div className="relative w-full max-h-[600px] rounded-xl overflow-hidden bg-black/40">
```

#### Media
```typescript
// Before: h-full object-cover
// After: h-auto object-contain
<img className="w-full h-auto max-h-[600px] object-contain bg-black" />
```

### Key Points
- ✅ `w-full` for full width
- ✅ `h-auto` for natural aspect ratio
- ✅ `max-h-[600px]` to prevent too tall
- ✅ `object-contain` to show entire content
- ✅ `bg-black` for clean letterbox

---

## 📊 Comparison Tables

### Audio Behavior

| Action | Before | After |
|--------|--------|-------|
| Double-tap left | Seek + might mute | Seek only ✅ |
| Double-tap right | Seek + might mute | Seek only ✅ |
| Single tap | Toggle mute | Toggle mute ✅ |
| Triple tap | Seek + might mute | Seek only ✅ |

### Card Sizing

| Property | Before | After |
|----------|--------|-------|
| Height | aspect-[4/3] (fixed) | max-h-[600px] (flexible) |
| Image Height | h-full | h-auto |
| Object Fit | object-cover (crops) | object-contain (fits) |
| Background | None | bg-black |

---

## 💻 Code Templates

### Audio-Safe Tap Handler
```typescript
const handleVideoTap = (e: React.MouseEvent) => {
  const now = Date.now();
  const isDoubleTap = now - lastTapRef.current < 300;
  
  if (isDoubleTap && tapSide !== 'center') {
    // Seek only - NO audio change
    video.currentTime += seekAmount;
    lastTapRef.current = now;
  } else if (!isDoubleTap) {
    // Single tap - toggle mute
    toggleMute();
    lastTapRef.current = now;
  }
};
```

### Flexible Card Container
```typescript
<div className="relative w-full max-h-[600px] rounded-xl overflow-hidden bg-black/40">
  <img 
    src={url} 
    className="w-full h-auto max-h-[600px] object-contain bg-black"
  />
</div>
```

---

## ✅ Checklist

### Audio Fix
- [x] Seek doesn't change mute state
- [x] Single tap toggles mute
- [x] Double-tap seeks correctly
- [x] Triple tap works
- [x] Volume preserved

### Card Size Fix
- [x] Full width cards
- [x] Auto height
- [x] Maintains aspect ratio
- [x] No cropping
- [x] Max height constraint
- [x] Responsive

---

## 🎯 Key Measurements

### Audio Timing
- Double-tap delay: 300ms
- Seek amount: ±10 seconds
- Feedback duration: 800ms

### Card Sizing
- Width: 100% (w-full)
- Height: Auto (h-auto)
- Max Height: 600px
- Object Fit: Contain
- Background: Black

---

## 🎉 Result

**Audio:**
- ✅ Stable during seek
- ✅ No unexpected muting
- ✅ Clear gesture separation

**Cards:**
- ✅ Full width
- ✅ Auto height
- ✅ Proper aspect ratio
- ✅ No cropping

---

**All features working perfectly!**
