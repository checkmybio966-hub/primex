import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import IntersectObserver from '@/components/common/IntersectObserver';
import { ErrorBoundary } from '@/components/common/ErrorBoundary';
import { Toaster } from '@/components/ui/sonner';
import { AuthProvider } from '@/contexts/AuthContext';
import { RouteGuard } from '@/components/common/RouteGuard';
import { PerformanceMonitor } from '@/utils/performance';
import routes, { type RouteConfig } from './routes';

const renderRoutes = (routes: RouteConfig[]) => {
  return routes.map((route, index) => (
    <Route
      key={index}
      path={route.path}
      element={route.element}
    >
      {route.children && renderRoutes(route.children)}
    </Route>
  ));
};

const App: React.FC = () => {
  useEffect(() => {
    // Initialize performance monitoring
    PerformanceMonitor.enableHardwareAcceleration();

    // Disable right-click globally
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    document.addEventListener('contextmenu', handleContextMenu);
    
    // Log app initialization
    console.log('✅ Primex initialized with performance optimizations');
    
    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
    };
  }, []);

  return (
    <ErrorBoundary>
      <Router>
        <AuthProvider>
          <RouteGuard>
            <IntersectObserver />
            <div className="flex flex-col min-h-screen">
              <main className="flex-grow">
                <Routes>
                  {renderRoutes(routes)}
                </Routes>
              </main>
            </div>
            <Toaster position="top-center" richColors />
          </RouteGuard>
        </AuthProvider>
      </Router>
    </ErrorBoundary>
  );
};

export default App;
