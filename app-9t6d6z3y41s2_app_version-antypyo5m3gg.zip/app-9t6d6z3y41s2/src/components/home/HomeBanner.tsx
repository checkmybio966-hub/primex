import { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, Pagination, EffectFade } from 'swiper/modules';
import type { Swiper as SwiperType } from 'swiper';
import Video from '@/components/ui/video';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { ShoppingCart } from 'lucide-react';
import type { Banner } from '@/types';
import { cn } from '@/lib/utils';

import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/effect-fade';

interface HomeBannerProps {
  banners: Banner[];
  loading?: boolean;
}

export function HomeBanner({ banners, loading }: HomeBannerProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [swiper, setSwiper] = useState<SwiperType | null>(null);
  const videoRefs = useRef<Map<number, HTMLVideoElement>>(new Map());
  const navigate = useNavigate();

  useEffect(() => {
    // Pause all videos except active one
    videoRefs.current.forEach((video, index) => {
      if (index === activeIndex) {
        video.play().catch(() => {});
      } else {
        video.pause();
        video.currentTime = 0;
      }
    });
  }, [activeIndex]);

  if (loading) {
    return (
      <div className="w-full aspect-[16/9] md:aspect-[21/9] rounded-[1.5rem] overflow-hidden">
        <Skeleton className="w-full h-full bg-muted/20" />
      </div>
    );
  }

  if (!banners || banners.length === 0) {
    return null;
  }

  return (
    <div className="w-full relative group">
      <Swiper
        modules={[Autoplay, Pagination, EffectFade]}
        spaceBetween={0}
        slidesPerView={1}
        autoplay={{
          delay: 4000,
          disableOnInteraction: false,
          pauseOnMouseEnter: true,
        }}
        pagination={{
          clickable: true,
          dynamicBullets: true,
        }}
        effect="fade"
        fadeEffect={{ crossFade: true }}
        loop={banners.length > 1}
        onSwiper={setSwiper}
        onSlideChange={(swiper) => setActiveIndex(swiper.realIndex)}
        className="w-full aspect-[16/9] md:aspect-[21/9] rounded-[1.5rem] overflow-hidden shadow-card home-banner"
      >
        {banners.map((banner, index) => (
          <SwiperSlide key={banner.id}>
            <div className="relative w-full h-full bg-black/40 group/slide">
              {banner.media_type === 'image' ? (
                <img
                  src={banner.media_url}
                  alt={banner.title || 'Banner'}
                  className="w-full h-full object-cover"
                  loading={index === 0 ? 'eager' : 'lazy'}
                />
              ) : (
                <video
                  ref={(el) => {
                    if (el) videoRefs.current.set(index, el);
                  }}
                  src={banner.media_url}
                  className="w-full h-full object-cover"
                  muted
                  loop
                  playsInline
                  preload={index === 0 ? 'auto' : 'metadata'}
                />
              )}

              {/* Overlay Gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />

              {/* Content Overlay */}
              {(banner.title || banner.description) && (
                <div className="absolute bottom-0 left-0 right-0 p-3 md:p-4 z-10">
                  {banner.title && (
                    <h2 className="text-section md:text-xl font-black text-white mb-1.5 drop-shadow-lg uppercase italic tracking-tighter">
                      {banner.title}
                    </h2>
                  )}
                  {banner.description && (
                    <p className="text-small md:text-section text-white/90 drop-shadow-md max-w-2xl font-medium">
                      {banner.description}
                    </p>
                  )}
                </div>
              )}

              {/* Link Overlay */}
              {banner.link_url && (
                <a
                  href={banner.link_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="absolute inset-0 z-20"
                  aria-label={banner.title || 'Banner link'}
                />
              )}
            </div>
          </SwiperSlide>
        ))}
      </Swiper>

      {/* Buy Now Button */}
      <Button
        onClick={() => navigate('/premium')}
        className="absolute bottom-3 left-3 z-30 h-9 px-3 rounded-full bg-white/90 hover:bg-white text-black font-semibold text-xs shadow-lg backdrop-blur-sm transition-all hover:scale-105 flex items-center gap-1.5"
      >
        <ShoppingCart className="w-3.5 h-3.5" />
        Buy Now
      </Button>

      {/* Banner Counter */}
      {banners.length > 1 && (
        <div className="absolute top-2 right-2 z-30 bg-black/60 backdrop-blur-md text-white px-2.5 py-1 rounded-full text-[10px] font-bold">
          {activeIndex + 1} / {banners.length}
        </div>
      )}
    </div>
  );
}
