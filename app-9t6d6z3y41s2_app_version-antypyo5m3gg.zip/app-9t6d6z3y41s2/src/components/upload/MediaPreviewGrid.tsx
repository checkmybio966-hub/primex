import { X, Play, Image as ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface MediaPreviewItem {
  file: File;
  preview: string;
  type: 'image' | 'video';
  thumbnail?: string; // For video thumbnails
}

interface MediaPreviewGridProps {
  items: MediaPreviewItem[];
  onRemove: (index: number) => void;
  className?: string;
}

export function MediaPreviewGrid({ items, onRemove, className }: MediaPreviewGridProps) {
  if (items.length === 0) return null;

  return (
    <div className={cn("w-full", className)}>
      <div className={cn(
        "grid gap-2",
        items.length === 1 && "grid-cols-1",
        items.length === 2 && "grid-cols-2",
        items.length === 3 && "grid-cols-2",
        items.length >= 4 && "grid-cols-2"
      )}>
        {items.slice(0, 4).map((item, index) => (
          <div
            key={index}
            className={cn(
              "relative rounded-xl overflow-hidden bg-black/40 group aspect-square",
              items.length === 3 && index === 0 && "col-span-2 aspect-video"
            )}
          >
            {item.type === 'image' ? (
              <img
                src={item.preview}
                alt={`Preview ${index + 1}`}
                className="w-full h-full object-cover"
              />
            ) : (
              <>
                {/* Show thumbnail if available, otherwise show video */}
                {item.thumbnail ? (
                  <img
                    src={item.thumbnail}
                    alt={`Video thumbnail ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <video
                    src={item.preview}
                    className="w-full h-full object-cover"
                    muted
                  />
                )}
                <div className="absolute inset-0 flex items-center justify-center bg-black/30 pointer-events-none">
                  <div className="w-12 h-12 rounded-full bg-white/90 flex items-center justify-center shadow-lg">
                    <Play className="w-6 h-6 text-black fill-black ml-1" />
                  </div>
                </div>
              </>
            )}

            {/* Remove Button */}
            <Button
              size="icon"
              variant="destructive"
              className="absolute top-2 right-2 w-8 h-8 rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-10"
              onClick={() => onRemove(index)}
            >
              <X className="w-4 h-4" />
            </Button>

            {/* +N Overlay for 4+ items */}
            {index === 3 && items.length > 4 && (
              <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center">
                <span className="text-white text-4xl font-black">
                  +{items.length - 4}
                </span>
              </div>
            )}

            {/* File Info */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="flex items-center gap-2">
                {item.type === 'image' ? (
                  <ImageIcon className="w-4 h-4 text-white" />
                ) : (
                  <Play className="w-4 h-4 text-white" />
                )}
                <span className="text-xs text-white font-medium truncate">
                  {item.file.name}
                </span>
              </div>
              <span className="text-xs text-white/70">
                {(item.file.size / 1024 / 1024).toFixed(2)} MB
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* File Count */}
      <div className="mt-3 flex items-center justify-between text-sm">
        <span className="text-muted-foreground font-medium">
          {items.length} file{items.length !== 1 ? 's' : ''} selected
        </span>
        <span className="text-muted-foreground">
          Total: {(items.reduce((acc, item) => acc + item.file.size, 0) / 1024 / 1024).toFixed(2)} MB
        </span>
      </div>
    </div>
  );
}
