import { Heart, MessageCircle, Eye, Volume2, VolumeX, Lock, Sparkles, Play } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { Button } from '@/components/ui/button';
import type { Post, MediaItem } from '@/types';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { FullScreenViewer } from '@/components/media/FullScreenViewer';
import { CommentsDialog } from '@/components/comments/CommentsDialog';
import { useEffect, useState, useRef, useCallback } from 'react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

interface ReelCardProps {
  reel: Post;
  isActive: boolean;
  preload?: boolean;
  onDelete?: (reelId: string) => void;
}

export function ReelCard({ reel, isActive, preload = false, onDelete }: ReelCardProps) {
  const { user, isApproved, isAdmin, isPremium } = useAuth();
  const navigate = useNavigate();
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(reel.likes_count);
  const [isLikeLoading, setIsLikeLoading] = useState(false);
  const [hasViewed, setHasViewed] = useState(false);
  const [muted, setMuted] = useState(true);
  const [showHeart, setShowHeart] = useState(false);
  const [showVolumeIcon, setShowVolumeIcon] = useState(false);
  const [viewerOpen, setViewerOpen] = useState(false);
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [videoLoaded, setVideoLoaded] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isSeeking, setIsSeeking] = useState(false);
  const [showSeekFeedback, setShowSeekFeedback] = useState<'forward' | 'backward' | null>(null);
  const [seekTapCount, setSeekTapCount] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const lastTapRef = useRef<number>(0);
  const lastTapSideRef = useRef<'left' | 'right' | 'center' | null>(null);
  const volumeTimeoutRef = useRef<number | undefined>(undefined);
  const seekTimeoutRef = useRef<number | undefined>(undefined);

  const hasAccess = !reel.is_premium || isPremium || isAdmin;
  const mediaItems: MediaItem[] = [{ url: reel.media_url, type: 'video' }];

  useEffect(() => {
    if (user) {
      api.isLiked(user.id, reel.id).then(setIsLiked);
    }
  }, [user, reel.id]);

  useEffect(() => {
    if (isActive && !hasViewed && hasAccess) {
      setHasViewed(true);
      api.incrementViews(reel.id);
    }
  }, [isActive, hasViewed, reel.id, hasAccess]);

  useEffect(() => {
    if (videoRef.current) {
      if (isActive && hasAccess) {
        videoRef.current.play().catch(() => {
          // Auto-play might be blocked, wait for user interaction
        });
      } else {
        videoRef.current.pause();
        videoRef.current.currentTime = 0;
      }
    }
  }, [isActive, hasAccess]);

  // Track video progress
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const updateProgress = () => {
      if (!isSeeking && video.duration) {
        setProgress((video.currentTime / video.duration) * 100);
      }
    };

    const updateDuration = () => {
      if (video.duration) {
        setDuration(video.duration);
      }
    };

    video.addEventListener('timeupdate', updateProgress);
    video.addEventListener('loadedmetadata', updateDuration);
    video.addEventListener('durationchange', updateDuration);

    return () => {
      video.removeEventListener('timeupdate', updateProgress);
      video.removeEventListener('loadedmetadata', updateDuration);
      video.removeEventListener('durationchange', updateDuration);
    };
  }, [isSeeking]);

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const video = videoRef.current;
    if (!video || !duration) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = (x / rect.width) * 100;
    const time = (percentage / 100) * duration;

    video.currentTime = time;
    setProgress(percentage);
  };

  const handleSeekStart = () => {
    setIsSeeking(true);
  };

  const handleSeekEnd = () => {
    setIsSeeking(false);
  };

  const handleLike = useCallback(async () => {
    if (!user || !isApproved) {
      toast.error('You must be an approved user to like reels');
      return;
    }
    if (isLikeLoading) return;

    setIsLikeLoading(true);
    const liked = await api.toggleLike(user.id, reel.id);
    setIsLiked(liked);
    setLikesCount((prev: number) => (liked ? prev + 1 : prev - 1));
    setIsLikeLoading(false);
    
    if (liked) {
      setShowHeart(true);
      setTimeout(() => setShowHeart(false), 800);
    }
  }, [user, isApproved, isLikeLoading, reel.id]);

  const handleVideoTap = (e: React.MouseEvent<HTMLDivElement>) => {
    const video = videoRef.current;
    if (!video) return;

    const now = Date.now();
    const DOUBLE_TAP_DELAY = 300;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const width = rect.width;
    
    // Determine tap zone: left 40%, center 20%, right 40%
    let tapSide: 'left' | 'right' | 'center';
    if (x < width * 0.4) {
      tapSide = 'left';
    } else if (x > width * 0.6) {
      tapSide = 'right';
    } else {
      tapSide = 'center';
    }
    
    const isDoubleTap = now - lastTapRef.current < DOUBLE_TAP_DELAY;
    
    if (isDoubleTap && tapSide !== 'center') {
      // Double tap on left/right - seek ±10 seconds
      // DO NOT change mute state during seek
      const seekAmount = tapSide === 'right' ? 10 : -10;
      const newTime = Math.max(0, Math.min(video.duration, video.currentTime + seekAmount));
      video.currentTime = newTime;
      
      // Show feedback
      setShowSeekFeedback(tapSide === 'right' ? 'forward' : 'backward');
      
      // Stack seek taps (allow 2-3 continuous taps)
      if (lastTapSideRef.current === tapSide) {
        setSeekTapCount(prev => prev + 1);
      } else {
        setSeekTapCount(1);
      }
      
      // Clear existing timeout
      if (seekTimeoutRef.current) {
        clearTimeout(seekTimeoutRef.current);
      }
      
      // Hide feedback after 800ms
      seekTimeoutRef.current = setTimeout(() => {
        setShowSeekFeedback(null);
        setSeekTapCount(0);
      }, 800);
      
      lastTapSideRef.current = tapSide;
      // Update lastTapRef to prevent single tap from triggering
      lastTapRef.current = now;
    } else if (isDoubleTap && tapSide === 'center') {
      // Double tap center - like
      handleLike();
      setShowHeart(true);
      setTimeout(() => setShowHeart(false), 1000);
      lastTapSideRef.current = null;
      lastTapRef.current = now;
    } else if (!isDoubleTap) {
      // Single tap only - toggle mute
      // Only toggle mute if it's NOT part of a double-tap sequence
      setMuted(prev => !prev);
      setShowVolumeIcon(true);
      
      if (volumeTimeoutRef.current) {
        clearTimeout(volumeTimeoutRef.current);
      }
      
      volumeTimeoutRef.current = setTimeout(() => {
        setShowVolumeIcon(false);
      }, 1000);
      
      lastTapSideRef.current = null;
      lastTapRef.current = now;
    }
  };

  // Cleanup timeouts on unmount
  useEffect(() => {
    return () => {
      if (volumeTimeoutRef.current) {
        clearTimeout(volumeTimeoutRef.current);
      }
      if (seekTimeoutRef.current) {
        clearTimeout(seekTimeoutRef.current);
      }
    };
  }, []);

  return (
    <div className="relative h-full w-full bg-black flex items-center justify-center overflow-hidden">
      {/* Thumbnail Background - Show while video is loading */}
      {!videoLoaded && reel.thumbnail_url && (
        <div className="absolute inset-0 z-0">
          <img
            src={reel.thumbnail_url}
            alt="Video thumbnail"
            className="w-full h-full object-contain"
          />
          <div className="absolute inset-0 bg-black/20" />
        </div>
      )}

      <div 
        className="absolute inset-0 z-10 cursor-pointer"
        onClick={handleVideoTap}
      >
        <video
          ref={videoRef}
          src={reel.media_url}
          className="max-w-full max-h-full object-contain pointer-events-none select-none"
          playsInline
          muted={muted}
          loop
          preload={isActive ? "auto" : preload ? "metadata" : "none"}
          poster={reel.thumbnail_url || `${reel.media_url}#t=0.1`}
          onContextMenu={(e) => e.preventDefault()}
          onLoadedData={() => setVideoLoaded(true)}
          controlsList="nodownload"
        />
      </div>

      {/* Like Animation Overlay */}
      {showHeart && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
          <Heart className="w-24 h-24 text-white fill-white animate-reel-like opacity-0 scale-0" />
        </div>
      )}

      {/* Volume Icon Overlay - Only show when tapped */}
      <div className={cn(
        "absolute inset-0 flex items-center justify-center pointer-events-none z-20 transition-opacity duration-300",
        showVolumeIcon ? "opacity-100" : "opacity-0"
      )}>
        <div className="bg-black/60 p-4 rounded-full backdrop-blur-sm">
           {muted ? <VolumeX className="w-10 h-10 text-white" /> : <Volume2 className="w-10 h-10 text-white" />}
        </div>
      </div>

      {/* Seek Feedback Overlay (Invisible Double Tap) */}
      {showSeekFeedback && (
        <div className={cn(
          "absolute inset-0 flex items-center pointer-events-none z-20",
          showSeekFeedback === 'forward' ? "justify-end pr-12" : "justify-start pl-12"
        )}>
          <div className="bg-black/70 px-6 py-4 rounded-2xl backdrop-blur-md flex items-center gap-3 animate-in fade-in zoom-in duration-200">
            <div className="flex gap-1">
              {Array.from({ length: Math.min(seekTapCount, 3) }).map((_, i) => (
                <div key={i} className="w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-b-[16px] border-b-white rotate-90" 
                  style={{ 
                    transform: showSeekFeedback === 'forward' ? 'rotate(90deg)' : 'rotate(-90deg)',
                    opacity: 1 - (i * 0.2)
                  }}
                />
              ))}
            </div>
            <span className="text-white text-lg font-bold">
              {seekTapCount * 10}s
            </span>
          </div>
        </div>
      )}

      {/* Premium Lock Overlay */}
      {!hasAccess && (
        <div className="absolute inset-0 z-[100] bg-black/90 backdrop-blur-xl flex flex-col items-center justify-center p-6 text-center space-y-6">
          <div className="relative">
            <div className="w-24 h-24 bg-primary/20 rounded-3xl flex items-center justify-center border border-primary/30 shadow-2xl animate-pulse">
              <Lock className="w-12 h-12 text-primary" />
            </div>
            <div className="absolute -top-2 -right-2 bg-yellow-500 rounded-full p-2 shadow-lg border-4 border-black">
              <Sparkles className="w-5 h-5 text-white fill-white" />
            </div>
          </div>

          <div className="space-y-2">
            <h2 className="text-2xl font-black text-white uppercase italic tracking-tight">
              Premium Content
            </h2>
            <p className="text-muted-foreground text-sm max-w-xs">
              Upgrade to Premium to unlock this exclusive reel and access all premium content
            </p>
          </div>

          <Button
            onClick={() => navigate('/premium')}
            className="bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-600/90 text-white px-8 py-6 rounded-2xl font-black uppercase italic tracking-tight shadow-2xl shadow-primary/30 border border-white/20 active:scale-95 transition-all"
          >
            <Sparkles className="w-5 h-5 mr-2 fill-white" />
            Upgrade to Premium
          </Button>
        </div>
      )}

      {/* Overlay Background */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20 pointer-events-none" />

      {/* Premium Badge (only if has access) */}
      {hasAccess && reel.is_premium && (
        <div className="absolute top-6 right-6 z-10 bg-primary/80 backdrop-blur-md text-white px-3 py-1.5 rounded-xl border border-white/20 flex items-center gap-2 shadow-2xl animate-pulse">
          <Lock className="w-4 h-4" />
          <span className="text-[10px] font-black uppercase tracking-widest italic">Premium</span>
        </div>
      )}

      {/* Admin Delete Button */}
      {isAdmin && onDelete && (
        <button
          onClick={() => onDelete(reel.id)}
          className={cn(
            "absolute top-6 right-6 z-20 w-10 h-10 rounded-full bg-destructive/90 backdrop-blur-md flex items-center justify-center text-white hover:bg-destructive transition-all shadow-lg border border-white/20",
            hasAccess && reel.is_premium && "top-20"
          )}
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
          </svg>
        </button>
      )}

      {/* Action Buttons (Right) - Compact Design */}
      {/* Action Icons - Right Side (Above Seekbar) */}
      {hasAccess && (
        <>
          <div className="absolute right-2 bottom-40 flex flex-col items-center gap-3 z-10">
            <div className="flex flex-col items-center gap-0.5">
              <button
                onClick={handleLike}
                disabled={isLikeLoading}
                className={cn(
                  "w-10 h-10 flex items-center justify-center rounded-full bg-black/30 backdrop-blur-md transition-all active:scale-125 hover:bg-black/50",
                  isLiked ? "text-primary scale-110" : "text-white"
                )}
              >
                <Heart className={cn("w-5 h-5", isLiked && "fill-current")} />
              </button>
              <span className="text-white text-xs font-bold drop-shadow-lg">{likesCount}</span>
            </div>

            <div className="flex flex-col items-center gap-0.5">
              <button 
                onClick={() => setCommentsOpen(true)}
                className="w-10 h-10 flex items-center justify-center rounded-full bg-black/30 backdrop-blur-sm hover:bg-black/50 transition-all"
              >
                <MessageCircle className="w-5 h-5 text-white" />
              </button>
              <span className="text-white text-xs font-bold drop-shadow-lg">{reel.comments_count}</span>
            </div>

            <div className="flex flex-col items-center gap-0.5">
               <div className="w-10 h-10 flex items-center justify-center rounded-full bg-black/30 backdrop-blur-md">
                 <Eye className="w-4 h-4 text-white" />
               </div>
               <span className="text-white text-xs font-bold drop-shadow-lg">{reel.views_count}</span>
            </div>

            {/* Sound Icon - Repositioned to Bottom Right */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setMuted(prev => !prev);
              }}
              className="w-10 h-10 flex items-center justify-center rounded-full bg-black/70 backdrop-blur-md hover:bg-black/90 transition-all active:scale-95 border-2 border-white/30 shadow-2xl"
              aria-label={muted ? "Unmute" : "Mute"}
            >
              {muted ? (
                <VolumeX className="w-5 h-5 text-white" />
              ) : (
                <Volume2 className="w-5 h-5 text-white" />
              )}
            </button>
          </div>

          {/* Video Progress Seekbar - Above Username */}
          <div className="absolute bottom-28 left-0 right-0 z-10 px-3">
            <div
              className="relative h-1.5 bg-white/30 rounded-full overflow-hidden cursor-pointer backdrop-blur-sm shadow-lg"
              onClick={handleSeek}
              onMouseDown={handleSeekStart}
              onMouseUp={handleSeekEnd}
              onTouchStart={handleSeekStart}
              onTouchEnd={handleSeekEnd}
            >
              {/* Progress Bar */}
              <div
                className="absolute top-0 left-0 h-full bg-white rounded-full transition-all duration-100 shadow-sm"
                style={{ width: `${progress}%` }}
              />
              
              {/* Seek Handle */}
              <div
                className="absolute top-1/2 -translate-y-1/2 w-3.5 h-3.5 bg-white rounded-full shadow-xl transition-all duration-100 border-2 border-white/50"
                style={{ left: `calc(${progress}% - 7px)` }}
              />
            </div>
          </div>

          {/* Bottom Info (Left) - Below Seekbar */}
          <div className="absolute left-3 right-16 bottom-5 z-10 flex flex-col gap-2.5">
            <div className="flex items-center gap-2.5">
              <Avatar className="w-8 h-8 border-2 border-primary ring-2 ring-primary/20 ring-offset-2 ring-offset-transparent">
                <AvatarImage src={reel.profiles?.profile_image || ''} />
                <AvatarFallback>{reel.profiles?.username?.[0]?.toUpperCase()}</AvatarFallback>
              </Avatar>
              <span className="text-section font-bold text-white drop-shadow-md">
                {reel.profiles?.username}
              </span>
              <button className="px-3 py-1.5 rounded-xl border border-white text-white text-[11px] font-black uppercase italic tracking-tighter bg-white/10 backdrop-blur-sm hover:bg-white hover:text-black transition-all">
                Follow
              </button>
            </div>

            {reel.caption && (
              <p className="text-normal text-white line-clamp-2 drop-shadow-md leading-snug font-medium">
                {reel.caption}
              </p>
            )}
          </div>

          {/* Music Disk Animation */}
          <div className="absolute right-3 bottom-5 z-10">
            <div className="w-8 h-8 rounded-full bg-gradient-to-r from-gray-800 via-gray-900 to-black p-1 animate-spin-slow shadow-lg border border-white/20">
               <Avatar className="w-full h-full">
                <AvatarImage src={reel.profiles?.profile_image || ''} />
              </Avatar>
            </div>
          </div>
        </>
      )}

      <FullScreenViewer
        media={mediaItems}
        initialIndex={0}
        open={viewerOpen}
        onOpenChange={setViewerOpen}
      />

      <CommentsDialog
        open={commentsOpen}
        onOpenChange={setCommentsOpen}
        postId={reel.id}
        commentsCount={reel.comments_count}
      />
    </div>
  );
}
