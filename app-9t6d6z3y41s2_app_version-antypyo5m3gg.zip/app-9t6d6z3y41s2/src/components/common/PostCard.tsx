import { Trash2, Heart, MessageCircle, Eye, Download, Lock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import type { Post, MediaItem } from '@/types';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { SwipeableMediaGrid } from '@/components/media/SwipeableMediaGrid';
import { FullScreenViewer } from '@/components/media/FullScreenViewer';
import { useEffect, useState, useRef } from 'react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface PostCardProps {
  post: Post;
  onDelete?: (postId: string) => void;
}

export function PostCard({ post, onDelete }: PostCardProps) {
  const { user, isAdmin, isApproved, isPremium } = useAuth();
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(post.likes_count);
  const [viewsCount, setViewsCount] = useState(post.views_count);
  const [isLikeLoading, setIsLikeLoading] = useState(false);
  const [viewerOpen, setViewerOpen] = useState(false);
  const [selectedMediaIndex, setSelectedMediaIndex] = useState(0);
  const cardRef = useRef<HTMLDivElement>(null);
  const [hasViewed, setHasViewed] = useState(false);

  // Prepare media items array
  const mediaItems: MediaItem[] = post.media_items && post.media_items.length > 0
    ? post.media_items
    : [{ url: post.media_url, type: post.media_type }];

  // Check if user has access to premium content
  const hasAccess = !post.is_premium || isPremium || isAdmin;

  const handleMediaClick = (index: number) => {
    if (!hasAccess) {
      toast.error('Upgrade to Premium to view this content');
      return;
    }
    // Prevent any scroll behavior
    window.scrollTo({ top: window.scrollY, behavior: 'auto' });
    setSelectedMediaIndex(index);
    setViewerOpen(true);
  };

  useEffect(() => {
    if (user) {
      api.isLiked(user.id, post.id).then(setIsLiked);
    }
  }, [user, post.id]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasViewed) {
          setHasViewed(true);
          api.incrementViews(post.id).then(() => setViewsCount((v: number) => v + 1));
        }
      },
      { threshold: 0.5 }
    );

    if (cardRef.current) {
      observer.observe(cardRef.current);
    }

    return () => observer.disconnect();
  }, [post.id, hasViewed]);

  const handleLike = async () => {
    if (!user || !isApproved) {
      toast.error('You must be an approved user to like posts');
      return;
    }
    if (isLikeLoading) return;

    setIsLikeLoading(true);
    const liked = await api.toggleLike(user.id, post.id);
    setIsLiked(liked);
    setLikesCount((prev: number) => (liked ? prev + 1 : prev - 1));
    setIsLikeLoading(false);
  };

  const isOwner = user?.id === post.user_id;

  return (
    <>
      <Card 
        ref={cardRef} 
        className="w-full bg-card border-border overflow-hidden rounded-xl shadow-card hover:shadow-hover transition-all duration-300 group"
        onContextMenu={(e) => e.preventDefault()}
      >
        <CardHeader className="flex flex-row items-center justify-between p-2 space-y-0">
          <div className="flex items-center gap-1.5">
            <Avatar className="w-7 h-7 ring-2 ring-primary/20 ring-offset-1 ring-offset-card transition-transform group-hover:scale-110">
              <AvatarImage src={post.profiles?.profile_image || ''} alt={post.profiles?.username} />
              <AvatarFallback>{post.profiles?.username?.[0]?.toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="flex flex-col">
              <span className="text-section font-bold leading-none group-hover:text-primary transition-colors">{post.profiles?.username}</span>
              <span className="text-small text-muted-foreground font-medium uppercase tracking-wider mt-0.5">
                {formatDistanceToNow(new Date(post.created_at), { addSuffix: true })}
              </span>
            </div>
          </div>

          {(isOwner || isAdmin) && (
            <Button
              variant="ghost"
              size="icon"
              className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors rounded-lg h-6.5 w-6.5"
              onClick={() => onDelete?.(post.id)}
            >
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          )}
        </CardHeader>

        <CardContent className="p-0 relative overflow-hidden">
          {post.is_premium && (
            <div className="absolute top-2 right-2 z-10 bg-primary/90 text-white px-2 py-0.5 rounded-lg shadow-lg border border-white/20 flex items-center gap-1 backdrop-blur-md">
              <Lock className="w-3 h-3" />
              <span className="text-xs font-black uppercase tracking-widest">Premium</span>
            </div>
          )}
          
          <SwipeableMediaGrid 
            media={mediaItems} 
            onMediaClick={handleMediaClick}
            isPremium={post.is_premium}
            hasAccess={hasAccess}
          />
        </CardContent>

        <CardFooter className="flex flex-col p-2 gap-1">
          {post.caption && (
            <p className="text-normal text-foreground/90 w-full line-clamp-2 leading-snug">
              <span className="font-bold mr-1">{post.profiles?.username}</span>
              {post.caption}
            </p>
          )}

          <div className="flex items-center justify-between w-full pt-1 border-t border-border/50">
            <div className="flex items-center gap-3">
              <button
                onClick={handleLike}
                disabled={isLikeLoading}
                className={cn(
                  "flex items-center gap-1 transition-all active:scale-125",
                  isLiked ? "text-primary scale-110" : "text-muted-foreground hover:text-primary"
                )}
              >
                <Heart className={cn("w-5 h-5", isLiked && "fill-current")} />
                <span className="text-normal font-bold">{likesCount}</span>
              </button>
              <button className="flex items-center gap-1 text-muted-foreground hover:text-primary transition-all">
                <MessageCircle className="w-5 h-5" />
                <span className="text-normal font-bold">{post.comments_count}</span>
              </button>
            </div>

            <div className="flex items-center gap-1 text-muted-foreground">
              <Eye className="w-4 h-4" />
              <span className="text-small font-bold">{viewsCount}</span>
            </div>
          </div>
        </CardFooter>
      </Card>

      <FullScreenViewer
        media={mediaItems}
        initialIndex={selectedMediaIndex}
        open={viewerOpen}
        onOpenChange={setViewerOpen}
      />
    </>
  );
}
