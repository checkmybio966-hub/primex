import { Play, Plus } from 'lucide-react';
import type { MediaItem } from '@/types';
import { cn } from '@/lib/utils';

interface TwitterMediaGridProps {
  media: MediaItem[];
  onMediaClick: (index: number) => void;
  isPremium?: boolean;
  hasAccess?: boolean;
}

export function TwitterMediaGrid({ media, onMediaClick, isPremium, hasAccess = true }: TwitterMediaGridProps) {
  const count = media.length;

  if (count === 0) return null;

  // Single media - full width
  if (count === 1) {
    return (
      <div 
        className="relative w-full aspect-[4/3] rounded-xl overflow-hidden bg-black/40 cursor-pointer group"
        onClick={() => onMediaClick(0)}
      >
        <MediaItem item={media[0]} isPremium={isPremium} hasAccess={hasAccess} />
      </div>
    );
  }

  // Two media - side by side
  if (count === 2) {
    return (
      <div className="grid grid-cols-2 gap-1.5">
        {media.map((item, index) => (
          <div
            key={index}
            className="relative aspect-[4/3] rounded-lg overflow-hidden bg-black/40 cursor-pointer group"
            onClick={() => onMediaClick(index)}
          >
            <MediaItem item={item} isPremium={isPremium} hasAccess={hasAccess} />
          </div>
        ))}
      </div>
    );
  }

  // Three media - 2 top, 1 bottom
  if (count === 3) {
    return (
      <div className="grid grid-cols-2 gap-1.5">
        <div
          className="col-span-2 relative aspect-[16/9] rounded-lg overflow-hidden bg-black/40 cursor-pointer group"
          onClick={() => onMediaClick(0)}
        >
          <MediaItem item={media[0]} isPremium={isPremium} hasAccess={hasAccess} />
        </div>
        {media.slice(1).map((item, index) => (
          <div
            key={index + 1}
            className="relative aspect-[4/3] rounded-lg overflow-hidden bg-black/40 cursor-pointer group"
            onClick={() => onMediaClick(index + 1)}
          >
            <MediaItem item={item} isPremium={isPremium} hasAccess={hasAccess} />
          </div>
        ))}
      </div>
    );
  }

  // Four or more media - 2x2 grid with +N overlay
  return (
    <div className="grid grid-cols-2 gap-1.5">
      {media.slice(0, 4).map((item, index) => (
        <div
          key={index}
          className="relative aspect-[4/3] rounded-lg overflow-hidden bg-black/40 cursor-pointer group"
          onClick={() => onMediaClick(index)}
        >
          <MediaItem item={item} isPremium={isPremium} hasAccess={hasAccess} />
          
          {/* +N Overlay for 4th item */}
          {index === 3 && count > 4 && (
            <div className="absolute inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-10">
              <div className="text-center">
                <Plus className="w-6 h-6 text-white mx-auto mb-0.5" />
                <span className="text-white text-xl font-black">
                  {count - 4}
                </span>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

interface MediaItemProps {
  item: MediaItem;
  isPremium?: boolean;
  hasAccess?: boolean;
}

function MediaItem({ item, isPremium, hasAccess }: MediaItemProps) {
  const isBlurred = isPremium && !hasAccess;

  return (
    <>
      {item.type === 'image' ? (
        <img
          src={item.url}
          alt="Post media"
          loading="lazy"
          className={cn(
            "w-full h-full object-cover transition-transform group-hover:scale-105",
            isBlurred && "blur-xl"
          )}
        />
      ) : (
        <>
          <video
            src={item.url}
            className={cn(
              "w-full h-full object-cover",
              isBlurred && "blur-xl"
            )}
            muted
            playsInline
            preload="metadata"
            poster={`${item.url}#t=0.1`}
          />
          <div className="absolute inset-0 flex items-center justify-center bg-black/20 pointer-events-none">
            <div className="w-10 h-10 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center shadow-lg">
              <Play className="w-5 h-5 text-black fill-black ml-0.5" />
            </div>
          </div>
        </>
      )}

      {/* Premium Lock Overlay */}
      {isBlurred && (
        <div className="absolute inset-0 bg-black/40 backdrop-blur-md flex flex-col items-center justify-center z-20">
          <div className="w-12 h-12 rounded-full bg-primary/20 backdrop-blur-sm flex items-center justify-center mb-2 border-2 border-primary/50">
            <svg className="w-6 h-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <span className="text-white font-black text-xs uppercase tracking-wider">Premium</span>
        </div>
      )}

      {/* Hover Overlay */}
      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors pointer-events-none" />
    </>
  );
}
