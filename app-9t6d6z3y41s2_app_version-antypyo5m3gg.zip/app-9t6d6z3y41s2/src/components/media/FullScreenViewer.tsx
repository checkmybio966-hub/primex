import { useState, useEffect } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';
import { TransformWrapper, TransformComponent } from 'react-zoom-pan-pinch';
import Video from '@/components/ui/video';
import type { MediaItem } from '@/types';
import { cn } from '@/lib/utils';

interface FullScreenViewerProps {
  media: MediaItem[];
  initialIndex?: number;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function FullScreenViewer({ media, initialIndex = 0, open, onOpenChange }: FullScreenViewerProps) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [scale, setScale] = useState(1);
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);

  // Minimum swipe distance (in px)
  const minSwipeDistance = 50;

  // Reset scroll position and index when opening
  useEffect(() => {
    if (open) {
      setCurrentIndex(initialIndex);
      setScale(1);
      // Reset scroll position to top
      window.scrollTo(0, 0);
      document.body.style.overflow = 'hidden';
      document.body.style.position = 'fixed';
      document.body.style.top = '0';
      document.body.style.left = '0';
      document.body.style.right = '0';
    } else {
      // Restore scroll
      document.body.style.overflow = '';
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.left = '';
      document.body.style.right = '';
    }
  }, [initialIndex, open]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!open) return;
      
      if (e.key === 'ArrowLeft') {
        handlePrevious();
      } else if (e.key === 'ArrowRight') {
        handleNext();
      } else if (e.key === 'Escape') {
        onOpenChange(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [open, currentIndex, media.length]);

  const handlePrevious = () => {
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : media.length - 1));
    setScale(1);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev < media.length - 1 ? prev + 1 : 0));
    setScale(1);
  };

  // Touch handlers for swipe navigation
  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;

    if (isLeftSwipe) {
      handleNext();
    } else if (isRightSwipe) {
      handlePrevious();
    }
  };

  if (!media || media.length === 0) return null;

  const currentMedia = media[currentIndex];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent 
        className="max-w-[100vw] w-screen h-screen p-0 bg-black/95 border-none rounded-none fixed inset-0 m-0"
        onPointerDownOutside={(e) => e.preventDefault()}
        style={{ top: 0, left: 0, transform: 'none' }}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
      >
        {/* Close Button - Top Left Only */}
        <Button
          variant="ghost"
          size="icon"
          onClick={() => onOpenChange(false)}
          className="absolute top-4 left-4 z-50 text-white hover:bg-white/20 rounded-full w-12 h-12 bg-black/70 backdrop-blur-md border-2 border-white/30 shadow-2xl transition-all hover:scale-110"
        >
          <X className="w-6 h-6 stroke-[2.5]" />
        </Button>

        {/* Media Counter - Top Center */}
        {media.length > 1 && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 bg-black/70 backdrop-blur-md text-white px-4 py-2 rounded-full text-sm font-medium border border-white/20">
            {currentIndex + 1} / {media.length}
          </div>
        )}

        {/* Main Content */}
        <div className="w-full h-full flex items-center justify-center relative">
          {currentMedia.type === 'image' ? (
            <TransformWrapper
              initialScale={1}
              minScale={0.5}
              maxScale={4}
              centerOnInit
              onTransformed={(ref) => setScale(ref.state.scale)}
            >
              {({ zoomIn, zoomOut, resetTransform }) => (
                <>
                  <TransformComponent
                    wrapperClass="w-full h-full flex items-center justify-center"
                    contentClass="w-full h-full flex items-center justify-center"
                  >
                    <img
                      src={currentMedia.url}
                      alt={`Media ${currentIndex + 1}`}
                      className="max-w-full max-h-full object-contain select-none"
                      draggable={false}
                    />
                  </TransformComponent>
                </>
              )}
            </TransformWrapper>
          ) : (
            <div className="w-full h-full flex items-center justify-center p-8">
              <Video
                src={currentMedia.url}
                className="max-w-full max-h-full"
                autoPlay
                controls
              />
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
