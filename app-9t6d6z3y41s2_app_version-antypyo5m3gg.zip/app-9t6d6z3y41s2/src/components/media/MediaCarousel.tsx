import { useState } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Pagination, Keyboard } from 'swiper/modules';
import type { Swiper as SwiperType } from 'swiper';
import Video from '@/components/ui/video';
import { Play, Maximize2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { MediaItem } from '@/types';

// Import Swiper styles
import 'swiper/css';
import 'swiper/css/pagination';

interface MediaCarouselProps {
  media: MediaItem[];
  onMediaClick?: (index: number) => void;
  autoplay?: boolean;
  className?: string;
}

export function MediaCarousel({ media, onMediaClick, autoplay = false, className }: MediaCarouselProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [swiper, setSwiper] = useState<SwiperType | null>(null);

  if (!media || media.length === 0) return null;

  // Single media - no carousel needed
  if (media.length === 1) {
    const item = media[0];
    return (
      <div 
        className={cn("relative w-full h-full bg-black/40 flex items-center justify-center group cursor-pointer", className)}
        onClick={() => onMediaClick?.(0)}
      >
        {item.type === 'image' ? (
          <>
            <img
              src={item.url}
              alt="Media"
              className="w-full h-full object-contain pointer-events-none select-none"
              loading="lazy"
              onDragStart={(e) => e.preventDefault()}
            />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center">
              <Maximize2 className="w-12 h-12 text-white opacity-0 group-hover:opacity-100 transition-opacity drop-shadow-lg" />
            </div>
          </>
        ) : (
          <>
            <Video
              src={item.url}
              className="w-full h-full object-contain"
              autoPlay={autoplay}
              muted
              loop
            />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center pointer-events-none">
              <Play className="w-16 h-16 text-white opacity-0 group-hover:opacity-80 transition-opacity drop-shadow-lg" />
            </div>
          </>
        )}
      </div>
    );
  }

  // Multiple media - use carousel
  return (
    <div className={cn("relative w-full h-full", className)}>
      <Swiper
        modules={[Pagination, Keyboard]}
        spaceBetween={0}
        slidesPerView={1}
        pagination={{ 
          clickable: true,
          dynamicBullets: false,
        }}
        keyboard={{ enabled: true }}
        onSwiper={setSwiper}
        onSlideChange={(swiper) => setActiveIndex(swiper.activeIndex)}
        className="w-full h-full media-carousel"
      >
        {media.map((item, index) => (
          <SwiperSlide key={index}>
            <div 
              className="w-full h-full bg-black/40 flex items-center justify-center group cursor-pointer"
              onClick={() => onMediaClick?.(index)}
            >
              {item.type === 'image' ? (
                <div className="swiper-zoom-container w-full h-full flex items-center justify-center">
                  <img
                    src={item.url}
                    alt={`Media ${index + 1}`}
                    className="w-full h-full object-contain pointer-events-none select-none"
                    loading="lazy"
                    onDragStart={(e) => e.preventDefault()}
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center pointer-events-none">
                    <Maximize2 className="w-12 h-12 text-white opacity-0 group-hover:opacity-100 transition-opacity drop-shadow-lg" />
                  </div>
                </div>
              ) : (
                <>
                  <Video
                    src={item.url}
                    className="w-full h-full object-contain"
                    autoPlay={autoplay && index === activeIndex}
                    muted
                    loop
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center pointer-events-none">
                    <Play className="w-16 h-16 text-white opacity-0 group-hover:opacity-80 transition-opacity drop-shadow-lg" />
                  </div>
                </>
              )}
            </div>
          </SwiperSlide>
        ))}
      </Swiper>

      {/* Media counter */}
      <div className="absolute top-4 right-4 z-10 bg-black/60 backdrop-blur-md text-white px-3 py-1.5 rounded-full text-xs font-bold">
        {activeIndex + 1} / {media.length}
      </div>
    </div>
  );
}
