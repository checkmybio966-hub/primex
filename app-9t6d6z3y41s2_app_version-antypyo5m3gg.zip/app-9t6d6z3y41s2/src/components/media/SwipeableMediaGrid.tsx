import { useState, useRef } from 'react';
import { Play } from 'lucide-react';
import type { MediaItem } from '@/types';
import { cn } from '@/lib/utils';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Pagination } from 'swiper/modules';
import type { Swiper as SwiperType } from 'swiper';
import 'swiper/css';
import 'swiper/css/pagination';

interface SwipeableMediaGridProps {
  media: MediaItem[];
  onMediaClick: (index: number) => void;
  isPremium?: boolean;
  hasAccess?: boolean;
}

export function SwipeableMediaGrid({ media, onMediaClick, isPremium, hasAccess = true }: SwipeableMediaGridProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  const swiperRef = useRef<SwiperType | null>(null);

  if (media.length === 0) return null;

  // Instagram-style smart layout based on media count
  const mediaCount = media.length;

  // 1 IMAGE: Full width single image
  if (mediaCount === 1) {
    return (
      <div 
        className="relative w-full rounded-xl overflow-hidden bg-black cursor-pointer group"
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          onMediaClick(0);
        }}
      >
        <MediaItemContent item={media[0]} isPremium={isPremium} hasAccess={hasAccess} />
      </div>
    );
  }

  // 2 IMAGES: Side by side (50% + 50%)
  if (mediaCount === 2) {
    return (
      <div className="grid grid-cols-2 gap-1 rounded-xl overflow-hidden">
        {media.map((item, index) => (
          <div
            key={index}
            className="relative aspect-square bg-black cursor-pointer group overflow-hidden"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onMediaClick(index);
            }}
          >
            <MediaItemContent item={item} isPremium={isPremium} hasAccess={hasAccess} isGrid />
          </div>
        ))}
      </div>
    );
  }

  // 3 IMAGES: Left 50% large, right 2 stacked (25% + 25%)
  if (mediaCount === 3) {
    return (
      <div className="grid grid-cols-2 gap-1 rounded-xl overflow-hidden" style={{ height: '400px' }}>
        {/* Left: Large image (50%) */}
        <div
          className="relative bg-black cursor-pointer group overflow-hidden"
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            onMediaClick(0);
          }}
        >
          <MediaItemContent item={media[0]} isPremium={isPremium} hasAccess={hasAccess} isGrid />
        </div>

        {/* Right: 2 stacked images (25% + 25%) */}
        <div className="grid grid-rows-2 gap-1">
          {media.slice(1, 3).map((item, index) => (
            <div
              key={index + 1}
              className="relative bg-black cursor-pointer group overflow-hidden"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onMediaClick(index + 1);
              }}
            >
              <MediaItemContent item={item} isPremium={isPremium} hasAccess={hasAccess} isGrid />
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 4+ IMAGES: 2x2 grid with "+X more" overlay
  if (mediaCount >= 4) {
    const remainingCount = mediaCount - 4;
    return (
      <div className="grid grid-cols-2 gap-1 rounded-xl overflow-hidden">
        {media.slice(0, 4).map((item, index) => (
          <div
            key={index}
            className="relative aspect-square bg-black cursor-pointer group overflow-hidden"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onMediaClick(index);
            }}
          >
            <MediaItemContent item={item} isPremium={isPremium} hasAccess={hasAccess} isGrid />
            
            {/* "+X more" overlay on 4th image */}
            {index === 3 && remainingCount > 0 && (
              <div className="absolute inset-0 bg-black/70 flex items-center justify-center backdrop-blur-sm">
                <span className="text-white text-3xl font-bold">+{remainingCount}</span>
              </div>
            )}
          </div>
        ))}
      </div>
    );
  }

  return null;
}

interface MediaItemContentProps {
  item: MediaItem;
  isPremium?: boolean;
  hasAccess?: boolean;
  isGrid?: boolean;
}

function MediaItemContent({ item, isPremium, hasAccess = true, isGrid = false }: MediaItemContentProps) {
  const isVideo = item.type === 'video';

  return (
    <>
      {isVideo ? (
        <div className="relative w-full h-full">
          {/* Video Thumbnail */}
          {item.thumbnail_url ? (
            <img
              src={item.thumbnail_url}
              alt="Video thumbnail"
              className={cn(
                "w-full h-full bg-black",
                isGrid ? "object-cover" : "object-contain max-h-[600px]"
              )}
            />
          ) : (
            <video
              src={item.url}
              className={cn(
                "w-full h-full bg-black",
                isGrid ? "object-cover" : "object-contain max-h-[600px]"
              )}
              preload="metadata"
            />
          )}
          
          {/* Play Button Overlay */}
          <div className="absolute inset-0 flex items-center justify-center bg-black/20 group-hover:bg-black/30 transition-colors">
            <div className="w-14 h-14 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform">
              <Play className="w-7 h-7 text-black fill-black ml-1" />
            </div>
          </div>
        </div>
      ) : (
        <img
          src={item.url}
          alt="Post media"
          className={cn(
            "w-full h-full bg-black group-hover:scale-105 transition-transform duration-300",
            isGrid ? "object-cover" : "object-contain max-h-[600px]"
          )}
        />
      )}

      {/* Premium Blur Overlay */}
      {isPremium && !hasAccess && (
        <div className="absolute inset-0 backdrop-blur-xl bg-black/40 flex items-center justify-center">
          <div className="text-center space-y-2">
            <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto border border-primary/30">
              <Play className="w-6 h-6 text-primary" />
            </div>
            <p className="text-white text-xs font-bold uppercase">Premium Only</p>
          </div>
        </div>
      )}
    </>
  );
}
