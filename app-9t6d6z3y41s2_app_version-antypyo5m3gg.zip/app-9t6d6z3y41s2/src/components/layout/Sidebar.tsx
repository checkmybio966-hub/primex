import { Home, Play, MessageCircle, User, ShieldCheck, Zap, LogOut, Sparkles, FolderOpen } from 'lucide-react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

export function Sidebar() {
  const { isAdmin, isPremium, profile, signOut } = useAuth();
  const navigate = useNavigate();

  const navItems = [
    { icon: Home, label: 'Home', path: '/' },
    { icon: Play, label: 'Reels', path: '/reels' },
    { icon: MessageCircle, label: 'Chat', path: '/chat' },
    { icon: User, label: 'Profile', path: '/profile' },
    ...(isAdmin ? [{ icon: ShieldCheck, label: 'Admin', path: '/admin' }] : [])
  ];

  const handleLogout = async () => {
    await signOut();
    navigate('/login', { replace: true });
  };

  return (
    <aside className="hidden md:flex flex-col h-screen w-60 border-r border-border bg-card/40 sticky top-0 left-0 z-50">
      <div className="flex items-center gap-2 p-4">
        <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center border border-primary/20 group hover:scale-110 transition-transform shadow-lg shadow-primary/5">
           <Zap className="w-5 h-5 text-primary fill-primary" />
        </div>
        <span className="heading-main text-lg tracking-tighter italic">Primex</span>
      </div>

      <nav className="flex-1 flex flex-col gap-1 p-3 mt-2">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 p-3 rounded-lg transition-all hover:bg-muted group border border-transparent",
                isActive ? "bg-primary/10 text-primary border-primary/20 shadow-sm" : "text-muted-foreground hover:text-foreground hover:border-border/50"
              )
            }
          >
            <item.icon className={cn("w-5 h-5 transition-transform group-hover:scale-110")} />
            <span className="text-normal font-bold uppercase italic tracking-tighter">{item.label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="px-3 mb-4">
        {(!isPremium && profile?.subscription_status !== 'active') && (
          <Button 
            className="w-full h-11 bg-gradient-primary border-none rounded-xl btn-standard shadow-xl hover:scale-[1.02] transition-transform flex items-center justify-center gap-2 group mb-3 px-4 text-small"
            onClick={() => navigate('/premium')}
          >
            <Sparkles className="w-5 h-5 animate-pulse" />
            GET ACCESS
          </Button>
        )}
      </div>

      <div className="p-3 border-t border-border/50 mt-auto">
        <Button 
          variant="ghost" 
          className="w-full flex justify-start gap-3 p-3 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-all h-11 px-3"
          onClick={handleLogout}
        >
          <LogOut className="w-5 h-5" />
          <span className="text-normal font-bold uppercase italic tracking-tighter">Logout</span>
        </Button>
      </div>
    </aside>
  );
}
