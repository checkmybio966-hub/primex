import { Header } from './Header';
import { Sidebar } from './Sidebar';
import { BottomNav } from './BottomNav';
import { Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useEffect, useRef } from 'react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export function Layout() {
  const { user, profile } = useAuth();
  const prevStatusRef = useRef<string | null>(null);
  const location = useLocation();
  const isReelsPage = location.pathname === '/reels';
  const isCreatePage = location.pathname === '/create';

  useEffect(() => {
    if (profile && prevStatusRef.current === 'payment_pending' && profile.subscription_status === 'active') {
      toast.success('Your premium has been activated.', {
        duration: 5000,
        icon: '👑'
      });
    }
    if (profile) {
      prevStatusRef.current = profile.subscription_status;
    }
  }, [profile]);

  if (!user) {
    return (
      <main className="min-h-screen bg-background">
        <Outlet />
      </main>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex overflow-hidden">
      {/* Desktop Sidebar - Hide on Reels/Create Page */}
      {(!isReelsPage && !isCreatePage) && <Sidebar />}

      <div className="flex-1 flex flex-col min-h-screen w-full relative">
        {/* Mobile Header - Hide on Reels/Create Page */}
        {(!isReelsPage && !isCreatePage) && (
          <div className="md:hidden sticky top-0 z-50">
            <Header />
          </div>
        )}

        <main className={cn(
          "flex-1 overflow-y-auto w-full mx-auto",
          (isReelsPage || isCreatePage) 
            ? "h-screen pb-0 max-w-none px-0" 
            : "pb-16 md:pb-3 max-w-4xl px-3 sm:px-4"
        )}>
          <Outlet />
        </main>

        {/* Mobile Nav - Always Fixed at Bottom */}
        {(!isReelsPage && !isCreatePage) && <BottomNav />}
      </div>
    </div>
  );
}
