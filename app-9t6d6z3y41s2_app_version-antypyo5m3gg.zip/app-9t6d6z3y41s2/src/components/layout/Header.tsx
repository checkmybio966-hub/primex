import { Bell, Zap, Home, Sparkles, FolderOpen, User, Crown } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { NavLink, useNavigate } from 'react-router-dom';
import { NotificationCenter } from '@/components/notifications/NotificationCenter';
import { cn } from '@/lib/utils';

export function Header() {
  const { isAdmin, isPremium } = useAuth();
  const navigate = useNavigate();

  const navLinks = [
    { icon: Home, label: 'Home', path: '/' },
    { icon: Sparkles, label: 'Premium', path: '/premium-feed' },
    { icon: FolderOpen, label: 'Files', path: '/files' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full bg-background/80 backdrop-blur-md border-b border-border/50 h-12 flex items-center px-3 md:px-4 justify-between shadow-sm">
      <div className="flex items-center gap-1.5 group cursor-pointer" onClick={() => navigate('/')}>
        <div className="w-7 h-7 bg-primary/10 rounded-lg flex items-center justify-center border border-primary/20 group-hover:scale-110 transition-transform shadow-lg shadow-primary/5">
          <Crown className="w-4.5 h-4.5 text-primary" />
        </div>
        <span className="heading-main hidden md:block text-lg tracking-tighter italic">Primex</span>
      </div>

      <nav className="flex items-center gap-0.5 md:gap-1">
        {navLinks.map((link) => (
          <NavLink
            key={link.path}
            to={link.path}
            className={({ isActive }) => cn(
              "flex items-center gap-1 px-2 py-1 rounded-lg text-meta font-black uppercase italic tracking-tighter transition-all hover:bg-muted/50",
              isActive ? "text-primary bg-primary/10" : "text-muted-foreground"
            )}
          >
            <link.icon className="w-3.5 h-3.5" />
            <span className="hidden sm:inline text-[11px]">{link.label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="flex items-center gap-1.5">
        <NotificationCenter />
        <NavLink to="/profile" className="p-1 rounded-full hover:bg-muted/50 transition-colors">
          <User className="w-4.5 h-4.5 text-foreground hover:text-primary transition-colors" />
        </NavLink>
      </div>
    </header>
  );
}
