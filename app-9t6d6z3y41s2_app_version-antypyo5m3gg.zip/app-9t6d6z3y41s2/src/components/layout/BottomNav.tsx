import { Home, Play, Gem, User, ShieldCheck, Plus } from 'lucide-react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';

export function BottomNav() {
  const { isAdmin } = useAuth();

  const navItems = [
    { icon: Home, label: 'Home', path: '/' },
    { icon: Play, label: 'Reels', path: '/reels' },
    ...(isAdmin ? [{ icon: Plus, label: 'Upload', path: '/upload', isUpload: true }] : []),
    { icon: Gem, label: 'Premium', path: '/premium-feed' },
    { icon: User, label: 'Profile', path: '/profile' },
    ...(isAdmin ? [{ icon: ShieldCheck, label: 'Admin', path: '/admin' }] : [])
  ];

  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 z-[100] md:hidden bg-card/98 backdrop-blur-xl border-t border-border/50 shadow-2xl"
      style={{
        height: '52px',
        paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 0px)',
        transform: 'translateZ(0)',
        willChange: 'transform',
        WebkitBackfaceVisibility: 'hidden',
        backfaceVisibility: 'hidden'
      }}
    >
      <div className="flex justify-around items-center h-full px-2">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              cn(
                "flex flex-col items-center gap-0.5 transition-all active:scale-90 h-full justify-center px-2 min-w-[50px]",
                isActive ? "text-primary" : "text-muted-foreground hover:text-foreground",
                (item as any).isUpload && "relative"
              )
            }
          >
            {(item as any).isUpload ? (
              <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center shadow-lg">
                <item.icon className="w-5 h-5 text-white" />
              </div>
            ) : (
              <>
                <item.icon className={cn("w-[18px] h-[18px]", item.path === '/premium-feed' ? "animate-pulse" : "")} />
                <span className="text-[9px] uppercase font-semibold tracking-tight leading-none">{item.label}</span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
