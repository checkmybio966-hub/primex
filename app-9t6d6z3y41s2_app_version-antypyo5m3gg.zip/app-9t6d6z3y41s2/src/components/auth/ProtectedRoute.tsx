import { ReactNode, useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';

interface ProtectedRouteProps {
  children: ReactNode;
  requirePremium?: boolean;
  requireAdmin?: boolean;
}

export function ProtectedRoute({ 
  children, 
  requirePremium = false, 
  requireAdmin = false 
}: ProtectedRouteProps) {
  const { user, isPremium, isAdmin, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [authorized, setAuthorized] = useState(false);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    if (loading) return;
    if (checked) return; // Prevent multiple checks

    if (!user) {
      toast.error('Please login to access this content');
      navigate('/login', { state: { from: location }, replace: true });
      setChecked(true);
      return;
    }

    if (requireAdmin && !isAdmin) {
      toast.error('Access denied. Administrator privileges required.');
      navigate('/', { replace: true });
      setChecked(true);
      return;
    }

    if (requirePremium && !isPremium && !isAdmin) {
      toast.error('Premium access required.');
      navigate('/premium', { replace: true });
      setChecked(true);
      return;
    }

    setAuthorized(true);
    setChecked(true);
  }, [user, isPremium, isAdmin, loading, navigate, requirePremium, requireAdmin, location, checked]);

  if (loading || !checked || !authorized) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  return <>{children}</>;
}
