import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import type { FileItem, Folder } from '@/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  FolderOpen, 
  FileText, 
  Image as ImageIcon, 
  Video as VideoIcon, 
  ChevronRight, 
  Upload, 
  Plus, 
  Loader2, 
  X, 
  ArrowLeft,
  FolderPlus,
  Trash2,
  Edit3
} from 'lucide-react';
import { toast } from 'sonner';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

interface FilePickerModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelect: (file: FileItem) => void;
  onUpload: (file: File) => Promise<void>;
}

function FilePreview({ url }: { url: string }) {
  const [signedUrl, setSignedUrl] = useState<string>('');
  
  useEffect(() => {
    const fetchUrl = async () => {
      try {
        const res = await api.getFileSignedUrl(url);
        setSignedUrl(res);
      } catch (e) {
        console.error(e);
      }
    };
    fetchUrl();
  }, [url]);

  if (!signedUrl) return <ImageIcon className="w-8 h-8 text-muted-foreground opacity-50" />;
  return <img src={signedUrl} alt="preview" className="w-full h-full object-cover pointer-events-none" />;
}

export function FilePickerModal({ open, onOpenChange, onSelect, onUpload }: FilePickerModalProps) {
  const { user, isPremium, isAdmin } = useAuth();
  const [folders, setFolders] = useState<Folder[]>([]);
  const [files, setFiles] = useState<FileItem[]>([]);
  const [currentFolder, setCurrentFolder] = useState<Folder | null>(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [isNewFolderOpen, setIsNewFolderOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');

  // Permission Check
  const canAccessCloud = isAdmin || isPremium;
  const canManageCloud = isAdmin;

  useEffect(() => {
    if (open && canAccessCloud) {
      fetchContent();
    } else if (!open) {
      setCurrentFolder(null);
    }
  }, [open, currentFolder, canAccessCloud]);

  const fetchContent = async () => {
    setLoading(true);
    try {
      const [filesData, foldersData] = await Promise.all([
        api.getFiles(currentFolder?.id),
        currentFolder ? Promise.resolve([]) : api.getFolders()
      ]);
      setFiles(filesData);
      setFolders(foldersData);
    } catch (error) {
      toast.error('Failed to load storage');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateFolder = async () => {
    if (!newFolderName || !user || !canManageCloud) return;
    try {
      await api.createFolder(newFolderName, user.id);
      toast.success('Folder created');
      setNewFolderName('');
      setIsNewFolderOpen(false);
      fetchContent();
    } catch (error) {
      toast.error('Failed to create folder');
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      if (user) {
         const uploadedFile = await api.uploadFile(
           user.id, 
           file, 
           file.name, 
           file.type, 
           canManageCloud ? currentFolder?.id || null : null
         );
         onSelect(uploadedFile);
      }
    } catch (error) {
      toast.error('Upload failed');
    } finally {
      setUploading(false);
    }
  };

  const getFileIcon = (type: string) => {
    if (type.includes('image')) return <ImageIcon className="w-8 h-8 text-blue-400" />;
    if (type.includes('video')) return <VideoIcon className="w-8 h-8 text-purple-400" />;
    return <FileText className="w-8 h-8 text-orange-400" />;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass border-border shadow-2xl rounded-[2.5rem] max-w-2xl p-0 overflow-hidden bg-background/95 backdrop-blur-xl">
        <DialogHeader className="p-6 border-b border-border/50 bg-muted/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-500/10 rounded-2xl border border-blue-500/20">
                <FolderOpen className="w-6 h-6 text-blue-500 fill-blue-500/20" />
              </div>
              <div className="flex flex-col text-left">
                <DialogTitle className="heading-main text-2xl text-blue-500">SECURE FILES</DialogTitle>
                <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Encrypted Cloud Storage</p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              {canManageCloud && (
                <>
                  <Button 
                    variant="outline" 
                    size="icon" 
                    onClick={() => setIsNewFolderOpen(!isNewFolderOpen)} 
                    className="rounded-xl h-12 w-12 border-border/50 hover:bg-muted/50"
                  >
                    <FolderPlus className="w-5 h-5" />
                  </Button>
                  <Button 
                    variant="default" 
                    size="icon" 
                    onClick={() => document.getElementById('modal-upload-input')?.click()}
                    className="rounded-xl h-12 w-12 bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-500/20"
                  >
                    {uploading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Upload className="w-5 h-5" />}
                  </Button>
                </>
              )}
              {!canManageCloud && (
                 <Button 
                    variant="default" 
                    className="rounded-xl h-12 px-6 bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-500/20 font-bold uppercase tracking-tight"
                    onClick={() => document.getElementById('modal-upload-input')?.click()}
                  >
                    {uploading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <Upload className="w-5 h-5 mr-2" />}
                    Upload File
                  </Button>
              )}
              <input id="modal-upload-input" type="file" className="hidden" onChange={handleFileUpload} />
            </div>
          </div>

          {isNewFolderOpen && canManageCloud && (
            <div className="mt-4 flex gap-2 animate-in slide-in-from-top-2">
              <Input 
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                placeholder="Folder Name"
                className="h-12 rounded-xl bg-background/50 border-border/50"
              />
              <Button onClick={handleCreateFolder} className="h-12 rounded-xl px-6 font-bold">Create</Button>
            </div>
          )}
        </DialogHeader>

        {canAccessCloud && (
          <div className="px-6 py-4 bg-muted/5 border-b border-border/30">
            <div className="flex items-center gap-2 p-1 bg-muted/30 border border-border/30 rounded-xl w-fit px-3">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setCurrentFolder(null)}
                className={cn(
                  "text-xs font-black uppercase italic tracking-tighter h-6 px-1 hover:bg-transparent",
                  !currentFolder ? "text-blue-500" : "text-muted-foreground"
                )}
              >
                Root
              </Button>
              {currentFolder && (
                <>
                  <ChevronRight className="w-3 h-3 text-muted-foreground shrink-0" />
                  <span className="text-xs font-black uppercase italic tracking-tighter text-blue-500">
                    {currentFolder.name}
                  </span>
                </>
              )}
            </div>
          </div>
        )}

        <div className="p-6 h-[400px] overflow-y-auto custom-scrollbar">
          {loading ? (
             <div className="grid grid-cols-3 gap-4">
               {[1,2,3,4,5,6].map(i => <Skeleton key={i} className="aspect-square rounded-2xl bg-muted/20" />)}
             </div>
          ) : (
            <>
              {canAccessCloud ? (
                <div className="space-y-6">
                  {!currentFolder && folders.length > 0 && (
                    <div className="grid grid-cols-3 gap-4">
                      {folders.map(folder => (
                        <div 
                          key={folder.id}
                          onClick={() => setCurrentFolder(folder)}
                          className="aspect-square rounded-[1.5rem] bg-muted/10 border border-border/30 flex flex-col items-center justify-center gap-3 cursor-pointer hover:bg-muted/20 hover:border-blue-500/30 transition-all group"
                        >
                           <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                             <FolderOpen className="w-6 h-6 text-blue-500 fill-blue-500/20" />
                           </div>
                           <p className="text-xs font-bold text-foreground/80 truncate max-w-[80%]">{folder.name}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {files.length > 0 ? (
                    <div className="grid grid-cols-3 gap-4">
                      {files.map(file => (
                        <div 
                          key={file.id}
                          onClick={() => onSelect(file)}
                          className="aspect-square rounded-[1.5rem] bg-card border border-border/30 overflow-hidden relative group cursor-pointer"
                        >
                           {file.file_type.includes('image') ? (
                             <FilePreview url={file.url} />
                           ) : (
                             <div className="w-full h-full flex flex-col items-center justify-center bg-muted/20 gap-2">
                                {getFileIcon(file.file_type)}
                                <p className="text-[10px] font-black uppercase text-muted-foreground truncate max-w-[80%]">{file.name}</p>
                             </div>
                           )}
                           <div className="absolute inset-0 bg-blue-600/80 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                              <Plus className="w-8 h-8 text-white" />
                           </div>
                           <div className="absolute bottom-2 left-2 right-2 bg-black/60 backdrop-blur-md rounded-lg p-1.5 opacity-100 group-hover:opacity-0 transition-opacity">
                              <p className="text-[9px] font-bold text-white truncate text-center">{file.name}</p>
                           </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    (!currentFolder && folders.length === 0 && files.length === 0) && (
                      <div className="flex flex-col items-center justify-center h-[300px] text-center opacity-40">
                        <div className="w-20 h-20 bg-muted/20 rounded-[2rem] flex items-center justify-center mb-4">
                           <FolderOpen className="w-10 h-10 text-muted-foreground" />
                        </div>
                        <p className="text-xl font-black uppercase italic tracking-tighter">Empty Folder</p>
                        <p className="text-sm font-medium">No content uploaded yet.</p>
                      </div>
                    )
                  )}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-center space-y-6">
                   <div className="w-24 h-24 bg-blue-500/10 rounded-full flex items-center justify-center animate-pulse">
                      <Upload className="w-10 h-10 text-blue-500" />
                   </div>
                   <div className="space-y-2">
                     <h3 className="heading-main text-2xl">Upload to Chat</h3>
                     <p className="text-muted-foreground max-w-xs mx-auto">Select a file from your device to send securely in this chat.</p>
                   </div>
                   <Button 
                      onClick={() => document.getElementById('modal-upload-input')?.click()}
                      className="h-14 px-8 rounded-2xl btn-standard text-lg shadow-xl"
                   >
                     SELECT FILE
                   </Button>
                </div>
              )}
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
