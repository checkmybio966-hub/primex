import { useState, useRef } from 'react';
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Image as ImageIcon, Video as VideoIcon, X, Upload, Loader2, Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import type { Banner } from '@/types';

export function BannerManagement() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [open, setOpen] = useState(false);
  const { profile } = useAuth();

  // Form state
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [linkUrl, setLinkUrl] = useState('');
  const [isActive, setIsActive] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchBanners = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('banners')
      .select('*')
      .order('order_index', { ascending: true });
    setBanners(data || []);
    setLoading(false);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    const isVideo = selectedFile.type.startsWith('video/');
    const isImage = selectedFile.type.startsWith('image/');

    if (!isImage && !isVideo) {
      toast.error('Please select an image or video file');
      return;
    }

    setFile(selectedFile);
    setPreviewUrl(URL.createObjectURL(selectedFile));
  };

  const handleUpload = async () => {
    if (!file || !profile) {
      toast.error('Please select a file');
      return;
    }

    setUploading(true);

    try {
      const isVideo = file.type.startsWith('video/');
      const bucket = 'primex_images'; // Use same bucket for banners
      const fileExt = file.name.split('.').pop();
      const fileName = `banners/${Date.now()}.${fileExt}`;

      // Upload to Supabase Storage
      const { error: uploadError } = await supabase.storage
        .from(bucket)
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false,
        });

      if (uploadError) throw uploadError;

      // Get Public URL
      const { data: { publicUrl } } = supabase.storage
        .from(bucket)
        .getPublicUrl(fileName);

      // Get next order index
      const { count } = await supabase
        .from('banners')
        .select('*', { count: 'exact', head: true });

      // Create Banner Record
      const { error: insertError } = await supabase
        .from('banners')
        .insert({
          media_url: publicUrl,
          media_type: isVideo ? 'video' : 'image',
          title: title || null,
          description: description || null,
          link_url: linkUrl || null,
          order_index: (count || 0) + 1,
          is_active: isActive,
        });

      if (insertError) throw insertError;

      toast.success('Banner uploaded successfully!');
      resetForm();
      setOpen(false);
      fetchBanners();
    } catch (error: any) {
      console.error('Upload error:', error);
      toast.error(error.message || 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (bannerId: string) => {
    try {
      const { error } = await supabase
        .from('banners')
        .delete()
        .eq('id', bannerId);

      if (error) throw error;

      toast.success('Banner deleted');
      fetchBanners();
    } catch (error: any) {
      toast.error(error.message || 'Failed to delete banner');
    }
  };

  const toggleActive = async (bannerId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('banners')
        .update({ is_active: !currentStatus })
        .eq('id', bannerId);

      if (error) throw error;

      toast.success(`Banner ${!currentStatus ? 'activated' : 'deactivated'}`);
      fetchBanners();
    } catch (error: any) {
      toast.error(error.message || 'Failed to update banner');
    }
  };

  const resetForm = () => {
    setFile(null);
    setPreviewUrl(null);
    setTitle('');
    setDescription('');
    setLinkUrl('');
    setIsActive(true);
  };

  return (
    <Card className="bg-card border-border rounded-[1.5rem]">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-section font-bold">Banner Management</CardTitle>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button onClick={fetchBanners} className="rounded-xl">
              <Plus className="w-4 h-4 mr-2" />
              Add Banner
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Upload New Banner</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              {/* File Upload */}
              <div className="space-y-2">
                <Label>Media File (Image or Video)</Label>
                <div className="flex items-center gap-4">
                  <Button 
                    onClick={() => fileInputRef.current?.click()}
                    variant="outline"
                    className="rounded-xl"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Choose File
                  </Button>
                  <span className="text-sm text-muted-foreground truncate flex-1">
                    {file ? file.name : "No file selected"}
                  </span>
                  <input
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    accept="image/*,video/*"
                    onChange={handleFileChange}
                  />
                </div>
                
                {previewUrl && (
                  <div className="mt-4 rounded-xl overflow-hidden border border-border relative group">
                    {file?.type.startsWith('video/') ? (
                      <video src={previewUrl} className="w-full max-h-64 object-contain" controls />
                    ) : (
                      <img src={previewUrl} className="w-full max-h-64 object-contain" alt="Preview" />
                    )}
                    <Button 
                      size="icon" 
                      variant="destructive" 
                      className="absolute top-2 right-2 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => { setFile(null); setPreviewUrl(null); }}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                )}
              </div>

              {/* Title */}
              <div className="space-y-2">
                <Label>Title (Optional)</Label>
                <Input
                  placeholder="Banner title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="rounded-xl"
                />
              </div>

              {/* Description */}
              <div className="space-y-2">
                <Label>Description (Optional)</Label>
                <Textarea
                  placeholder="Banner description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="rounded-xl min-h-20"
                />
              </div>

              {/* Link URL */}
              <div className="space-y-2">
                <Label>Link URL (Optional)</Label>
                <Input
                  placeholder="https://example.com"
                  value={linkUrl}
                  onChange={(e) => setLinkUrl(e.target.value)}
                  className="rounded-xl"
                />
              </div>

              {/* Active Toggle */}
              <div className="flex items-center justify-between">
                <Label>Active</Label>
                <Switch checked={isActive} onCheckedChange={setIsActive} />
              </div>

              {/* Upload Button */}
              <Button 
                onClick={handleUpload}
                disabled={uploading || !file}
                className="w-full rounded-xl h-12"
              >
                {uploading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Uploading...
                  </>
                ) : (
                  'Upload Banner'
                )}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        {loading ? (
          <p className="text-muted-foreground text-center py-8">Loading banners...</p>
        ) : banners.length > 0 ? (
          <div className="space-y-4">
            {banners.map((banner) => (
              <div key={banner.id} className="flex items-center gap-4 p-4 border border-border rounded-xl">
                <div className="w-32 h-20 rounded-lg overflow-hidden bg-black/40 flex-shrink-0">
                  {banner.media_type === 'image' ? (
                    <img src={banner.media_url} alt={banner.title || 'Banner'} className="w-full h-full object-cover" />
                  ) : (
                    <video src={banner.media_url} className="w-full h-full object-cover" muted />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold truncate">{banner.title || 'Untitled Banner'}</h4>
                  <p className="text-sm text-muted-foreground truncate">{banner.description || 'No description'}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${banner.is_active ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'}`}>
                      {banner.is_active ? 'Active' : 'Inactive'}
                    </span>
                    <span className="text-xs text-muted-foreground">#{banner.order_index}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Switch 
                    checked={banner.is_active} 
                    onCheckedChange={() => toggleActive(banner.id, banner.is_active)}
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDelete(banner.id)}
                    className="text-destructive hover:text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground text-center py-8">No banners yet. Add your first banner!</p>
        )}
      </CardContent>
    </Card>
  );
}
