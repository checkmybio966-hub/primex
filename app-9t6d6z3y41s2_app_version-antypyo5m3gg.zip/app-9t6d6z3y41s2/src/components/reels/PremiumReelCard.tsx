import { useState } from 'react';
import { Play, Lock, Eye, Heart, MessageCircle } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { FullscreenReelPlayer } from '@/components/reels/FullscreenReelPlayer';
import type { Post } from '@/types';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';

interface PremiumReelCardProps {
  reel: Post;
  position: number;
  onPreload?: () => void;
}

export function PremiumReelCard({ reel, position, onPreload }: PremiumReelCardProps) {
  const { isPremium, isAdmin } = useAuth();
  const [isPlayerOpen, setIsPlayerOpen] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const hasAccess = !reel.is_premium || isPremium || isAdmin;

  const handleClick = () => {
    setIsPlayerOpen(true);
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
    // Trigger preload
    if (onPreload) {
      onPreload();
    }
  };

  return (
    <>
      <div
        className={cn(
          "relative group cursor-pointer rounded-xl overflow-hidden bg-black/40 transition-all duration-300",
          "hover:scale-[1.02] hover:shadow-2xl hover:shadow-primary/20",
          "border border-border/50 hover:border-primary/50"
        )}
        onClick={handleClick}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Thumbnail */}
        <div className="relative aspect-[9/16] overflow-hidden bg-black">
          {reel.thumbnail_url ? (
            <img
              src={reel.thumbnail_url}
              alt={reel.caption || 'Reel thumbnail'}
              className="w-full h-full object-contain"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-muted/20 to-muted/5 flex items-center justify-center">
              <Play className="w-16 h-16 text-muted-foreground/30" />
            </div>
          )}

          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

          {/* Premium Badge */}
          {reel.is_premium && (
            <div className="absolute top-2 right-2 bg-primary/90 backdrop-blur-md text-white px-2 py-1 rounded-lg shadow-lg border border-white/20 flex items-center gap-1 z-10">
              <Lock className="w-3 h-3" />
              <span className="text-[9px] font-black uppercase tracking-widest">Premium</span>
            </div>
          )}

          {/* Play Button Overlay */}
          <div className={cn(
            "absolute inset-0 flex items-center justify-center transition-all duration-300",
            isHovered ? "opacity-100 scale-100" : "opacity-0 scale-90"
          )}>
            <div className="w-16 h-16 rounded-full bg-primary/90 backdrop-blur-md flex items-center justify-center shadow-2xl border-2 border-white/30 group-hover:scale-110 transition-transform">
              <Play className="w-8 h-8 text-white fill-white ml-1" />
            </div>
          </div>

          {/* Lock Overlay for Non-Premium Users */}
          {!hasAccess && (
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-20">
              <div className="text-center space-y-2">
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto border border-primary/30">
                  <Lock className="w-6 h-6 text-primary" />
                </div>
                <p className="text-white text-xs font-bold uppercase">Premium Only</p>
              </div>
            </div>
          )}

          {/* Bottom Info */}
          <div className="absolute bottom-0 left-0 right-0 p-3 space-y-2 z-10">
            {/* User Info */}
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center">
                <span className="text-[10px] font-bold text-white">
                  {reel.profiles?.username?.[0]?.toUpperCase()}
                </span>
              </div>
              <span className="text-white text-xs font-bold">
                {reel.profiles?.username}
              </span>
              <span className="text-white/60 text-[10px]">
                {formatDistanceToNow(new Date(reel.created_at), { addSuffix: true })}
              </span>
            </div>

            {/* Caption */}
            {reel.caption && (
              <p className="text-white text-xs line-clamp-2 leading-snug">
                {reel.caption}
              </p>
            )}

            {/* Stats */}
            <div className="flex items-center gap-3 text-white/80">
              <div className="flex items-center gap-1">
                <Heart className="w-3.5 h-3.5" />
                <span className="text-xs font-bold">{reel.likes_count}</span>
              </div>
              <div className="flex items-center gap-1">
                <MessageCircle className="w-3.5 h-3.5" />
                <span className="text-xs font-bold">{reel.comments_count}</span>
              </div>
              <div className="flex items-center gap-1">
                <Eye className="w-3 h-3" />
                <span className="text-xs font-bold">{reel.views_count}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Hover Effect Border */}
        <div className={cn(
          "absolute inset-0 border-2 border-primary rounded-xl transition-opacity duration-300 pointer-events-none",
          isHovered ? "opacity-100" : "opacity-0"
        )} />
      </div>

      {/* Fullscreen Player */}
      <FullscreenReelPlayer
        reel={reel}
        isOpen={isPlayerOpen}
        onClose={() => setIsPlayerOpen(false)}
        position={position}
      />
    </>
  );
}
