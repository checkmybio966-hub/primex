import { useEffect, useRef, useState, useCallback } from 'react';
import { ArrowLeft, Volume2, VolumeX, Lock, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import type { Post } from '@/types';

interface FullscreenReelPlayerProps {
  reel: Post;
  isOpen: boolean;
  onClose: () => void;
  position?: number;
}

export function FullscreenReelPlayer({ reel, isOpen, onClose, position = 0 }: FullscreenReelPlayerProps) {
  const { isPremium, isAdmin } = useAuth();
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [muted, setMuted] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [showVolumeIcon, setShowVolumeIcon] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isSeeking, setIsSeeking] = useState(false);
  const [showSeekFeedback, setShowSeekFeedback] = useState<'forward' | 'backward' | null>(null);
  const [seekTapCount, setSeekTapCount] = useState(0);
  const lastTapRef = useRef<number>(0);
  const lastTapSideRef = useRef<'left' | 'right' | 'center' | null>(null);
  const seekTimeoutRef = useRef<number | undefined>(undefined);
  const navigate = useNavigate();

  const hasAccess = !reel.is_premium || isPremium || isAdmin;

  // Handle fullscreen
  useEffect(() => {
    if (!isOpen || !containerRef.current) return;

    const container = containerRef.current;

    // Request fullscreen
    const enterFullscreen = async () => {
      try {
        if (container.requestFullscreen) {
          await container.requestFullscreen();
        } else if ((container as any).webkitRequestFullscreen) {
          await (container as any).webkitRequestFullscreen();
        } else if ((container as any).mozRequestFullScreen) {
          await (container as any).mozRequestFullScreen();
        } else if ((container as any).msRequestFullscreen) {
          await (container as any).msRequestFullscreen();
        }
      } catch (error) {
        console.error('Failed to enter fullscreen:', error);
      }
    };

    enterFullscreen();

    // Exit fullscreen on close
    return () => {
      if (document.fullscreenElement) {
        document.exitFullscreen().catch(console.error);
      }
    };
  }, [isOpen]);

  // Handle video playback
  useEffect(() => {
    if (!isOpen || !videoRef.current || !hasAccess) return;

    const video = videoRef.current;

    // Autoplay video
    const playVideo = async () => {
      try {
        await video.play();
        setIsLoading(false);
      } catch (error) {
        console.error('Failed to autoplay video:', error);
        setIsLoading(false);
      }
    };

    playVideo();

    return () => {
      video.pause();
    };
  }, [isOpen, hasAccess]);

  // Handle escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen, onClose]);

  // Handle fullscreen change
  useEffect(() => {
    const handleFullscreenChange = () => {
      if (!document.fullscreenElement) {
        onClose();
      }
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    document.addEventListener('mozfullscreenchange', handleFullscreenChange);
    document.addEventListener('MSFullscreenChange', handleFullscreenChange);

    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
      document.removeEventListener('mozfullscreenchange', handleFullscreenChange);
      document.removeEventListener('MSFullscreenChange', handleFullscreenChange);
    };
  }, [onClose]);

  // Track video progress
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !hasAccess) return;

    const updateProgress = () => {
      if (!isSeeking && video.duration) {
        setProgress((video.currentTime / video.duration) * 100);
      }
    };

    const updateDuration = () => {
      if (video.duration) {
        setDuration(video.duration);
      }
    };

    video.addEventListener('timeupdate', updateProgress);
    video.addEventListener('loadedmetadata', updateDuration);
    video.addEventListener('durationchange', updateDuration);

    return () => {
      video.removeEventListener('timeupdate', updateProgress);
      video.removeEventListener('loadedmetadata', updateDuration);
      video.removeEventListener('durationchange', updateDuration);
    };
  }, [isSeeking, hasAccess]);

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const video = videoRef.current;
    if (!video || !duration) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = (x / rect.width) * 100;
    const time = (percentage / 100) * duration;

    video.currentTime = time;
    setProgress(percentage);
  };

  const handleSeekStart = () => {
    setIsSeeking(true);
  };

  const handleSeekEnd = () => {
    setIsSeeking(false);
  };

  const handleVideoTap = (e: React.MouseEvent<HTMLDivElement>) => {
    const video = videoRef.current;
    if (!video || !hasAccess) return;

    const now = Date.now();
    const DOUBLE_TAP_DELAY = 300;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const width = rect.width;
    
    // Determine tap zone: left 40%, center 20%, right 40%
    let tapSide: 'left' | 'right' | 'center';
    if (x < width * 0.4) {
      tapSide = 'left';
    } else if (x > width * 0.6) {
      tapSide = 'right';
    } else {
      tapSide = 'center';
    }
    
    const isDoubleTap = now - lastTapRef.current < DOUBLE_TAP_DELAY;
    
    if (isDoubleTap && tapSide !== 'center') {
      // Double tap on left/right - seek ±10 seconds
      // DO NOT change mute state during seek
      const seekAmount = tapSide === 'right' ? 10 : -10;
      const newTime = Math.max(0, Math.min(video.duration, video.currentTime + seekAmount));
      video.currentTime = newTime;
      
      // Show feedback
      setShowSeekFeedback(tapSide === 'right' ? 'forward' : 'backward');
      
      // Stack seek taps
      if (lastTapSideRef.current === tapSide) {
        setSeekTapCount(prev => prev + 1);
      } else {
        setSeekTapCount(1);
      }
      
      // Clear existing timeout
      if (seekTimeoutRef.current) {
        clearTimeout(seekTimeoutRef.current);
      }
      
      // Hide feedback after 800ms
      seekTimeoutRef.current = setTimeout(() => {
        setShowSeekFeedback(null);
        setSeekTapCount(0);
      }, 800);
      
      lastTapSideRef.current = tapSide;
      // Update lastTapRef to prevent single tap from triggering
      lastTapRef.current = now;
    } else if (!isDoubleTap) {
      // Single tap only - toggle mute
      // Only toggle mute if it's NOT part of a double-tap sequence
      toggleMute();
      lastTapSideRef.current = null;
      lastTapRef.current = now;
    } else {
      // Double tap on center - just update tap time
      lastTapRef.current = now;
    }
  };

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (seekTimeoutRef.current) {
        clearTimeout(seekTimeoutRef.current);
      }
    };
  }, []);

  const toggleMute = useCallback(() => {
    setMuted(prev => !prev);
    setShowVolumeIcon(true);
    setTimeout(() => setShowVolumeIcon(false), 1000);
  }, []);

  const handleUpgrade = () => {
    onClose();
    navigate('/premium');
  };

  if (!isOpen) return null;

  return (
    <div
      ref={containerRef}
      className={cn(
        "fixed inset-0 z-[9999] bg-black flex items-center justify-center transition-opacity duration-300",
        isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
      )}
    >
      {/* Back Button - Top Left (Always Visible) */}
      <Button
        variant="ghost"
        size="icon"
        className="absolute top-6 left-6 z-[10000] w-10 h-10 rounded-full bg-black/30 backdrop-blur-md flex items-center justify-center text-white hover:bg-black/50 transition-all border border-white/10"
        onClick={(e) => {
          e.stopPropagation();
          onClose();
        }}
      >
        <ArrowLeft className="w-6 h-6" />
      </Button>

      {/* Sound Icon - Top Right (Always Visible) */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          toggleMute();
        }}
        className="absolute top-4 right-4 z-[10000] w-12 h-12 rounded-full bg-black/70 backdrop-blur-md flex items-center justify-center hover:bg-black/90 transition-all active:scale-95 border-2 border-white/30 shadow-2xl"
        aria-label={muted ? "Unmute" : "Mute"}
      >
        {muted ? (
          <VolumeX className="w-6 h-6 text-white" />
        ) : (
          <Volume2 className="w-6 h-6 text-white" />
        )}
      </button>

      {/* Position Indicator - Top Right (Below Sound Icon) */}
      {position !== undefined && (
        <div className="absolute top-20 right-4 z-[10000] bg-black/70 backdrop-blur-md px-3 py-1.5 rounded-full text-white text-sm font-bold border-2 border-white/30 shadow-lg">
          #{position + 1}
        </div>
      )}

      {/* Premium Lock Overlay */}
      {!hasAccess && (
        <div className="absolute inset-0 z-[9998] bg-black/90 backdrop-blur-xl flex flex-col items-center justify-center p-6 text-center space-y-6">
          <div className="relative">
            <div className="w-24 h-24 bg-primary/20 rounded-3xl flex items-center justify-center border border-primary/30 shadow-2xl animate-pulse">
              <Lock className="w-12 h-12 text-primary" />
            </div>
            <div className="absolute -top-2 -right-2 bg-yellow-500 rounded-full p-2 shadow-lg border-4 border-black">
              <Sparkles className="w-5 h-5 text-white fill-white" />
            </div>
          </div>

          <div className="space-y-2">
            <h2 className="text-2xl font-black text-white uppercase italic tracking-tight">
              Premium Content
            </h2>
            <p className="text-muted-foreground text-sm max-w-xs">
              Upgrade to Premium to unlock this exclusive reel and access all premium content
            </p>
          </div>

          <Button
            onClick={handleUpgrade}
            className="bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-600/90 text-white px-8 py-6 rounded-2xl font-black uppercase italic tracking-tight shadow-2xl shadow-primary/30 border border-white/20"
          >
            <Sparkles className="w-5 h-5 mr-2 fill-white" />
            Upgrade to Premium
          </Button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
            className="text-muted-foreground hover:text-white transition-colors text-sm font-medium"
          >
            Close
          </button>
        </div>
      )}

      {/* Video Player */}
      {hasAccess && (
        <>
          {/* Loading Indicator */}
          {isLoading && (
            <div className="absolute inset-0 z-[9997] flex items-center justify-center bg-black">
              <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin" />
            </div>
          )}

          {/* Thumbnail Background (while loading) */}
          {isLoading && reel.thumbnail_url && (
            <div className="absolute inset-0 z-[9996]">
              <img
                src={reel.thumbnail_url}
                alt="Video thumbnail"
                className="w-full h-full object-contain"
              />
              <div className="absolute inset-0 bg-black/30" />
            </div>
          )}

          {/* Video Element */}
          <video
            ref={videoRef}
            src={reel.media_url}
            className="max-w-full max-h-full object-contain pointer-events-none select-none"
            playsInline
            muted={muted}
            loop
            preload="auto"
            poster={reel.thumbnail_url}
            onLoadedData={() => setIsLoading(false)}
            controlsList="nodownload"
            onContextMenu={(e) => e.preventDefault()}
          />

          {/* Tap Overlay for Gestures */}
          <div 
            className="absolute inset-0 z-[9997] cursor-pointer"
            onClick={handleVideoTap}
          />

          {/* Volume Icon Overlay */}
          <div
            className={cn(
              "absolute inset-0 flex items-center justify-center pointer-events-none z-[9998] transition-opacity duration-300",
              showVolumeIcon ? "opacity-100" : "opacity-0"
            )}
          >
            <div className="bg-black/60 p-4 rounded-full backdrop-blur-sm">
              {muted ? (
                <VolumeX className="w-10 h-10 text-white" />
              ) : (
                <Volume2 className="w-10 h-10 text-white" />
              )}
            </div>
          </div>

          {/* Seek Feedback Overlay (Double Tap) */}
          {showSeekFeedback && (
            <div className={cn(
              "absolute inset-0 flex items-center pointer-events-none z-[9998]",
              showSeekFeedback === 'forward' ? "justify-end pr-12" : "justify-start pl-12"
            )}>
              <div className="bg-black/70 px-6 py-4 rounded-2xl backdrop-blur-md flex items-center gap-3 animate-in fade-in zoom-in duration-200">
                <div className="flex gap-1">
                  {Array.from({ length: Math.min(seekTapCount, 3) }).map((_, i) => (
                    <div 
                      key={i} 
                      className="w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-b-[16px] border-b-white" 
                      style={{ 
                        transform: showSeekFeedback === 'forward' ? 'rotate(90deg)' : 'rotate(-90deg)',
                        opacity: 1 - (i * 0.2)
                      }}
                    />
                  ))}
                </div>
                <span className="text-white text-lg font-bold">
                  {seekTapCount * 10}s
                </span>
              </div>
            </div>
          )}

          {/* Video Progress Seekbar - Above Username */}
          <div className="absolute bottom-24 left-0 right-0 z-[9999] px-4">
            <div
              className="relative h-2 bg-white/30 rounded-full overflow-hidden cursor-pointer backdrop-blur-sm shadow-lg"
              onClick={handleSeek}
              onMouseDown={handleSeekStart}
              onMouseUp={handleSeekEnd}
              onTouchStart={handleSeekStart}
              onTouchEnd={handleSeekEnd}
            >
              {/* Progress Bar */}
              <div
                className="absolute top-0 left-0 h-full bg-white rounded-full transition-all duration-100 shadow-sm"
                style={{ width: `${progress}%` }}
              />
              
              {/* Seek Handle */}
              <div
                className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-xl transition-all duration-100 border-2 border-white/50"
                style={{ left: `calc(${progress}% - 8px)` }}
              />
            </div>
          </div>

          {/* Reel Info Overlay - Below Seekbar */}
          <div className="absolute bottom-0 left-0 right-0 z-[9998] bg-gradient-to-t from-black/80 via-black/40 to-transparent p-4 pb-6 pointer-events-none">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center">
                  <span className="text-xs font-bold text-white">
                    {reel.profiles?.username?.[0]?.toUpperCase()}
                  </span>
                </div>
                <span className="text-white font-bold text-sm">
                  {reel.profiles?.username}
                </span>
                {reel.is_premium && (
                  <div className="bg-primary/90 px-2 py-0.5 rounded-md flex items-center gap-1">
                    <Lock className="w-3 h-3 text-white" />
                    <span className="text-[9px] font-black uppercase text-white">Premium</span>
                  </div>
                )}
              </div>
              {reel.caption && (
                <p className="text-white text-sm line-clamp-2">
                  {reel.caption}
                </p>
              )}
            </div>
          </div>

          {/* Tap to unmute hint */}
          {muted && !showVolumeIcon && (
            <div className="absolute bottom-24 left-1/2 -translate-x-1/2 z-[9998] bg-black/60 backdrop-blur-sm px-4 py-2 rounded-full text-white text-xs font-medium animate-pulse pointer-events-none">
              Tap to unmute
            </div>
          )}
        </>
      )}
    </div>
  );
}
