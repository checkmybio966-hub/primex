import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Switch } from '@/components/ui/switch';
import { Upload, Image as ImageIcon, Video as VideoIcon, Loader2, X, ArrowLeft, Sparkles, FolderOpen, AlertCircle, LayoutGrid, Play, FileIcon } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import type { MediaItem } from '@/types';

type UploadType = 'normal' | 'premium';
type ContentCategory = 'posts' | 'reels' | 'albums' | 'files';

// File validation constants
const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB
const MAX_IMAGE_SIZE = 10 * 1024 * 1024; // 10MB for images
const MAX_VIDEO_SIZE = 50 * 1024 * 1024; // 50MB for videos
const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
const ALLOWED_VIDEO_TYPES = ['video/mp4', 'video/webm', 'video/quicktime', 'video/x-msvideo'];
const MAX_RETRIES = 2;
const UPLOAD_TIMEOUT = 60000; // 60 seconds per file

interface UploadError {
  file: string;
  error: string;
  type: 'validation' | 'network' | 'storage' | 'permission' | 'unknown';
}

export default function UploadPage() {
  const { user, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [uploadType, setUploadType] = useState<UploadType>('normal');
  const [files, setFiles] = useState<File[]>([]);
  const [caption, setCaption] = useState('');
  const [title, setTitle] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [currentFileProgress, setCurrentFileProgress] = useState('');
  const [uploadErrors, setUploadErrors] = useState<UploadError[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Premium toggles
  const [categories, setCategories] = useState({
    posts: true,
    reels: false,
    albums: false,
    files: false
  });

  // DEBUG FUNCTION: Create test album with dummy data
  const createTestAlbum = async () => {
    if (!user) {
      toast.error('You must be logged in');
      return;
    }

    console.log('[TEST] ═══════════════════════════════════════');
    console.log('[TEST] CREATING TEST ALBUM WITH DUMMY DATA');
    console.log('[TEST] ═══════════════════════════════════════');

    try {
      const testAlbum = {
        title: `Test Album - ${new Date().toLocaleTimeString()}`,
        description: 'This is a test album created with dummy data',
        media_items: [
          {
            url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4',
            type: 'image' as const
          },
          {
            url: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e',
            type: 'image' as const
          },
          {
            url: 'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d',
            type: 'image' as const
          }
        ],
        thumbnail_url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4',
        is_premium: true
      };

      console.log('[TEST] Test album data:', testAlbum);
      console.log('[TEST] Calling api.createAlbum()...');

      const result = await api.createAlbum(testAlbum);

      console.log('[TEST] Result:', result);

      if (result.error) {
        console.error('[TEST] ❌ Failed to create test album:', result.error);
        toast.error(`Test failed: ${(result.error as any).message}`);
        return;
      }

      if (!result.data) {
        console.error('[TEST] ❌ No data returned');
        toast.error('Test failed: No data returned');
        return;
      }

      console.log('[TEST] ═══════════════════════════════════════');
      console.log('[TEST] ✓ TEST ALBUM CREATED SUCCESSFULLY');
      console.log('[TEST] ═══════════════════════════════════════');
      console.log('[TEST] Album ID:', result.data.id);
      console.log('[TEST] Album Title:', result.data.title);
      console.log('[TEST] Is Premium:', result.data.is_premium);
      console.log('[TEST] ═══════════════════════════════════════');

      toast.success('Test album created! Check Premium Feed → Albums');
      
      // Navigate to premium feed
      setTimeout(() => {
        navigate('/premium-feed?tab=albums&refresh=true');
      }, 1000);

    } catch (error) {
      console.error('[TEST] ❌ Exception:', error);
      toast.error(`Test failed: ${error}`);
    }
  };

  // Redirect if not admin
  if (!isAdmin) {
    navigate('/');
    return null;
  }

  // File validation function
  const validateFile = (file: File): { valid: boolean; error?: string } => {
    console.log(`[VALIDATION] Checking file: ${file.name}, size: ${file.size}, type: ${file.type}`);

    // Check file type
    const isImage = ALLOWED_IMAGE_TYPES.includes(file.type);
    const isVideo = ALLOWED_VIDEO_TYPES.includes(file.type);

    if (!isImage && !isVideo) {
      return {
        valid: false,
        error: `Invalid file type: ${file.type}. Only images (JPEG, PNG, GIF, WebP) and videos (MP4, WebM, MOV) are allowed.`
      };
    }

    // Check file size
    if (isImage && file.size > MAX_IMAGE_SIZE) {
      return {
        valid: false,
        error: `Image too large: ${(file.size / 1024 / 1024).toFixed(2)}MB. Maximum size is 10MB.`
      };
    }

    if (isVideo && file.size > MAX_VIDEO_SIZE) {
      return {
        valid: false,
        error: `Video too large: ${(file.size / 1024 / 1024).toFixed(2)}MB. Maximum size is 50MB.`
      };
    }

    console.log(`[VALIDATION] ✓ File ${file.name} passed validation`);
    return { valid: true };
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    const validFiles: File[] = [];
    const errors: UploadError[] = [];

    selectedFiles.forEach(file => {
      const validation = validateFile(file);
      if (validation.valid) {
        validFiles.push(file);
      } else {
        errors.push({
          file: file.name,
          error: validation.error || 'Validation failed',
          type: 'validation'
        });
        toast.error(`${file.name}: ${validation.error}`);
      }
    });

    if (validFiles.length > 0) {
      setFiles(prev => [...prev, ...validFiles]);
      toast.success(`${validFiles.length} file(s) added`);
    }

    if (errors.length > 0) {
      setUploadErrors(prev => [...prev, ...errors]);
    }
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const toggleCategory = (category: ContentCategory) => {
    setCategories(prev => ({
      ...prev,
      [category]: !prev[category]
    }));
  };

  const detectContentType = (): { type: 'post' | 'reel' | 'album' | 'file', isPremium: boolean } => {
    if (uploadType === 'normal') {
      // Normal upload logic - create simple posts/reels
      const hasVideo = files.some(f => f.type.startsWith('video/'));
      if (hasVideo && files.length === 1) {
        return { type: 'reel', isPremium: false };
      }
      return { type: 'post', isPremium: false };
    }

    // Premium upload - use toggles
    // Albums and Files create special structures
    if (categories.albums) return { type: 'album', isPremium: true };
    if (categories.files) return { type: 'file', isPremium: true };
    
    // Posts and Reels create simple premium posts/reels (direct media display)
    if (categories.reels) return { type: 'reel', isPremium: true };
    if (categories.posts) return { type: 'post', isPremium: true };
    
    // Default to premium post
    return { type: 'post', isPremium: true };
  };

  // Upload single file with retry logic
  const uploadSingleFile = async (
    file: File, 
    index: number, 
    retryCount = 0
  ): Promise<MediaItem | null> => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${Date.now()}_${index}_${Math.random().toString(36).substring(7)}.${fileExt}`;
    const filePath = `uploads/${fileName}`;

    console.log(`[UPLOAD] Starting upload for file ${index + 1}/${files.length}: ${file.name}`);
    console.log(`[UPLOAD] File path: ${filePath}, Size: ${(file.size / 1024 / 1024).toFixed(2)}MB`);

    try {
      // Create upload promise with timeout
      const uploadPromise = api.supabase.storage
        .from('primex_images') // Using existing bucket
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      // Add timeout
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Upload timeout')), UPLOAD_TIMEOUT)
      );

      const { data, error } = await Promise.race([
        uploadPromise,
        timeoutPromise
      ]) as any;

      if (error) {
        console.error(`[UPLOAD ERROR] File ${file.name}:`, error);
        
        // Determine error type
        let errorType: UploadError['type'] = 'unknown';
        let errorMessage = error.message || 'Unknown error';

        if (error.message?.includes('permission') || error.message?.includes('unauthorized')) {
          errorType = 'permission';
          errorMessage = 'Permission denied. Please check admin access.';
        } else if (error.message?.includes('network') || error.message?.includes('fetch')) {
          errorType = 'network';
          errorMessage = 'Network error. Please check your connection.';
        } else if (error.message?.includes('storage') || error.message?.includes('bucket')) {
          errorType = 'storage';
          errorMessage = 'Storage error. Please try again.';
        }

        // Retry logic
        if (retryCount < MAX_RETRIES && errorType === 'network') {
          console.log(`[RETRY] Retrying upload for ${file.name} (attempt ${retryCount + 1}/${MAX_RETRIES})`);
          await new Promise(resolve => setTimeout(resolve, 1000 * (retryCount + 1))); // Exponential backoff
          return uploadSingleFile(file, index, retryCount + 1);
        }

        throw { type: errorType, message: errorMessage, originalError: error };
      }

      // Get public URL
      const { data: urlData } = api.supabase.storage
        .from('primex_images')
        .getPublicUrl(filePath);

      console.log(`[UPLOAD] ✓ Successfully uploaded ${file.name}`);
      console.log(`[UPLOAD] Public URL: ${urlData.publicUrl}`);

      return {
        url: urlData.publicUrl,
        type: file.type.startsWith('video/') ? 'video' : 'image'
      };

    } catch (error: any) {
      console.error(`[UPLOAD FAILED] File ${file.name}:`, error);
      
      const uploadError: UploadError = {
        file: file.name,
        error: error.message || 'Upload failed',
        type: error.type || 'unknown'
      };

      setUploadErrors(prev => [...prev, uploadError]);
      
      // Don't throw on last retry, return null instead
      if (retryCount >= MAX_RETRIES) {
        toast.error(`Failed to upload ${file.name}: ${error.message}`);
        return null;
      }

      throw error;
    }
  };

  const handleUpload = async () => {
    if (files.length === 0) {
      toast.error('Please select at least one file');
      return;
    }

    if (!user) {
      toast.error('You must be logged in to upload');
      return;
    }

    console.log('[UPLOAD START] Beginning upload process...');
    console.log(`[UPLOAD START] Total files: ${files.length}`);
    console.log(`[UPLOAD START] Upload type: ${uploadType}`);

    setUploading(true);
    setUploadProgress(0);
    setUploadErrors([]);

    try {
      const { type, isPremium } = detectContentType();
      console.log(`[UPLOAD] Detected content type: ${type}, Premium: ${isPremium}`);
      
      // Upload files sequentially with progress tracking
      const mediaItems: MediaItem[] = [];
      const failedFiles: string[] = [];

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        setCurrentFileProgress(`Uploading ${file.name} (${i + 1}/${files.length})...`);
        
        try {
          const mediaItem = await uploadSingleFile(file, i);
          
          if (mediaItem) {
            mediaItems.push(mediaItem);
            console.log(`[PROGRESS] Uploaded ${i + 1}/${files.length} files`);
          } else {
            failedFiles.push(file.name);
          }

          // Update progress (80% for uploads, 20% for database operations)
          setUploadProgress(((i + 1) / files.length) * 80);
        } catch (error) {
          console.error(`[UPLOAD] Failed to upload ${file.name}:`, error);
          failedFiles.push(file.name);
        }
      }

      // Check if any files uploaded successfully
      if (mediaItems.length === 0) {
        throw new Error('All file uploads failed. Please check your connection and try again.');
      }

      console.log('[VALIDATION] ✓ Upload validation passed:', {
        total_files_selected: files.length,
        successfully_uploaded: mediaItems.length,
        failed_uploads: failedFiles.length,
        media_urls: mediaItems.map(m => m.url)
      });

      if (failedFiles.length > 0) {
        toast.warning(`${failedFiles.length} file(s) failed to upload: ${failedFiles.join(', ')}`);
      }

      setCurrentFileProgress('Creating content...');
      console.log(`[DATABASE] Creating ${type} with ${mediaItems.length} media items`);
      console.log(`[DATABASE] Content type: ${type}, Premium: ${isPremium}`);

      // Create post/album/file based on type
      if (type === 'album') {
        // CRITICAL VALIDATION: Ensure we have media items
        if (!mediaItems || mediaItems.length === 0) {
          console.error('[CRITICAL ERROR] Attempting to create album with empty media items!');
          throw new Error('Cannot create album: No media URLs generated. Upload may have failed.');
        }

        // CRITICAL VALIDATION: Ensure all URLs are valid
        const invalidUrls = mediaItems.filter(item => !item.url || item.url.trim() === '');
        if (invalidUrls.length > 0) {
          console.error('[CRITICAL ERROR] Found invalid URLs in media items:', invalidUrls);
          throw new Error(`Cannot create album: ${invalidUrls.length} media item(s) have invalid URLs`);
        }

        console.log('[VALIDATION] ✓ Album validation passed - all media items have valid URLs');

        // Auto-generate album title if not provided
        const albumTitle = title.trim() || `Premium Album - ${new Date().toLocaleDateString()}`;
        
        console.log('[DATABASE] ═══════════════════════════════════════');
        console.log('[DATABASE] PREPARING TO SAVE ALBUM TO DATABASE');
        console.log('[DATABASE] ═══════════════════════════════════════');
        console.log('[DATABASE] Album details:', {
          title: albumTitle,
          description: caption || null,
          media_items_count: mediaItems.length,
          is_premium: isPremium,
          thumbnail_url: mediaItems[0]?.url || null,
          all_media_urls: mediaItems.map(m => m.url)
        });
        console.log('[DATABASE] Collection: albums');
        console.log('[DATABASE] ═══════════════════════════════════════');

        console.log('[DATABASE] Calling api.createAlbum()...');
        const result = await api.createAlbum({
          title: albumTitle,
          description: caption || null,
          media_items: mediaItems,
          thumbnail_url: mediaItems[0]?.url || null,
          is_premium: isPremium
        });
        console.log('[DATABASE] api.createAlbum() returned:', result);

        if (result.error) {
          console.error('[DATABASE ERROR] ═══════════════════════════════════════');
          console.error('[DATABASE ERROR] FAILED TO CREATE ALBUM');
          console.error('[DATABASE ERROR] ═══════════════════════════════════════');
          console.error('[DATABASE ERROR] Error details:', result.error);
          console.error('[DATABASE ERROR] Error message:', (result.error as any).message);
          console.error('[DATABASE ERROR] Error code:', (result.error as any).code);
          console.error('[DATABASE ERROR] ═══════════════════════════════════════');
          throw new Error(`Failed to create album: ${(result.error as any).message || 'Unknown error'}`);
        }

        if (!result.data) {
          console.error('[DATABASE ERROR] ═══════════════════════════════════════');
          console.error('[DATABASE ERROR] NO DATA RETURNED FROM CREATE ALBUM');
          console.error('[DATABASE ERROR] ═══════════════════════════════════════');
          console.error('[DATABASE ERROR] Result:', result);
          console.error('[DATABASE ERROR] ═══════════════════════════════════════');
          throw new Error('Failed to create album: No data returned from database');
        }

        console.log('[DATABASE] ═══════════════════════════════════════');
        console.log('[DATABASE] ✓✓✓ ALBUM SAVED SUCCESSFULLY ✓✓✓');
        console.log('[DATABASE] ═══════════════════════════════════════');
        console.log('[DATABASE] Saved album details:', {
          id: result.data.id,
          title: result.data.title,
          is_premium: result.data.is_premium,
          media_count: result.data.media_items?.length || 0,
          created_at: result.data.created_at
        });
        console.log('[DATABASE] ═══════════════════════════════════════');

        // Verify the album was saved with correct premium flag
        if (result.data.is_premium !== isPremium) {
          console.warn('[DATABASE WARNING] ⚠️ is_premium FLAG MISMATCH!', {
            expected: isPremium,
            actual: result.data.is_premium
          });
          toast.warning('Album created but premium flag may be incorrect');
        }

        // VERIFICATION: Fetch the album back to confirm it exists
        console.log('[VERIFICATION] Fetching album back from database to confirm...');
        try {
          const verifyAlbums = await api.getAlbums(false, 1, 0); // Fetch without premium filter
          const savedAlbum = verifyAlbums.find(a => a.id === result.data?.id);
          if (savedAlbum) {
            console.log('[VERIFICATION] ✓ Album confirmed in database:', {
              id: savedAlbum.id,
              title: savedAlbum.title,
              is_premium: savedAlbum.is_premium
            });
          } else {
            console.warn('[VERIFICATION] ⚠️ Album not found in immediate fetch (may need time to propagate)');
          }
        } catch (verifyError) {
          console.warn('[VERIFICATION] Could not verify album:', verifyError);
        }
      } else if (type === 'file') {
        // Upload as files
        console.log(`[DATABASE] Creating ${mediaItems.length} file entries`);
        for (let i = 0; i < mediaItems.length; i++) {
          const item = mediaItems[i];
          await api.uploadFile(
            user.id,
            files[i],
            title || files[i].name,
            files[i].type,
            null
          );
        }
        console.log('[DATABASE] ✓ Files created successfully');
      } else {
        // Create post or reel
        console.log(`[DATABASE] Creating ${type}`);
        const { error } = await api.createPost({
          user_id: user.id,
          type: type,
          media_url: mediaItems[0].url,
          media_type: mediaItems[0].type,
          media_items: mediaItems.length > 1 ? mediaItems : undefined,
          caption: caption,
          is_premium: isPremium,
          thumbnail_url: mediaItems[0].type === 'video' ? mediaItems[0].url : undefined
        });

        if (error) {
          console.error('[DATABASE ERROR] Failed to create post:', error);
          throw new Error(`Failed to create post: ${error.message}`);
        }

        console.log('[DATABASE] ✓ Post created successfully');
      }

      setUploadProgress(100);
      setCurrentFileProgress('');
      
      // Show success message
      const successMessage = failedFiles.length > 0
        ? `${type.charAt(0).toUpperCase() + type.slice(1)} created with ${mediaItems.length}/${files.length} files`
        : `${type.charAt(0).toUpperCase() + type.slice(1)} uploaded successfully!`;
      
      toast.success(successMessage);
      console.log('[UPLOAD COMPLETE] ✓ Upload process completed successfully');
      
      // Reset form
      setFiles([]);
      setCaption('');
      setTitle('');
      setUploadProgress(0);
      setUploadErrors([]);
      
      // Navigate based on type with a small delay to ensure database is updated
      setTimeout(() => {
        if (type === 'album') {
          // Albums go to premium feed albums tab
          navigate('/premium-feed?tab=albums&refresh=true');
        } else if (type === 'file') {
          // Files go to premium feed files tab
          navigate('/premium-feed?tab=files&refresh=true');
        } else if (type === 'reel' && isPremium) {
          // Premium reels go to premium feed reels tab
          navigate('/premium-feed?tab=reels&refresh=true');
        } else if (type === 'reel' && !isPremium) {
          // Normal reels go to reels page
          navigate('/reels');
        } else if (type === 'post' && isPremium) {
          // Premium posts go to premium feed posts tab
          navigate('/premium-feed?tab=posts&refresh=true');
        } else {
          // Normal posts go to home
          navigate('/');
        }
      }, 500); // 500ms delay to ensure real-time event propagates

    } catch (error: any) {
      console.error('[UPLOAD FAILED]', error);
      
      // Determine user-friendly error message
      let errorMessage = 'Upload failed. Please try again.';
      
      if (error.message) {
        errorMessage = error.message;
      } else if (error.type === 'network') {
        errorMessage = 'Network error. Please check your internet connection and try again.';
      } else if (error.type === 'permission') {
        errorMessage = 'Permission denied. Please ensure you have admin access.';
      } else if (error.type === 'storage') {
        errorMessage = 'Storage error. Please contact support if this persists.';
      }

      toast.error(errorMessage);
      setCurrentFileProgress('');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="min-h-screen pb-20 md:pb-4">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-card/95 backdrop-blur-xl border-b border-border/50 px-3 py-2">
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            className="h-8 w-8"
          >
            <ArrowLeft className="w-4.5 h-4.5" />
          </Button>
          <h1 className="text-section font-bold uppercase italic tracking-tighter">Upload Content</h1>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-3 py-4 space-y-4">
        {/* DEBUG: Test Album Button (Admin Only) */}
        {isAdmin && (
          <Card className="glass border-yellow-500/50 bg-yellow-500/5">
            <CardContent className="p-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-small font-bold text-yellow-500">🔧 Debug Mode</p>
                  <p className="text-[10px] text-muted-foreground">Create test album with dummy data</p>
                </div>
                <Button
                  onClick={createTestAlbum}
                  variant="outline"
                  size="sm"
                  className="border-yellow-500/50 text-yellow-500 hover:bg-yellow-500/10"
                >
                  Create Test Album
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Upload Type Selector */}
        <Card className="glass border-border/50">
          <CardHeader className="p-3">
            <CardTitle className="text-section">Upload Type</CardTitle>
          </CardHeader>
          <CardContent className="p-3 pt-0">
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant={uploadType === 'normal' ? 'default' : 'outline'}
                onClick={() => setUploadType('normal')}
                className="h-11"
              >
                <Upload className="w-4 h-4 mr-1.5" />
                Normal
              </Button>
              <Button
                variant={uploadType === 'premium' ? 'default' : 'outline'}
                onClick={() => setUploadType('premium')}
                className="h-11"
              >
                <Sparkles className="w-4 h-4 mr-1.5" />
                Premium
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Premium Category Toggles */}
        {uploadType === 'premium' && (
          <Card className="glass border-border/50 border-primary/30">
            <CardHeader className="p-3">
              <CardTitle className="text-section flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-primary" />
                Premium Categories
              </CardTitle>
              <p className="text-[10px] text-muted-foreground mt-1">
                Select where this content will appear
              </p>
            </CardHeader>
            <CardContent className="p-3 pt-0">
              <div className="grid grid-cols-2 gap-2">
                {(['posts', 'reels', 'albums', 'files'] as ContentCategory[]).map((cat) => (
                  <div
                    key={cat}
                    className={cn(
                      "flex items-center justify-between p-2.5 rounded-lg border transition-all",
                      categories[cat] ? "bg-primary/10 border-primary/30" : "bg-muted/20 border-border/30"
                    )}
                  >
                    <Label htmlFor={cat} className="text-small font-bold uppercase cursor-pointer">
                      {cat}
                    </Label>
                    <Switch
                      id={cat}
                      checked={categories[cat]}
                      onCheckedChange={() => toggleCategory(cat)}
                    />
                  </div>
                ))}
              </div>
              
              {/* Active Category Info */}
              {categories.posts && (
                <div className="mt-3 p-2.5 bg-primary/5 border border-primary/20 rounded-lg">
                  <div className="flex items-start gap-2">
                    <LayoutGrid className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                    <div className="space-y-1">
                      <p className="text-[11px] font-bold text-primary">Creating Premium Posts</p>
                      <p className="text-[10px] text-muted-foreground leading-relaxed">
                        Media will appear directly in Premium Feed → Posts tab
                      </p>
                    </div>
                  </div>
                </div>
              )}
              
              {categories.reels && (
                <div className="mt-3 p-2.5 bg-primary/5 border border-primary/20 rounded-lg">
                  <div className="flex items-start gap-2">
                    <Play className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                    <div className="space-y-1">
                      <p className="text-[11px] font-bold text-primary">Creating Premium Reels</p>
                      <p className="text-[10px] text-muted-foreground leading-relaxed">
                        Videos will appear directly in Premium Feed → Reels tab
                      </p>
                    </div>
                  </div>
                </div>
              )}
              
              {categories.albums && (
                <div className="mt-3 p-2.5 bg-primary/5 border border-primary/20 rounded-lg">
                  <div className="flex items-start gap-2">
                    <FolderOpen className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                    <div className="space-y-1">
                      <p className="text-[11px] font-bold text-primary">Creating Premium Album</p>
                      <p className="text-[10px] text-muted-foreground leading-relaxed">
                        All media grouped into a single album with grid view in Premium Feed → Albums tab
                      </p>
                    </div>
                  </div>
                </div>
              )}
              
              {categories.files && (
                <div className="mt-3 p-2.5 bg-primary/5 border border-primary/20 rounded-lg">
                  <div className="flex items-start gap-2">
                    <FileIcon className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                    <div className="space-y-1">
                      <p className="text-[11px] font-bold text-primary">Creating Premium Files</p>
                      <p className="text-[10px] text-muted-foreground leading-relaxed">
                        Files will be available for download in Premium Feed → Files tab
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* File Upload Area */}
        <Card className="glass border-border/50">
          <CardHeader className="p-3">
            <CardTitle className="text-section">Select Files</CardTitle>
          </CardHeader>
          <CardContent className="p-3 pt-0 space-y-3">
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*,video/*"
              onChange={handleFileSelect}
              className="hidden"
            />
            
            <Button
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              className="w-full h-24 border-dashed border-2"
              disabled={uploading}
            >
              <div className="flex flex-col items-center gap-1.5">
                <Upload className="w-6 h-6" />
                <span className="text-small font-bold">Choose Files</span>
                <span className="text-[10px] text-muted-foreground">Images or Videos</span>
              </div>
            </Button>

            {/* File Preview */}
            {files.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-small font-bold">Selected Files ({files.length})</Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setFiles([])}
                    className="h-7 text-[10px]"
                  >
                    Clear All
                  </Button>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {files.map((file, index) => (
                    <div key={index} className="relative aspect-square rounded-lg overflow-hidden bg-muted/20 border border-border/30 group">
                      {file.type.startsWith('image/') ? (
                        <img
                          src={URL.createObjectURL(file)}
                          alt={`Preview ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center p-2">
                          <VideoIcon className="w-8 h-8 text-muted-foreground mb-1" />
                          <span className="text-[9px] text-center text-muted-foreground line-clamp-2">
                            {file.name}
                          </span>
                        </div>
                      )}
                      
                      {/* File Size Badge */}
                      <div className="absolute bottom-1 left-1 bg-black/70 backdrop-blur-sm px-1.5 py-0.5 rounded text-[9px] text-white font-bold">
                        {(file.size / 1024 / 1024).toFixed(1)}MB
                      </div>

                      {/* Remove Button */}
                      <button
                        onClick={() => removeFile(index)}
                        className="absolute top-1 right-1 w-5 h-5 rounded-full bg-destructive flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X className="w-3 h-3 text-white" />
                      </button>
                    </div>
                  ))}
                </div>
                
                {/* Total Size */}
                <div className="flex items-center justify-between text-[10px] text-muted-foreground p-2 bg-muted/10 rounded-lg">
                  <span>Total Size:</span>
                  <span className="font-bold">
                    {(files.reduce((sum, f) => sum + f.size, 0) / 1024 / 1024).toFixed(2)}MB
                  </span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Title (for albums/files) */}
        {uploadType === 'premium' && (categories.albums || categories.files) && (
          <Card className="glass border-border/50">
            <CardContent className="p-3 space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-small font-bold uppercase">
                  {categories.albums ? 'Album Title' : 'File Title'}
                </Label>
                {categories.albums && (
                  <span className="text-[10px] text-muted-foreground">Optional</span>
                )}
              </div>
              <Textarea
                placeholder={categories.albums ? "Enter album title (auto-generated if empty)..." : "Enter title..."}
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="min-h-[60px] text-sm"
              />
              {categories.albums && !title.trim() && (
                <p className="text-[10px] text-muted-foreground">
                  💡 If left empty, title will be auto-generated as "Premium Album - {new Date().toLocaleDateString()}"
                </p>
              )}
            </CardContent>
          </Card>
        )}

        {/* Caption/Description */}
        <Card className="glass border-border/50">
          <CardContent className="p-3 space-y-2">
            <Label className="text-small font-bold uppercase">
              {uploadType === 'premium' && categories.albums ? 'Description' : 'Caption'}
            </Label>
            <Textarea
              placeholder="Write something..."
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              className="min-h-[100px] text-sm"
            />
          </CardContent>
        </Card>

        {/* Upload Progress */}
        {uploading && (
          <Card className="glass border-border/50 border-primary/30">
            <CardContent className="p-3 space-y-3">
              <div className="flex items-center justify-between text-small">
                <span className="font-bold">Uploading...</span>
                <span className="text-primary font-bold">{Math.round(uploadProgress)}%</span>
              </div>
              <Progress value={uploadProgress} className="h-2" />
              {currentFileProgress && (
                <p className="text-[11px] text-muted-foreground animate-pulse">
                  {currentFileProgress}
                </p>
              )}
              <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                <Loader2 className="w-3 h-3 animate-spin" />
                <span>Please wait, do not close this page...</span>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Upload Errors */}
        {uploadErrors.length > 0 && !uploading && (
          <Card className="glass border-destructive/50 bg-destructive/5">
            <CardContent className="p-3 space-y-2">
              <div className="flex items-center gap-2 text-small font-bold text-destructive">
                <AlertCircle className="w-4 h-4" />
                Upload Errors ({uploadErrors.length})
              </div>
              <div className="space-y-1.5 max-h-32 overflow-y-auto">
                {uploadErrors.map((error, index) => (
                  <div key={index} className="text-[11px] p-2 bg-background/50 rounded-lg border border-border/30">
                    <p className="font-bold text-foreground">{error.file}</p>
                    <p className="text-destructive">{error.error}</p>
                    <p className="text-muted-foreground text-[10px] mt-0.5">Type: {error.type}</p>
                  </div>
                ))}
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setUploadErrors([])}
                className="w-full h-8 text-[11px]"
              >
                Clear Errors
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Upload Button */}
        <Button
          onClick={handleUpload}
          disabled={uploading || files.length === 0}
          className="w-full h-12 text-sm font-bold uppercase"
        >
          {uploading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Uploading...
            </>
          ) : (
            <>
              <Upload className="w-4 h-4 mr-2" />
              Upload {uploadType === 'premium' ? 'Premium' : 'Normal'} Content
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
