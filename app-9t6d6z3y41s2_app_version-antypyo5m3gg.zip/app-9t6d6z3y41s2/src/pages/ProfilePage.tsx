import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { supabase } from '@/db/supabase';
import type { Profile, Post } from '@/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Settings as SettingsIcon, ShieldCheck, Zap, Grid, Play, LogOut, Upload, Loader2, Sparkles, Star, Heart } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import Video from '@/components/ui/video';

export default function ProfilePage() {
  const { profile, signOut, isPremium, isAdmin } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [reels, setReels] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (!profile) return;
    
    const fetchUserContent = async () => {
      try {
        const { data: allUserContent } = await supabase
          .from('posts')
          .select('*')
          .eq('user_id', profile.id)
          .order('created_at', { ascending: false });
        
        if (allUserContent) {
          const casted = allUserContent as Post[];
          setPosts(casted.filter(p => p.type === 'post'));
          setReels(casted.filter(p => p.type === 'reel'));
        }
      } catch (error) {
        toast.error('Failed to fetch profile content');
      } finally {
        setLoading(false);
      }
    };

    fetchUserContent();
  }, [profile]);

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !profile) return;

    setUploadingAvatar(true);
    try {
      const fileName = `${profile.id}/avatar-${Date.now()}.jpg`;
      const { data, error } = await supabase.storage.from('primex_images').upload(fileName, file);
      if (error) throw error;

      const { data: { publicUrl } } = supabase.storage.from('primex_images').getPublicUrl(fileName);
      await api.updateProfile(profile.id, { profile_image: publicUrl });
      toast.success('Profile picture updated');
      window.location.reload(); // Quick refresh to update everywhere
    } catch (error: any) {
      toast.error(error.message || 'Avatar upload failed');
    } finally {
      setUploadingAvatar(false);
    }
  };

  if (!profile) return null;

  return (
    <div className="py-4 space-y-6 animate-fade-in max-w-4xl mx-auto px-3 md:px-0 pb-16 md:pb-8">
      {/* Profile Header */}
      <div className="flex flex-col items-center gap-4 md:flex-row md:items-start md:gap-8">
        <div className="relative group">
          <Avatar className="w-24 h-24 md:w-32 md:h-32 border-4 border-card ring-2 ring-primary/20 ring-offset-2 ring-offset-background shadow-2xl transition-transform group-hover:scale-105">
            <AvatarImage src={profile.profile_image || ''} className="object-cover" />
            <AvatarFallback className="bg-muted text-3xl font-black uppercase italic tracking-tighter">
              {profile.username?.[0]}
            </AvatarFallback>
          </Avatar>
          {isPremium && (
            <div className="absolute -top-1 -right-1 bg-primary text-primary-foreground p-1.5 rounded-xl shadow-xl animate-bounce border-2 border-background">
              <Star className="w-4 h-4 fill-current" />
            </div>
          )}
        </div>

        <div className="flex-1 space-y-4 text-center md:text-left">
          <div className="space-y-2">
            <div className="flex flex-col md:flex-row md:items-center gap-2">
               <h2 className="heading-main text-lg truncate max-w-[300px]">{profile.display_name || profile.username}</h2>
               <div className="flex items-center justify-center md:justify-start gap-1.5">
                  {isAdmin && (
                    <div className="bg-red-500/10 text-red-500 border border-red-500/30 px-2.5 py-1 rounded-full text-[9px] font-black uppercase italic tracking-tighter flex items-center gap-1 shadow-sm">
                      <ShieldCheck className="w-2.5 h-2.5" />
                      Admin
                    </div>
                  )}
                  {isPremium && (
                    <div className="bg-primary/10 text-primary border border-primary/30 px-2.5 py-1 rounded-full text-[9px] font-black uppercase italic tracking-tighter flex items-center gap-1 shadow-sm">
                      <Zap className="w-2.5 h-2.5 fill-current" />
                      Premium
                    </div>
                  )}
                  {profile.status === 'pending' && (
                    <div className="bg-yellow-500/10 text-yellow-500 border border-yellow-500/30 px-2.5 py-1 rounded-full text-[9px] font-black uppercase italic tracking-tighter shadow-sm">
                      Pending Approval
                    </div>
                  )}
               </div>
            </div>
            <div className="space-y-0.5">
              <p className="text-section font-bold tracking-tight opacity-80">@{profile.username}</p>
              <p className="text-normal font-medium text-muted-foreground line-clamp-2">{profile.bio || 'No bio yet.'}</p>
            </div>
          </div>

          <div className="flex items-center justify-center md:justify-start gap-8 border-y border-border/30 py-3">
            <div className="flex flex-col items-center">
              <p className="text-lg font-bold gradient-text">{posts.length}</p>
              <p className="text-small uppercase font-black tracking-tighter opacity-60">Posts</p>
            </div>
            <div className="flex flex-col items-center">
              <p className="text-lg font-bold gradient-text">{reels.length}</p>
              <p className="text-small uppercase font-black tracking-tighter opacity-60">Reels</p>
            </div>
            <div className="flex flex-col items-center">
              <p className="text-lg font-bold gradient-text">0</p>
              <p className="text-small uppercase font-black tracking-tighter opacity-60">Followers</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center md:justify-start gap-3">
            {(!isPremium && profile.subscription_status !== 'active') && (
              <Button variant="outline" className="rounded-xl font-bold gap-1.5 h-9 px-4 border-border/50 hover:bg-muted/50 transition-all hover:border-primary/30 text-small" onClick={() => navigate('/premium')}>
                <Sparkles className="w-3.5 h-3.5 text-primary" />
                Upgrade Plan
              </Button>
            )}
            <Button 
              variant="outline" 
              className="rounded-xl font-bold gap-1.5 h-9 px-4 border-border/50 hover:bg-muted/50 transition-all hover:border-primary/30 text-small"
              onClick={() => navigate('/edit-profile')}
            >
              <SettingsIcon className="w-3.5 h-3.5" />
              Edit Profile
            </Button>
            <Button variant="ghost" className="rounded-xl font-bold gap-1.5 h-9 px-4 text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-all text-small" onClick={async () => { await signOut(); navigate('/login', { replace: true }); }}>
              <LogOut className="w-3.5 h-3.5" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* Content Tabs */}
      <Tabs defaultValue="posts" className="w-full">
        <TabsList className="w-full h-11 bg-card/40 border border-border/50 p-1 rounded-xl mb-4">
          <TabsTrigger value="posts" className="flex-1 h-full rounded-lg gap-1.5 font-bold data-[state=active]:bg-primary/10 data-[state=active]:text-primary data-[state=active]:shadow-lg transition-all text-small">
            <Grid className="w-4 h-4" />
            Posts
          </TabsTrigger>
          <TabsTrigger value="reels" className="flex-1 h-full rounded-lg gap-1.5 font-bold data-[state=active]:bg-primary/10 data-[state=active]:text-primary data-[state=active]:shadow-lg transition-all text-small">
            <Play className="w-4 h-4" />
            Reels
          </TabsTrigger>
        </TabsList>

        <TabsContent value="posts" className="mt-0">
          {posts.length > 0 ? (
            <div className="grid grid-cols-3 gap-1 md:gap-2">
              {posts.map(post => (
                <div key={post.id} className="aspect-square bg-muted rounded-lg overflow-hidden cursor-pointer hover:opacity-80 transition-opacity relative group border border-border/20 shadow-md">
                   {post.media_type === 'video' ? (
                     <div className="w-full h-full relative">
                        <Video src={post.media_url} className="w-full h-full object-cover" muted loop />
                        <div className="absolute top-1.5 right-1.5">
                           <Play className="w-3 h-3 text-white fill-white" />
                        </div>
                     </div>
                   ) : (
                     <img src={post.media_url} className="w-full h-full object-cover" alt="" />
                   )}
                   <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 text-white">
                      <div className="flex items-center gap-1 font-bold text-xs">
                         <Heart className="w-4 h-4 fill-current" />
                         {post.likes_count}
                      </div>
                   </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-12 text-center space-y-3 glass rounded-2xl border-dashed border-2 border-border/50 p-6">
               <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center mx-auto mb-4 opacity-20">
                  <Grid className="w-6 h-6" />
               </div>
               <h3 className="text-xl font-black uppercase italic tracking-tighter opacity-60">No Posts Yet</h3>
               <p className="text-muted-foreground font-medium max-w-xs mx-auto text-small">Share your first moment with the world!</p>
               <Button onClick={() => navigate('/create')} className="rounded-xl h-9 px-6 font-bold shadow-lg text-small">Create Post</Button>
            </div>
          )}
        </TabsContent>

        <TabsContent value="reels" className="mt-0">
          {reels.length > 0 ? (
            <div className="grid grid-cols-3 gap-1 md:gap-2">
              {reels.map(reel => (
                <div key={reel.id} className="aspect-[9/16] bg-muted rounded-lg overflow-hidden cursor-pointer hover:opacity-80 transition-opacity relative group border border-border/20 shadow-md">
                   <Video src={reel.media_url} className="w-full h-full object-cover" muted loop />
                   <div className="absolute top-2 right-2 bg-black/20 backdrop-blur-sm p-1.5 rounded-full border border-white/20">
                      <Play className="w-3.5 h-3.5 text-white fill-white" />
                   </div>
                   <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 text-white">
                      <div className="flex items-center gap-1 font-bold text-xs">
                         <Heart className="w-4 h-4 fill-current" />
                         {reel.likes_count}
                      </div>
                   </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-12 text-center space-y-3 glass rounded-2xl border-dashed border-2 border-border/50 p-6">
               <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center mx-auto mb-4 opacity-20">
                  <Play className="w-6 h-6" />
               </div>
               <h3 className="text-xl font-black uppercase italic tracking-tighter opacity-60">No Reels Yet</h3>
               <p className="text-muted-foreground font-medium max-w-xs mx-auto text-small">Upload your first reel and reach more people!</p>
               <Button onClick={() => navigate('/create')} className="rounded-xl h-9 px-6 font-bold shadow-lg text-small">Create Reel</Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
