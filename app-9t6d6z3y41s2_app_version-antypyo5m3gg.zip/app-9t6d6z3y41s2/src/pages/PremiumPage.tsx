import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { Button } from '@/components/ui/button';
import { Zap, X, Star, Timer, Loader2, ShieldCheck, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import type { Settings } from '@/types';

export default function PremiumPage() {
  const { profile, refreshProfile, user } = useAuth();
  const [settings, setSettings] = useState<Settings | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [timeLeft, setTimeLeft] = useState(120); // 120 seconds
  const navigate = useNavigate();

  useEffect(() => {
    setLoading(true);
    api.getSettings().then((data) => {
      setSettings(data);
      setLoading(false);
    });
  }, []);

  useEffect(() => {
    if (timeLeft <= 0) {
      toast.info('QR session expired. Please click Get Access again.');
      setTimeLeft(120); // Auto reset timer as per prompt
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handlePaid = async () => {
    if (!user || !profile) {
      toast.error('Please login first to submit payment');
      navigate('/login');
      return;
    }

    setSubmitting(true);
    try {
      await api.updateProfile(profile.id, { 
        subscription_status: 'payment_pending'
      });
      await refreshProfile();
      toast.success('Payment request sent to admin for verification.');
      
      // Navigate to home after submission
      setTimeout(() => navigate('/'), 2000);
    } catch (error) {
      toast.error('Failed to submit payment status');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancel = () => {
    navigate('/login');
  };

  if (profile?.is_premium) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-background text-center">
        <div className="w-20 h-20 bg-primary/10 rounded-[2rem] flex items-center justify-center mb-6 border border-primary/20">
          <Star className="w-12 h-12 text-primary fill-primary" />
        </div>
        <h1 className="heading-main mb-4">You are already Premium!</h1>
        <Button onClick={() => navigate('/')} className="rounded-xl btn-standard h-12 px-8">Go to Home</Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-primary/10 flex flex-col relative overflow-hidden font-sans">
      {/* Decorative Blur */}
      <div className="absolute top-[-20%] left-[-10%] w-[500px] h-[500px] bg-primary/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-20%] right-[-10%] w-[500px] h-[500px] bg-blue-500/5 rounded-full blur-[120px] pointer-events-none" />

      {/* Cancel Button */}
      <div className="absolute top-6 right-6 z-50">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={handleCancel} 
          className="rounded-xl w-12 h-12 bg-muted/20 hover:bg-muted/40 transition-all border border-border/50 group"
        >
          <X className="w-6 h-6 group-hover:rotate-90 transition-transform duration-300" />
        </Button>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-6 space-y-12 max-w-lg mx-auto w-full relative z-10">
        {/* Header Section */}
        <div className="text-center space-y-4 animate-in fade-in slide-in-from-top-4 duration-700">
          <div className="flex justify-center mb-6">
            <div className="w-24 h-24 bg-primary/10 rounded-[2.5rem] flex items-center justify-center border border-primary/20 shadow-2xl animate-pulse ring-4 ring-primary/5">
              <Zap className="w-12 h-12 text-primary fill-primary" />
            </div>
          </div>
          <h1 className="heading-main text-5xl">
            GET PREMIUM ACCESS
          </h1>
          <p className="text-normal font-semibold text-muted-foreground max-w-xs mx-auto">
            Elevate your social experience to the next level
          </p>
        </div>

        {/* Payment Card */}
        <div className="w-full bg-card/40 backdrop-blur-xl border border-border/50 rounded-[3rem] p-8 shadow-2xl space-y-8 animate-in zoom-in duration-500">
          {/* Timer Section */}
          <div className="flex items-center justify-center gap-3 bg-background/50 border border-border/50 py-3 rounded-2xl">
            <Timer className="w-6 h-6 text-primary animate-pulse" />
            <span className={cn(
              "font-black italic text-2xl tracking-tighter transition-colors tabular-nums",
              timeLeft < 30 ? "text-destructive" : "text-primary"
            )}>
              {formatTime(timeLeft)}
            </span>
          </div>

          <div className="space-y-6 text-center">
            {/* QR Section */}
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-primary/50 to-blue-500/50 rounded-[2.5rem] blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200" />
              <div className="relative bg-white p-6 rounded-[2rem] aspect-square flex items-center justify-center border-4 border-primary/10 shadow-inner">
                {loading ? (
                  <Loader2 className="w-12 h-12 animate-spin text-primary" />
                ) : (
                  <img src={settings?.premium_qr_url || ''} alt="QR Code" className="w-full h-full object-contain" />
                )}
              </div>
            </div>

            <div className="bg-muted/30 border border-border/40 rounded-2xl p-4">
              <p className="text-normal font-bold text-muted-foreground leading-relaxed">
                {settings?.payment_text || "Scan the QR code to pay for premium subscription."}
              </p>
            </div>
          </div>

          {/* Action Button */}
          <Button 
            className="w-full h-16 rounded-[2rem] btn-standard text-2xl bg-gradient-primary border-none shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-primary/20 flex items-center justify-center gap-3"
            onClick={handlePaid}
            disabled={submitting || loading}
          >
            {submitting ? (
              <Loader2 className="w-8 h-8 animate-spin" />
            ) : (
              <>
                I HAVE PAID
                <ArrowRight className="w-7 h-7" />
              </>
            )}
          </Button>
        </div>

        {/* Benefits List (Visual only) */}
        <div className="grid grid-cols-2 gap-4 w-full px-4 text-meta font-black uppercase italic tracking-tighter">
           <div className="flex items-center gap-2">
             <div className="w-2 h-2 rounded-full bg-primary" />
             UNLIMITED POSTS
           </div>
           <div className="flex items-center gap-2">
             <div className="w-2 h-2 rounded-full bg-primary" />
             REELS ACCESS
           </div>
           <div className="flex items-center gap-2">
             <div className="w-2 h-2 rounded-full bg-primary" />
             PREMIUM BADGE
           </div>
           <div className="flex items-center gap-2">
             <div className="w-2 h-2 rounded-full bg-primary" />
             PRIORITY SUPPORT
           </div>
        </div>
      </div>
    </div>
  );
}
