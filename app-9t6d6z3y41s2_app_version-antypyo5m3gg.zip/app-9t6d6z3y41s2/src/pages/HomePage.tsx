import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { supabase } from '@/db/supabase';
import type { Post, Banner } from '@/types';
import { PostCard } from '@/components/common/PostCard';
import { HomeBanner } from '@/components/home/HomeBanner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, RefreshCcw, Search, X } from 'lucide-react';
import { toast } from 'sonner';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';

export default function HomePage() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [banners, setBanners] = useState<Banner[]>([]);
  const [loading, setLoading] = useState(true);
  const [bannersLoading, setBannersLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Post[]>([]);
  const [searching, setSearching] = useState(false);
  const { user, isApproved, isAdmin, isPremium } = useAuth();
  const navigate = useNavigate();

  const fetchBanners = async () => {
    try {
      const { data } = await supabase
        .from('banners')
        .select('*')
        .eq('is_active', true)
        .order('order_index', { ascending: true });
      setBanners(data || []);
    } catch (error) {
      console.error('Failed to fetch banners:', error);
    } finally {
      setBannersLoading(false);
    }
  };

  const fetchPosts = async () => {
    try {
      const data = await api.getPosts('post');
      setPosts(data);
    } catch (error) {
      toast.error('Failed to fetch posts');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchBanners();
    fetchPosts();

    // Real-time subscription for banners
    const bannersChannel = supabase
      .channel('banners-changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'banners',
      }, () => {
        fetchBanners();
      })
      .subscribe();

    // Real-time subscription for posts
    const postsChannel = supabase
      .channel('posts-changes')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'posts',
        filter: 'type=eq.post',
      }, () => {
        fetchPosts();
      })
      .subscribe();

    return () => {
      bannersChannel.unsubscribe();
      postsChannel.unsubscribe();
    };
  }, []);

  const handleDelete = async (postId: string) => {
    try {
      await api.deletePost(postId);
      setPosts((prev) => prev.filter((p) => p.id !== postId));
      toast.success('Post deleted');
    } catch (error) {
      toast.error('Failed to delete post');
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    fetchPosts();
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }

    if (!isPremium && !isAdmin) {
      toast.error('Search is only available for Premium users');
      return;
    }

    setSearching(true);
    try {
      const results = await api.searchPosts(searchQuery, isPremium || isAdmin);
      setSearchResults(results);
      if (results.length === 0) {
        toast.info('No results found');
      }
    } catch (error) {
      toast.error('Search failed');
    } finally {
      setSearching(false);
    }
  };

  const closeSearch = () => {
    setSearchOpen(false);
    setSearchQuery('');
    setSearchResults([]);
  };

  return (
    <div className="py-2 w-full mx-auto min-h-screen relative px-2 pb-16 md:pb-3">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-section font-bold">Feed</h2>
        <div className="flex items-center gap-1">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setSearchOpen(!searchOpen)} 
            className="w-8 h-8"
          >
            <Search className="w-4 h-4 text-muted-foreground" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={handleRefresh} 
            className={cn("w-8 h-8", refreshing && 'animate-spin')}
            disabled={loading || refreshing}
          >
            <RefreshCcw className="w-4 h-4 text-muted-foreground" />
          </Button>
        </div>
      </div>

      {/* Search Bar */}
      {searchOpen && (
        <div className="mb-3 animate-in slide-in-from-top-2 duration-300">
          <div className="flex items-center gap-2 bg-muted/20 border border-border/50 rounded-xl p-2">
            <Search className="w-4 h-4 text-muted-foreground ml-1" />
            <Input
              placeholder="Search posts..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              className="border-0 bg-transparent h-8 text-sm focus-visible:ring-0"
            />
            {searchQuery && (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSearchQuery('')}
                className="w-7 h-7"
              >
                <X className="w-3.5 h-3.5" />
              </Button>
            )}
            <Button
              onClick={handleSearch}
              disabled={searching || !searchQuery.trim()}
              className="h-8 px-3 text-xs"
            >
              {searching ? 'Searching...' : 'Search'}
            </Button>
          </div>
          {!isPremium && !isAdmin && (
            <p className="text-[10px] text-destructive mt-1 ml-1">
              🔒 Search is only available for Premium users
            </p>
          )}
        </div>
      )}

      {/* Search Results */}
      {searchResults.length > 0 && (
        <div className="mb-3">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-small font-bold">Search Results ({searchResults.length})</h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={closeSearch}
              className="h-7 text-[10px]"
            >
              Clear
            </Button>
          </div>
          <div className="flex flex-col gap-2">
            {searchResults.map((post) => (
              <PostCard key={post.id} post={post} onDelete={handleDelete} />
            ))}
          </div>
          <div className="h-px bg-border/50 my-4" />
        </div>
      )}

      {/* Banner Section */}
      <div className="mb-3">
        <HomeBanner banners={banners} loading={bannersLoading} />
      </div>

      {loading ? (
        <div className="flex flex-col gap-2">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="space-y-3">
              <div className="flex items-center gap-2">
                <Skeleton className="w-8 h-8 rounded-full bg-muted" />
                <div className="space-y-1">
                  <Skeleton className="h-3.5 w-28 bg-muted" />
                  <Skeleton className="h-3 w-20 bg-muted" />
                </div>
              </div>
              <Skeleton className="h-[350px] w-full rounded-xl bg-muted" />
            </div>
          ))}
        </div>
      ) : posts.length > 0 ? (
        <div className="flex flex-col gap-2 animate-fade-in">
          {posts.map((post) => (
            <PostCard key={post.id} post={post} onDelete={handleDelete} />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-12 text-center px-4">
          <div className="w-14 h-14 bg-muted rounded-full flex items-center justify-center mb-3">
            <Plus className="w-7 h-7 text-muted-foreground opacity-20" />
          </div>
          <h3 className="text-lg font-bold mb-2">No posts yet</h3>
          <p className="text-muted-foreground mb-6 max-w-xs text-normal">Be the first to share something amazing with the Primex community!</p>
          <Button onClick={() => navigate('/create')} className="rounded-xl h-11 px-7 font-bold text-base shadow-lg">
            Create First Post
          </Button>
        </div>
      )}

      {/* Floating Create Button - Admin Only */}
      {isAdmin && (
        <Button
          onClick={() => navigate('/create')}
          className="fixed bottom-20 right-5 md:bottom-7 md:right-7 w-14 h-14 rounded-full shadow-2xl bg-primary hover:bg-primary/90 text-primary-foreground transition-all hover:scale-110 active:scale-95 z-40 border-4 border-background"
        >
          <Plus className="w-7 h-7 stroke-[3]" />
        </Button>
      )}
    </div>
  );
}
