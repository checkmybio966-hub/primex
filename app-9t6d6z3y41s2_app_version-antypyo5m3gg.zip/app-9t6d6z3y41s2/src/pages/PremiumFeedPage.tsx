import { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import type { Post, Album, FileItem } from '@/types';
import { PostCard } from '@/components/common/PostCard';
import { ReelCard } from '@/components/common/ReelCard';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Lock, Sparkles, ShieldCheck, Play, LayoutGrid, FolderOpen, FileIcon, Image as ImageIcon, Video as VideoIcon } from 'lucide-react';
import { toast } from 'sonner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function PremiumFeedPage() {
  const { profile, isPremium, isAdmin } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const [posts, setPosts] = useState<Post[]>([]);
  const [reels, setReels] = useState<Post[]>([]);
  const [albums, setAlbums] = useState<Album[]>([]);
  const [files, setFiles] = useState<FileItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('posts');
  const [activeIndex, setActiveIndex] = useState(0);
  const [showDebug, setShowDebug] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const scrollPos = e.currentTarget.scrollTop;
    const height = e.currentTarget.clientHeight;
    const index = Math.round(scrollPos / height);
    if (index !== activeIndex) {
      setActiveIndex(index);
    }
  };

  const hasAccess = isPremium || isAdmin;

  // Handle URL parameters for tab switching and refresh
  useEffect(() => {
    const tab = searchParams.get('tab');
    const shouldRefresh = searchParams.get('refresh');
    
    if (tab) {
      console.log(`[URL PARAM] Switching to tab: ${tab}`);
      setActiveTab(tab);
    }
    
    if (shouldRefresh === 'true' && hasAccess) {
      console.log('[URL PARAM] Refresh requested, fetching content...');
      fetchPremiumContent();
    }
    
    // Clear URL parameters after processing
    if (tab || shouldRefresh) {
      setSearchParams({});
    }
  }, [searchParams]);

  useEffect(() => {
    console.log('[MOUNT] ═══════════════════════════════════════');
    console.log('[MOUNT] PremiumFeedPage mounted');
    console.log('[MOUNT] ═══════════════════════════════════════');
    console.log('[MOUNT] User:', profile?.username);
    console.log('[MOUNT] User ID:', profile?.id);
    console.log('[MOUNT] User Role:', profile?.role);
    console.log('[MOUNT] Is Admin:', isAdmin);
    console.log('[MOUNT] Is Premium:', isPremium);
    console.log('[MOUNT] Has Access:', hasAccess);
    console.log('[MOUNT] ═══════════════════════════════════════');
    
    if (hasAccess) {
      console.log('[MOUNT] ✓ Has access - fetching content');
      fetchPremiumContent();
      
      // Set up real-time subscription for albums
      console.log('[REALTIME] Setting up albums subscription');
      const albumsChannel = api.supabase
        .channel('albums-changes')
        .on('postgres_changes', {
          event: '*',
          schema: 'public',
          table: 'albums',
        }, (payload) => {
          console.log('[REALTIME] Albums change detected:', payload);
          // Refresh albums when changes occur
          fetchPremiumContent();
        })
        .subscribe();

      return () => {
        console.log('[REALTIME] Cleaning up albums subscription');
        albumsChannel.unsubscribe();
      };
    } else {
      console.log('[MOUNT] ❌ No access - skipping fetch');
      setLoading(false);
    }
  }, [hasAccess]);

  // Force refresh when switching to albums tab
  useEffect(() => {
    if (activeTab === 'albums' && hasAccess) {
      console.log('[TAB SWITCH] Albums tab activated, refreshing...');
      fetchPremiumContent();
    }
  }, [activeTab]);

  // Log albums state changes
  useEffect(() => {
    console.log('[STATE] ═══════════════════════════════════════');
    console.log('[STATE] Albums state changed');
    console.log('[STATE] Albums length:', albums.length);
    console.log('[STATE] Albums:', albums.map(a => ({ id: a.id, title: a.title, is_premium: a.is_premium })));
    console.log('[STATE] ═══════════════════════════════════════');
  }, [albums]);

  const fetchPremiumContent = async () => {
    console.log('[FETCH] ═══════════════════════════════════════');
    console.log('[FETCH] Fetching premium content...');
    console.log('[FETCH] ═══════════════════════════════════════');
    setLoading(true);
    try {
      console.log('[FETCH] Calling API functions...');
      const [postsData, reelsData, albumsData, filesData] = await Promise.all([
        api.getPosts('post', 20, 0, true),
        api.getPosts('reel', 20, 0, true),
        api.getAlbums(true, 20, 0),
        api.getFiles()
      ]);
      
      console.log('[FETCH] ═══════════════════════════════════════');
      console.log('[FETCH] ✓ Premium content fetched successfully');
      console.log('[FETCH] ═══════════════════════════════════════');
      console.log('[FETCH] Posts:', postsData.length);
      console.log('[FETCH] Reels:', reelsData.length);
      console.log('[FETCH] Albums:', albumsData.length);
      console.log('[FETCH] Files:', filesData.length);
      console.log('[FETCH] ═══════════════════════════════════════');
      console.log('[FETCH] Albums data:', albumsData.map(a => ({
        id: a.id,
        title: a.title,
        is_premium: a.is_premium,
        media_count: a.media_items?.length || 0
      })));
      console.log('[FETCH] ═══════════════════════════════════════');
      
      setPosts(postsData);
      setReels(reelsData);
      setAlbums(albumsData);
      setFiles(filesData);
      
      console.log('[STATE] State updated with fetched data');
      console.log('[STATE] Albums state length:', albumsData.length);
      
      // Show success toast if albums were fetched and we're on albums tab
      if (activeTab === 'albums' && albumsData.length > 0) {
        toast.success(`Loaded ${albumsData.length} premium album${albumsData.length !== 1 ? 's' : ''}`);
      }
    } catch (error) {
      console.error('[FETCH ERROR] ═══════════════════════════════════════');
      console.error('[FETCH ERROR] Failed to fetch premium content');
      console.error('[FETCH ERROR] ═══════════════════════════════════════');
      console.error('[FETCH ERROR] Error:', error);
      console.error('[FETCH ERROR] ═══════════════════════════════════════');
      toast.error('Failed to fetch premium content');
    } finally {
      setLoading(false);
      console.log('[FETCH] Loading state set to false');
    }
  };

  const handleDeletePost = async (postId: string) => {
    try {
      await api.deletePost(postId);
      setPosts(posts.filter(p => p.id !== postId));
      setReels(reels.filter(p => p.id !== postId));
      toast.success('Post deleted');
    } catch (error) {
      toast.error('Failed to delete post');
    }
  };

  const handleDeleteAlbum = async (albumId: string) => {
    try {
      await api.deleteAlbum(albumId);
      setAlbums(albums.filter(a => a.id !== albumId));
      toast.success('Album deleted');
    } catch (error) {
      toast.error('Failed to delete album');
    }
  };

  // DEBUG: Fetch ALL albums without premium filter
  const fetchAllAlbumsDebug = async () => {
    console.log('[DEBUG] ═══════════════════════════════════════');
    console.log('[DEBUG] FETCHING ALL ALBUMS (NO FILTER)');
    console.log('[DEBUG] ═══════════════════════════════════════');
    
    try {
      const allAlbums = await api.getAlbums(false, 50, 0); // No premium filter
      
      console.log('[DEBUG] Total albums in database:', allAlbums.length);
      console.log('[DEBUG] Albums:', allAlbums.map(a => ({
        id: a.id,
        title: a.title,
        is_premium: a.is_premium,
        media_count: a.media_items?.length || 0,
        created_at: a.created_at
      })));
      
      const premiumCount = allAlbums.filter(a => a.is_premium).length;
      const normalCount = allAlbums.filter(a => !a.is_premium).length;
      
      console.log('[DEBUG] Premium albums:', premiumCount);
      console.log('[DEBUG] Normal albums:', normalCount);
      console.log('[DEBUG] ═══════════════════════════════════════');
      
      toast.success(`Found ${allAlbums.length} total albums (${premiumCount} premium, ${normalCount} normal)`);
      
      // Update state with all albums for debugging
      setAlbums(allAlbums);
    } catch (error) {
      console.error('[DEBUG] Failed to fetch albums:', error);
      toast.error('Debug fetch failed');
    }
  };

  if (loading) {
    return (
      <div className="space-y-8 max-w-2xl mx-auto py-8 px-4">
        <Skeleton className="h-10 w-full rounded-2xl bg-muted/20" />
        {[1, 2, 3].map((i) => (
          <div key={i} className="space-y-4">
            <Skeleton className="h-[400px] w-full rounded-3xl bg-muted/20" />
          </div>
        ))}
      </div>
    );
  }

  if (!hasAccess) {
    return (
      <div className="min-h-[80vh] flex flex-col items-center justify-center p-6 text-center space-y-8 max-w-md mx-auto">
        <div className="relative">
          <div className="w-32 h-32 bg-primary/10 rounded-[2.5rem] flex items-center justify-center border border-primary/20 shadow-2xl animate-pulse">
            <Lock className="w-16 h-16 text-primary" />
          </div>
          <div className="absolute -top-2 -right-2 bg-yellow-500 rounded-full p-2 shadow-lg border-4 border-background">
            <Sparkles className="w-6 h-6 text-white fill-white" />
          </div>
        </div>

        <div className="space-y-4">
          <h1 className="text-2xl font-black uppercase italic tracking-tighter">PREMIUM ACCESS</h1>
          <p className="text-section font-semibold text-muted-foreground">
            Upgrade to Premium to unlock exclusive posts and reels from our top creators.
          </p>
        </div>

        <Button 
          onClick={() => navigate('/premium')}
          className="w-full h-11 rounded-xl text-sm font-bold uppercase bg-gradient-primary border-none shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-primary/20 flex items-center justify-center gap-2"
        >
          UPGRADE NOW
          <Sparkles className="w-4 h-4 animate-pulse" />
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto py-3 px-3 pb-16 md:pb-4">
      {/* Debug Panel (Admin Only) */}
      {isAdmin && showDebug && (
        <Card className="glass border-primary/30 mb-4">
          <CardContent className="p-3 space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-small font-bold text-primary">🔍 Debug Info</h3>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={fetchAllAlbumsDebug}
                  className="h-6 text-[10px] border-yellow-500/50 text-yellow-500"
                >
                  Fetch All Albums
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowDebug(false)}
                  className="h-6 text-[10px]"
                >
                  Hide
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2 bg-muted/20 rounded">
                <p className="font-bold">Posts</p>
                <p className="text-muted-foreground">{posts.length} items</p>
              </div>
              <div className="p-2 bg-muted/20 rounded">
                <p className="font-bold">Reels</p>
                <p className="text-muted-foreground">{reels.length} items</p>
              </div>
              <div className="p-2 bg-muted/20 rounded">
                <p className="font-bold">Albums</p>
                <p className="text-muted-foreground">{albums.length} items</p>
              </div>
              <div className="p-2 bg-muted/20 rounded">
                <p className="font-bold">Files</p>
                <p className="text-muted-foreground">{files.length} items</p>
              </div>
            </div>
            <div className="p-2 bg-muted/20 rounded text-[10px]">
              <p className="font-bold mb-1">Recent Albums:</p>
              {albums.slice(0, 3).map(a => (
                <p key={a.id} className="text-muted-foreground">
                  • {a.title} ({a.media_items?.length || 0} media, premium: {a.is_premium ? '✓' : '✗'})
                </p>
              ))}
              {albums.length === 0 && (
                <p className="text-destructive">No albums found with current filter</p>
              )}
            </div>
            <div className="p-2 bg-yellow-500/10 rounded border border-yellow-500/30 text-[10px]">
              <p className="font-bold text-yellow-500 mb-1">💡 Debug Tips:</p>
              <ul className="text-muted-foreground space-y-0.5">
                <li>• Click "Fetch All Albums" to see all albums (no filter)</li>
                <li>• Check browser console (F12) for detailed logs</li>
                <li>• Upload test album from Upload page</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="posts" onValueChange={setActiveTab} className="w-full">
        <div className="flex flex-col items-center gap-4 mb-6">
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary fill-primary animate-pulse" />
              <h1 className="text-section font-bold">PREMIUM FEED</h1>
            </div>
            <div className="flex items-center gap-2">
              {isAdmin && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowDebug(!showDebug)}
                  className="h-8 text-[11px]"
                >
                  {showDebug ? 'Hide' : 'Debug'}
                </Button>
              )}
              <Button
                variant="ghost"
                size="sm"
                onClick={fetchPremiumContent}
                disabled={loading}
                className="h-8 text-[11px]"
              >
                {loading ? 'Loading...' : 'Refresh'}
              </Button>
            </div>
          </div>
          <TabsList className="bg-muted/40 p-1 h-10 rounded-xl border border-border/50 grid grid-cols-4 w-full max-w-lg">
            <TabsTrigger 
              value="posts" 
              className="rounded-lg flex items-center gap-1.5 data-[state=active]:bg-primary data-[state=active]:text-white transition-all font-semibold text-[10px]"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              Posts
            </TabsTrigger>
            <TabsTrigger 
              value="reels" 
              className="rounded-lg flex items-center gap-1.5 data-[state=active]:bg-primary data-[state=active]:text-white transition-all font-semibold text-[10px]"
            >
              <Play className="w-3.5 h-3.5" />
              Reels
            </TabsTrigger>
            <TabsTrigger 
              value="albums" 
              className="rounded-lg flex items-center gap-1.5 data-[state=active]:bg-primary data-[state=active]:text-white transition-all font-semibold text-[10px]"
            >
              <FolderOpen className="w-3.5 h-3.5" />
              Albums
            </TabsTrigger>
            <TabsTrigger 
              value="files" 
              className="rounded-lg flex items-center gap-1.5 data-[state=active]:bg-primary data-[state=active]:text-white transition-all font-semibold text-[10px]"
            >
              <FileIcon className="w-3.5 h-3.5" />
              Files
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="posts" className="animate-in fade-in duration-500">
          {posts.length > 0 ? (
            <div className="flex flex-col gap-3">
              {posts.map((post) => (
                <PostCard key={post.id} post={post} onDelete={handleDeletePost} />
              ))}
            </div>
          ) : (
             <EmptyState message="No Premium Posts Yet" />
          )}
        </TabsContent>

        <TabsContent value="reels" className="animate-in fade-in duration-500">
          {reels.length > 0 ? (
            <div 
              ref={containerRef}
              onScroll={handleScroll}
              className="h-[calc(100vh-220px)] w-full overflow-y-scroll snap-y snap-mandatory scrollbar-hide bg-black rounded-2xl border border-border/50 shadow-2xl relative"
            >
               {reels.map((reel, index) => (
                  <div key={reel.id} className="h-full w-full snap-start shrink-0 relative">
                    <ReelCard 
                      reel={reel} 
                      isActive={activeIndex === index && activeTab === 'reels'} 
                      preload={Math.abs(activeIndex - index) <= 1}
                      onDelete={handleDeletePost}
                    />
                  </div>
               ))}
            </div>
          ) : (
            <EmptyState message="No Premium Reels Yet" />
          )}
        </TabsContent>

        <TabsContent value="albums" className="animate-in fade-in duration-500">
          {loading ? (
            <div className="space-y-3">
              <div className="flex items-center justify-center p-4 bg-primary/10 rounded-lg border border-primary/20">
                <div className="flex items-center gap-2 text-primary">
                  <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                  <span className="text-small font-semibold">Loading Premium Albums...</span>
                </div>
              </div>
              <div className="grid grid-cols-1 gap-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-48 w-full rounded-xl bg-muted/20" />
                ))}
              </div>
            </div>
          ) : albums.length > 0 ? (
            <>
              <div className="mb-3 p-3 bg-gradient-to-r from-primary/10 to-primary/5 rounded-lg border border-primary/20">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                      <FolderOpen className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-small font-bold text-foreground">
                        {albums.length} Premium Album{albums.length !== 1 ? 's' : ''}
                      </p>
                      <p className="text-[10px] text-muted-foreground">
                        Tap any album to view media
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        console.log('[MANUAL REFRESH] User clicked refresh button');
                        fetchPremiumContent();
                      }}
                      className="h-7 px-2 text-[10px]"
                    >
                      🔄 Refresh
                    </Button>
                    <Sparkles className="w-5 h-5 text-primary animate-pulse" />
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-1 gap-3">
                {albums.map((album) => {
                  console.log('[RENDER] Rendering album card:', {
                    id: album.id,
                    title: album.title,
                    is_premium: album.is_premium,
                    media_count: album.media_items?.length || 0
                  });
                  return <AlbumCard key={album.id} album={album} onDelete={handleDeleteAlbum} />;
                })}
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="w-20 h-20 bg-primary/10 rounded-3xl flex items-center justify-center mb-4 border border-primary/20">
                <FolderOpen className="w-10 h-10 text-primary" />
              </div>
              <h3 className="text-section font-bold mb-2">No Premium Albums Yet</h3>
              <p className="text-small text-muted-foreground max-w-xs mb-4">
                Premium albums will appear here once they are created
              </p>
              <div className="space-y-3 w-full max-w-xs">
                <div className="p-3 bg-muted/10 rounded-lg border border-border/50">
                  <p className="text-[11px] text-muted-foreground mb-2">
                    💡 <strong>Debug Info:</strong>
                  </p>
                  <ul className="text-[10px] text-muted-foreground space-y-1 text-left">
                    <li>• Fetched {albums.length} albums with premium filter</li>
                    <li>• Real-time updates: Active</li>
                    <li>• User access: {hasAccess ? 'Granted' : 'Denied'}</li>
                    <li>• Check browser console (F12) for detailed logs</li>
                  </ul>
                </div>
                <Button 
                  onClick={() => {
                    console.log('[MANUAL REFRESH] User clicked refresh from empty state');
                    fetchPremiumContent();
                  }}
                  variant="outline"
                  className="w-full h-10 px-6 rounded-xl"
                >
                  🔄 Refresh Albums
                </Button>
                {isAdmin && (
                  <>
                    <Button 
                      onClick={() => navigate('/upload')}
                      className="w-full h-10 px-6 rounded-xl"
                    >
                      <Sparkles className="w-4 h-4 mr-2" />
                      Create Album
                    </Button>
                    <Button 
                      onClick={fetchAllAlbumsDebug}
                      variant="outline"
                      className="w-full h-10 px-6 rounded-xl border-yellow-500/50 text-yellow-500"
                    >
                      🔍 Fetch All Albums (No Filter)
                    </Button>
                  </>
                )}
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="files" className="animate-in fade-in duration-500">
          {files.length > 0 ? (
            <div className="grid grid-cols-1 gap-2">
              {files.map((file) => (
                <FileCard key={file.id} file={file} />
              ))}
            </div>
          ) : (
            <EmptyState message="No Premium Files Yet" />
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function EmptyState({ message }: { message: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-10 text-center space-y-4">
      <div className="w-14 h-14 bg-muted/20 rounded-2xl flex items-center justify-center border border-border/50">
        <Lock className="w-7 h-7 text-muted-foreground" />
      </div>
      <div className="space-y-1">
        <h2 className="text-section font-black uppercase italic tracking-tighter">{message}</h2>
        <p className="text-small text-muted-foreground">Check back later for exclusive content!</p>
      </div>
    </div>
  );
}

function AlbumCard({ album, onDelete }: { album: Album; onDelete: (id: string) => void }) {
  const { isAdmin } = useAuth();
  const navigate = useNavigate();

  const mediaCount = album.media_items?.length || 0;
  const imageCount = album.media_items?.filter(m => m.type === 'image').length || 0;
  const videoCount = album.media_items?.filter(m => m.type === 'video').length || 0;

  return (
    <Card 
      className="glass border-border/50 overflow-hidden group cursor-pointer hover:border-primary/30 transition-all active:scale-[0.98]"
      onClick={() => navigate(`/album/${album.id}`)}
    >
      <div className="relative aspect-video bg-muted/20">
        {album.thumbnail_url ? (
          <img 
            src={album.thumbnail_url} 
            alt={album.title || 'Album'} 
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <FolderOpen className="w-12 h-12 text-muted-foreground opacity-30" />
          </div>
        )}
        
        {/* Premium Badge */}
        {album.is_premium && (
          <div className="absolute top-2 left-2 bg-primary/90 backdrop-blur-sm px-2 py-1 rounded-lg flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-white" />
            <span className="text-[10px] font-bold text-white uppercase">Premium</span>
          </div>
        )}

        {/* Media Count Badge */}
        <div className="absolute top-2 right-2 bg-black/70 backdrop-blur-sm px-2 py-1 rounded-lg">
          <span className="text-[10px] text-white font-bold">{mediaCount} items</span>
        </div>

        {/* Delete Button (Admin Only) */}
        {isAdmin && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onDelete(album.id);
            }}
            className="absolute bottom-2 right-2 w-7 h-7 rounded-full bg-destructive/90 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <svg className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
          </button>
        )}

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>

      <CardContent className="p-3">
        <h3 className="text-section font-bold line-clamp-1 mb-1">
          {album.title || 'Untitled Album'}
        </h3>
        
        {album.description && (
          <p className="text-small text-muted-foreground line-clamp-2 mb-2">
            {album.description}
          </p>
        )}

        {/* Media Type Breakdown */}
        <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
          {imageCount > 0 && (
            <div className="flex items-center gap-1">
              <ImageIcon className="w-3 h-3" />
              <span className="font-bold">{imageCount}</span>
            </div>
          )}
          {videoCount > 0 && (
            <div className="flex items-center gap-1">
              <VideoIcon className="w-3 h-3" />
              <span className="font-bold">{videoCount}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

function FileCard({ file }: { file: FileItem }) {
  const [signedUrl, setSignedUrl] = useState<string>('');

  useEffect(() => {
    api.getFileSignedUrl(file.url).then(setSignedUrl).catch(console.error);
  }, [file.url]);

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <Card className="glass border-border/50 hover:border-primary/30 transition-all">
      <CardContent className="p-3 flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
          <FileIcon className="w-5 h-5 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-small font-bold line-clamp-1">{file.name}</h3>
          <p className="text-[10px] text-muted-foreground">{formatFileSize(file.size)}</p>
        </div>
        {signedUrl && (
          <Button
            size="sm"
            variant="outline"
            onClick={() => window.open(signedUrl, '_blank')}
            className="h-8 text-[10px]"
          >
            View
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
