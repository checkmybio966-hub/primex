import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import { api } from '@/db/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Zap, ShieldCheck, Lock, ArrowRight, Eye, EyeOff, Sparkles, Gem } from 'lucide-react';
import { toast } from 'sonner';

export default function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const { signInWithUsername, signUpWithUsername, profile, isPremium } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      toast.error('Please fill in all fields');
      return;
    }

    setLoading(true);
    
    // Explicitly handle the requested admin logic
    if (username === "admin" && (password === "admin123" || password === "password" || password === "password123")) {
       const adminPassword = password;
       let { error: signInError } = await signInWithUsername("admin", adminPassword);
       
       if (signInError) {
          toast.info("Initializing administrator account, please wait...");
          // If the account doesn't exist, try to sign it up automatically for this demo
          const { error: signUpError } = await signUpWithUsername("admin", adminPassword);
          
          if (signUpError) {
             console.error("Admin sign-up failed:", signUpError.message);
             // If already registered, it means sign-in failed because of a different password
             if (signUpError.message.includes("already registered")) {
                toast.error(`Admin account already exists with a different password. Please contact support.`);
             } else {
                toast.error(`Admin Initialization Error: ${signUpError.message}`);
             }
             setLoading(false);
             return;
          }
          
          // After sign up, make sure it's an admin in the profiles table
          const { data: { session } } = await supabase.auth.getSession();
          if (session?.user) {
            await api.updateProfile(session.user.id, { role: 'admin', status: 'approved' });
          }

          // Now sign in after successful sign-up
          const { error: secondSignInError } = await signInWithUsername("admin", adminPassword);
          if (secondSignInError) {
             console.error("Second admin sign-in failed:", secondSignInError.message);
             toast.error(`Admin Login Error: ${secondSignInError.message}`);
             setLoading(false);
             return;
          }
       }
       
       // Success
       toast.success('Administrator Login successful!');
       setLoading(false);
       navigate('/admin');
       return;
    }

    const { error } = await signInWithUsername(username, password);
    setLoading(false);

    if (error) {
      toast.error(error.message || 'Login failed');
    } else {
      toast.success('Login successful!');
      const profileData = await api.getProfile((await supabase.auth.getSession()).data.session?.user.id || '');
      if (profileData?.role === 'admin') {
        navigate('/admin');
      } else {
        navigate('/');
      }
    }
  };

  // Common function for all "Get Access" buttons - Fast navigation
  const handleGetAccess = (plan: 'premium' | 'exclusive', price: number) => {
    const currentUsername = username || profile?.username || 'Guest';
    
    // Instant navigation with username
    navigate('/qr-payment', { 
      state: { 
        plan, 
        price,
        username: currentUsername
      },
      replace: false
    });
  };

  const isActive = profile?.subscription_status === 'active';

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-background relative overflow-hidden">
      {/* Decorative Circles */}
      <div className="absolute top-[-10%] right-[-10%] w-96 h-96 bg-primary/20 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-10%] w-96 h-96 bg-blue-500/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="w-full max-w-md space-y-8 relative z-10">
        <div className="flex flex-col items-center gap-4 mb-8">
          <div className="w-20 h-20 bg-primary/10 rounded-3xl flex items-center justify-center border border-primary/20 shadow-lg animate-fade-in">
             <Zap className="w-12 h-12 text-primary fill-primary" />
          </div>
          <h1 className="text-5xl font-black italic tracking-tighter uppercase gradient-text animate-slide-in">Primex</h1>
          <p className="text-normal font-medium text-muted-foreground">Join the premium social experience</p>
        </div>

        <Card className="glass border-border/50 shadow-card animate-fade-in rounded-[1.5rem]">
          <CardHeader>
            <CardTitle className="text-section font-bold flex items-center gap-2">
              <Lock className="w-5 h-5 text-primary" />
              Sign In
            </CardTitle>
            <CardDescription className="text-meta">Enter your username and password to access your account</CardDescription>
          </CardHeader>
          <form onSubmit={handleLogin}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Input
                  placeholder="Username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="bg-background/50 border-border/50 h-12 rounded-xl text-normal font-medium focus:ring-primary/50 transition-all px-4"
                  required
                />
              </div>
              <div className="space-y-2">
                <div className="relative">
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="bg-background/50 border-border/50 h-12 rounded-xl text-normal font-medium focus:ring-primary/50 transition-all px-4 pr-12"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col gap-4">
              <Button type="submit" className="w-full h-12 rounded-xl btn-standard shadow-xl hover:shadow-primary/20 transition-all" disabled={loading}>
                {loading ? 'Signing in...' : 'Sign In'}
              </Button>
              <p className="text-meta text-center">
                Don't have an account?{' '}
                <Link to="/register" className="text-primary hover:underline font-bold">
                  Create Account
                </Link>
              </p>
            </CardFooter>
          </form>
        </Card>

        {/* Plans Section */}
        <div className="space-y-4 animate-fade-in [animation-delay:200ms]">
          <h3 className="text-center text-body font-semibold text-muted-foreground">Choose Your Plan</h3>
          
          {/* Premium Plan */}
          <Card className="bg-gradient-to-br from-primary/20 to-blue-600/10 border-primary/30 shadow-card hover:shadow-lg transition-all rounded-2xl">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
                    <Sparkles className="w-6 h-6 text-primary fill-primary" />
                  </div>
                  <div>
                    <h4 className="text-body font-bold flex items-center gap-2">
                      Premium Plan ✨
                    </h4>
                    <p className="text-small text-muted-foreground font-semibold">₹299 INR</p>
                  </div>
                </div>
                <Button 
                  onClick={() => handleGetAccess('premium', 299)}
                  className="h-10 px-6 rounded-xl bg-primary hover:bg-primary/90 text-white font-semibold transition-all active:scale-95"
                >
                  Get Access
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Exclusive Plan */}
          <Card className="bg-gradient-to-br from-purple-500/20 to-pink-600/10 border-purple-500/30 shadow-card hover:shadow-lg transition-all rounded-2xl">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center">
                    <Gem className="w-6 h-6 text-purple-400 fill-purple-400" />
                  </div>
                  <div>
                    <h4 className="text-body font-bold flex items-center gap-2">
                      Exclusive Plan 💎
                    </h4>
                    <p className="text-small text-muted-foreground font-semibold">Premium Content</p>
                  </div>
                </div>
                <Button 
                  onClick={() => handleGetAccess('exclusive', 0)}
                  className="h-10 px-6 rounded-xl bg-purple-500 hover:bg-purple-600 text-white font-semibold transition-all active:scale-95"
                >
                  Get Access
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Old Premium Access Section - Only show if not logged in */}
        {(!isPremium && !isActive && !profile) && (
          <Card className="bg-gradient-to-br from-primary/20 to-blue-600/10 border-primary/30 shadow-lg animate-fade-in [animation-delay:400ms] rounded-[1.5rem]">
            <CardHeader className="text-center">
              <CardTitle className="text-section font-bold flex items-center justify-center gap-2">
                <ShieldCheck className="w-6 h-6 text-primary" />
                Unlock Premium Access
              </CardTitle>
              <CardDescription className="text-body text-foreground/80">
                Subscribe to unlock full features, unlimited uploads, and reels
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                className="w-full h-14 bg-gradient-primary border-none rounded-xl btn-standard shadow-xl hover:scale-[1.02] transition-transform flex items-center justify-center gap-2 group active:scale-95"
                onClick={() => handleGetAccess('premium', 299)}
              >
                GET ACCESS
                <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
