import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Zap, UserPlus } from 'lucide-react';
import { toast } from 'sonner';

export default function RegisterPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { signUpWithUsername } = useAuth();
  const navigate = useNavigate();

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password || !confirmPassword) {
      toast.error('Please fill in all fields');
      return;
    }

    if (username.length < 3) {
      toast.error('Username must be at least 3 characters');
      return;
    }

    if (password.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }

    if (password !== confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }

    setLoading(true);
    const { error } = await signUpWithUsername(username, password);
    setLoading(false);

    if (error) {
      toast.error(error.message || 'Registration failed');
    } else {
      toast.success('Registration successful! Please login.');
      navigate('/login');
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-background relative overflow-hidden">
      <div className="absolute top-[-10%] left-[-10%] w-96 h-96 bg-primary/20 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-96 h-96 bg-blue-500/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="w-full max-w-md space-y-8 relative z-10">
        <div className="flex flex-col items-center gap-4 mb-8">
          <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center border border-primary/20 shadow-lg animate-fade-in">
             <Zap className="w-10 h-10 text-primary fill-primary" />
          </div>
          <h1 className="text-4xl font-black italic tracking-tighter uppercase gradient-text animate-slide-in">Primex</h1>
          <p className="text-normal font-medium text-muted-foreground">Create your account</p>
        </div>

        <Card className="glass border-border/50 shadow-card animate-fade-in rounded-[1.5rem]">
          <CardHeader>
            <CardTitle className="text-section font-bold flex items-center gap-2">
              <UserPlus className="w-5 h-5 text-primary" />
              Sign Up
            </CardTitle>
            <CardDescription className="text-meta">Enter your details to create a new account</CardDescription>
          </CardHeader>
          <form onSubmit={handleRegister}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Input
                  placeholder="Username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                  className="bg-background/50 border-border/50 h-12 rounded-xl text-normal font-medium focus:ring-primary/50 transition-all px-4"
                  required
                />
                <p className="text-meta opacity-50 ml-1 italic font-medium">Lowercase letters, numbers, and underscores only</p>
              </div>
              <div className="space-y-2">
                <Input
                  type="password"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-background/50 border-border/50 h-12 rounded-xl text-normal font-medium focus:ring-primary/50 transition-all px-4"
                  required
                />
              </div>
              <div className="space-y-2">
                <Input
                  type="password"
                  placeholder="Confirm Password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="bg-background/50 border-border/50 h-12 rounded-xl text-normal font-medium focus:ring-primary/50 transition-all px-4"
                  required
                />
              </div>
            </CardContent>
            <CardFooter className="flex flex-col gap-4">
              <Button type="submit" className="w-full h-12 rounded-xl btn-standard shadow-xl hover:shadow-primary/20 transition-all" disabled={loading}>
                {loading ? 'Registering...' : 'Register'}
              </Button>
              <p className="text-meta text-center">
                Already have an account?{' '}
                <Link to="/login" className="text-primary hover:underline font-bold">
                  Sign In
                </Link>
              </p>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  );
}
