import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { supabase } from '@/db/supabase';
import type { MediaItem, MediaType } from '@/types';
import { MediaPreviewGrid } from '@/components/upload/MediaPreviewGrid';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Image as ImageIcon, Video as VideoIcon, X, Upload, Loader2, Crown, Search, Bell, Gem, ArrowUp, ChevronLeft, Plus } from 'lucide-react';
import { toast } from 'sonner';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { generateVideoThumbnail, blobToFile } from '@/utils/videoThumbnail';

interface MediaPreviewItem {
  file: File;
  preview: string;
  type: 'image' | 'video';
  thumbnail?: string; // For video thumbnails
}

export default function CreatePage() {
  const [activeTab, setActiveTab] = useState<'normal' | 'premium'>('normal');
  const [files, setFiles] = useState<MediaPreviewItem[]>([]);
  const [caption, setCaption] = useState('');
  const [isPremiumContent, setIsPremiumContent] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { profile, isApproved, isPremium, isAdmin } = useAuth();
  const navigate = useNavigate();

  // Admin-only access check
  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6 text-center space-y-4">
            <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto">
              <X className="w-8 h-8 text-destructive" />
            </div>
            <h2 className="text-2xl font-bold">Access Denied</h2>
            <p className="text-muted-foreground">
              Only administrators can upload content. Please contact an admin if you need access.
            </p>
            <Button onClick={() => navigate('/')} className="w-full">
              Go to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    if (selectedFiles.length === 0) return;

    // Validate files
    const validFiles: MediaPreviewItem[] = [];
    
    for (const file of selectedFiles) {
      const isVideo = file.type.startsWith('video/');
      const isImage = file.type.startsWith('image/');

      if (!isImage && !isVideo) {
        toast.error(`Invalid file type: ${file.name}`);
        continue;
      }

      // Size validation - No limit for admins, 10MB for images and 50MB for videos for others
      if (!isAdmin) {
        const maxSize = isVideo ? 50 * 1024 * 1024 : 10 * 1024 * 1024;
        if (file.size > maxSize) {
          toast.error(`File too large: ${file.name} (max ${isVideo ? '50MB' : '10MB'})`);
          continue;
        }
      }

      const preview = URL.createObjectURL(file);
      const mediaItem: MediaPreviewItem = {
        file,
        preview,
        type: isVideo ? 'video' : 'image'
      };

      // Generate thumbnail for videos
      if (isVideo) {
        try {
          toast.loading('Generating video thumbnail...', { id: 'thumbnail' });
          const thumbnailResult = await generateVideoThumbnail(file, 0, 0.8);
          mediaItem.thumbnail = thumbnailResult.dataUrl;
          toast.success('Thumbnail generated', { id: 'thumbnail' });
        } catch (error) {
          console.error('Failed to generate thumbnail:', error);
          toast.error('Failed to generate thumbnail', { id: 'thumbnail' });
        }
      }

      validFiles.push(mediaItem);
    }

    setFiles(prev => [...prev, ...validFiles]);
    
    // Reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleRemoveFile = (index: number) => {
    setFiles(prev => {
      const newFiles = [...prev];
      URL.revokeObjectURL(newFiles[index].preview);
      newFiles.splice(index, 1);
      return newFiles;
    });
  };

  const handleUpload = async () => {
    if (files.length === 0 || !profile) {
      toast.error('Please select at least one file');
      return;
    }

    if (!isApproved) {
      toast.error('You must be approved to create content');
      return;
    }

    // Check upload limits for regular users
    if (!isPremium && !isAdmin) {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const { count, error: countError } = await supabase
        .from('posts')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', profile.id)
        .eq('type', 'post')
        .gte('created_at', today.toISOString());

      if (countError) {
        console.error(countError);
        toast.error('Failed to check upload limit');
        return;
      }
      
      if (count !== null && count >= 1) {
        toast.error('Daily upload limit reached for regular users. Upgrade to Premium!');
        return;
      }
    }

    setUploading(true);
    setUploadProgress(0);

    try {
      const mediaItems: MediaItem[] = [];
      const totalFiles = files.length;

      // Upload all files
      for (let i = 0; i < files.length; i++) {
        const item = files[i];
        const isVideo = item.type === 'video';
        const bucket = isVideo ? 'primex_videos' : 'primex_images';
        const fileExt = item.file.name.split('.').pop();
        const fileName = `${profile.id}/${Date.now()}_${i}.${fileExt}`;

        // Upload to Supabase Storage
        const { error: uploadError } = await supabase.storage
          .from(bucket)
          .upload(fileName, item.file, {
            cacheControl: '3600',
            upsert: false,
          });

        if (uploadError) {
          console.error(`Failed to upload ${item.file.name}:`, uploadError);
          toast.error(`Failed to upload ${item.file.name}`);
          continue;
        }

        // Get Public URL
        const { data: { publicUrl } } = supabase.storage
          .from(bucket)
          .getPublicUrl(fileName);

        // Upload thumbnail for videos
        let thumbnailUrl: string | undefined;
        if (isVideo && item.thumbnail) {
          try {
            // Convert data URL to blob
            const response = await fetch(item.thumbnail);
            const thumbnailBlob = await response.blob();
            const thumbnailFile = blobToFile(thumbnailBlob, `thumbnail_${Date.now()}_${i}.jpg`);
            
            const thumbnailFileName = `${profile.id}/thumbnails/${Date.now()}_${i}.jpg`;
            
            const { error: thumbError } = await supabase.storage
              .from('primex_images')
              .upload(thumbnailFileName, thumbnailFile, {
                cacheControl: '3600',
                upsert: false,
              });

            if (!thumbError) {
              const { data: { publicUrl: thumbUrl } } = supabase.storage
                .from('primex_images')
                .getPublicUrl(thumbnailFileName);
              
              thumbnailUrl = thumbUrl;
            }
          } catch (error) {
            console.error('Failed to upload thumbnail:', error);
          }
        }

        mediaItems.push({
          url: publicUrl,
          type: item.type as MediaType,
          thumbnail_url: thumbnailUrl
        });

        // Update progress
        setUploadProgress(Math.round(((i + 1) / totalFiles) * 100));
      }

      if (mediaItems.length === 0) {
        throw new Error('No files were uploaded successfully');
      }

      // Determine post type (if any video, it's a reel)
      const hasVideo = mediaItems.some(m => m.type === 'video');
      const postType = hasVideo ? 'reel' : 'post';

      // Create Post Record
      await api.createPost({
        user_id: profile.id,
        type: postType,
        media_url: mediaItems[0].url, // First item for backward compatibility
        media_type: mediaItems[0].type,
        media_items: mediaItems,
        caption: caption,
        is_premium: isPremiumContent || activeTab === 'premium',
      });

      toast.success(`${mediaItems.length} file(s) uploaded successfully!`);
      
      // Clean up
      files.forEach(f => URL.revokeObjectURL(f.preview));
      setFiles([]);
      setCaption('');
      
      navigate(activeTab === 'premium' ? '/premium-feed' : '/');
    } catch (error: any) {
      console.error('Upload error:', error);
      toast.error(error.message || 'Upload failed');
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Top Header matching the image style */}
      <div className="sticky top-0 z-50 bg-background/95 backdrop-blur-md border-b border-border/50 px-3 h-12 flex items-center justify-between">
        <div className="w-7 h-7 bg-primary/10 rounded-lg flex items-center justify-center border border-primary/20" onClick={() => navigate('/')}>
          <Crown className="w-4.5 h-4.5 text-primary" />
        </div>

        <div className="flex bg-muted/50 p-0.5 rounded-full border border-border/50">
          <button
            onClick={() => setActiveTab('normal')}
            className={cn(
              "px-3 py-1 rounded-full text-[11px] font-black uppercase italic tracking-tighter transition-all",
              activeTab === 'normal' ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
            )}
          >
            Normal
          </button>
          <button
            onClick={() => {
              if (!isPremium && !isAdmin) {
                toast.error('Premium features are for subscribers only');
                navigate('/premium');
                return;
              }
              setActiveTab('premium');
              setIsPremiumContent(true);
            }}
            className={cn(
              "px-3 py-1 rounded-full text-[11px] font-black uppercase italic tracking-tighter transition-all flex items-center gap-1",
              activeTab === 'premium' ? "bg-primary text-white shadow-lg shadow-primary/20" : "text-muted-foreground hover:text-foreground"
            )}
          >
            <Gem className="w-3 h-3" />
            Premium
          </button>
        </div>

        <div className="flex items-center gap-1.5">
          <Button size="icon" variant="ghost" className="rounded-full w-7 h-7">
            <Search className="w-3.5 h-3.5" />
          </Button>
          <Button size="icon" variant="ghost" className="rounded-full w-7 h-7">
            <Bell className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      <div className="max-w-md mx-auto px-3 pt-2 space-y-3">
        <div className="flex items-center gap-1.5 text-muted-foreground/50 font-black uppercase tracking-widest text-[10px] ml-1.5">
          <ChevronLeft className="w-3 h-3 cursor-pointer hover:text-primary transition-colors" onClick={() => navigate(-1)} />
          <span>feed.</span>
        </div>

        <Card className="bg-[#121212] border-border/30 shadow-2xl rounded-2xl overflow-hidden relative">
          <CardContent className="p-3 space-y-3">
            {/* Premium Toggle */}
            <div className="flex items-center justify-between bg-muted/10 p-2.5 rounded-xl border border-border/30">
              <div className="flex items-center gap-2">
                <Gem className="w-3.5 h-3.5 text-primary" />
                <div>
                  <Label className="text-[11px] font-black uppercase italic tracking-tighter block text-white">Premium Content</Label>
                  <p className="text-[9px] text-muted-foreground font-medium uppercase tracking-widest leading-none mt-0.5">Visible only in the Premium Feed</p>
                </div>
              </div>
              <Switch
                checked={isPremiumContent}
                onCheckedChange={setIsPremiumContent}
                className="data-[state=checked]:bg-primary scale-90"
                disabled={!isPremium && !isAdmin}
              />
            </div>

            {/* Media File Section */}
            <div className="space-y-1.5">
              <Label className="text-white text-[11px] font-black uppercase italic tracking-tighter ml-1">Media Files</Label>
              <div className="flex items-center gap-2.5 bg-muted/10 p-1.5 pr-2.5 rounded-xl border border-border/30">
                <Button 
                  onClick={() => fileInputRef.current?.click()}
                  className="h-8.5 px-3 rounded-lg bg-primary hover:bg-primary/90 text-white text-[11px] font-black uppercase italic tracking-tighter shadow-lg shadow-primary/20"
                >
                  <Plus className="w-3 h-3 mr-1" />
                  Add Files
                </Button>
                <span className="text-[11px] font-bold text-muted-foreground truncate flex-1 opacity-70">
                  {files.length > 0 ? `${files.length} file(s) selected` : "No files selected"}
                </span>
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  accept="image/*,video/*"
                  multiple
                  onChange={handleFileChange}
                />
              </div>

              {/* Preview Grid */}
              <MediaPreviewGrid 
                items={files}
                onRemove={handleRemoveFile}
              />
            </div>

            {/* Caption Section */}
            <div className="space-y-2">
              <Label className="text-white text-[11px] font-black uppercase italic tracking-tighter ml-1">Description / Caption</Label>
              <Textarea
                placeholder="Describe this prime moment..."
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                className="bg-muted/10 border-border/30 min-h-[100px] rounded-xl p-3 focus:ring-primary/30 transition-all text-sm font-medium resize-none text-white placeholder:text-muted-foreground/40"
              />
            </div>

            {/* Upload Progress */}
            {uploading && (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-white font-bold">Uploading...</span>
                  <span className="text-primary font-black">{uploadProgress}%</span>
                </div>
                <Progress value={uploadProgress} className="h-1.5" />
              </div>
            )}
          </CardContent>

          {/* Floating Diamond Button */}
          <div className="absolute bottom-4 right-4">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center shadow-lg shadow-primary/30 animate-pulse">
              <Gem className="w-5 h-5 text-white" />
            </div>
          </div>
        </Card>
      </div>

      {/* Fixed Bottom Publish Button */}
      <div className="fixed bottom-4 left-0 right-0 px-4 flex justify-center z-50">
        <Button 
          onClick={handleUpload}
          disabled={uploading || files.length === 0}
          className="w-full max-w-sm h-12 bg-black text-white hover:bg-black/90 rounded-2xl shadow-2xl border border-white/10 flex items-center justify-center gap-2.5 transition-all active:scale-95 disabled:opacity-50"
        >
          {uploading ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span className="text-sm font-black uppercase italic tracking-tighter">Uploading {uploadProgress}%</span>
            </>
          ) : (
            <>
              <div className="w-5 h-5 rounded-full border border-white flex items-center justify-center">
                <ArrowUp className="w-2.5 h-2.5 text-white" />
              </div>
              <span className="text-sm font-black uppercase italic tracking-tighter">Publish</span>
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
