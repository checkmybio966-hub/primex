import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useEffect, useState, useMemo } from 'react';
import { api } from '@/db/api';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { ArrowLeft, CheckCircle, Sparkles, Gem } from 'lucide-react';
import { toast } from 'sonner';

export default function QRPaymentPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { profile } = useAuth();
  const [settings, setSettings] = useState<{ premium_qr_url: string; payment_text: string } | null>(null);
  const [loading, setLoading] = useState(true);

  // Get data from navigation state (instant access)
  const plan = location.state?.plan || 'premium';
  const price = location.state?.price || 299;
  const passedUsername = location.state?.username;

  // Memoize username to avoid recalculation
  const displayUsername = useMemo(() => {
    return passedUsername || profile?.username || 'Guest';
  }, [passedUsername, profile?.username]);

  useEffect(() => {
    // Fast async loading - don't block UI
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const data = await api.getSettings();
      if (data) {
        setSettings({
          premium_qr_url: data.premium_qr_url || '',
          payment_text: data.payment_text || ''
        });
      }
    } catch (error) {
      console.error('Failed to fetch settings:', error);
      toast.error('Failed to load payment details');
    } finally {
      setLoading(false);
    }
  };

  const handlePayNow = () => {
    toast.success('Payment successfully completed, waiting for access', {
      duration: 5000,
      icon: <CheckCircle className="w-5 h-5 text-green-500" />,
    });
    // Fast navigation back
    navigate('/login', { replace: true });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-background">
        <Card className="w-full max-w-md">
          <CardHeader>
            <Skeleton className="h-8 w-48 bg-muted" />
          </CardHeader>
          <CardContent className="space-y-6">
            <Skeleton className="h-64 w-full bg-muted" />
            <Skeleton className="h-12 w-full bg-muted" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-background relative overflow-hidden animate-page-enter">
      {/* Decorative Circles */}
      <div className="absolute top-[-10%] right-[-10%] w-96 h-96 bg-primary/20 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-10%] w-96 h-96 bg-purple-500/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="w-full max-w-md space-y-6 relative z-10">
        {/* Back Button */}
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="text-body font-medium">Back</span>
        </button>

        <Card className="glass border-border/50 shadow-card rounded-2xl">
          <CardHeader className="text-center space-y-4">
            <div className="flex items-center justify-center gap-3">
              {plan === 'premium' ? (
                <Sparkles className="w-8 h-8 text-primary fill-primary" />
              ) : (
                <Gem className="w-8 h-8 text-purple-400 fill-purple-400" />
              )}
              <CardTitle className="text-heading font-bold">
                {plan === 'premium' ? 'Premium Plan' : 'Exclusive Plan'}
              </CardTitle>
            </div>
            
            {/* Username Display - Always show */}
            <div className="bg-muted/50 rounded-xl p-3 border border-border/50">
              <p className="text-small text-muted-foreground">Payment for</p>
              <p className="text-body font-bold text-foreground">@{displayUsername}</p>
            </div>

            {price > 0 && (
              <div className="text-center">
                <p className="text-xs text-muted-foreground">Amount</p>
                <p className="text-2xl font-black text-primary">₹{price} INR</p>
              </div>
            )}
          </CardHeader>

          <CardContent className="space-y-6">
            {/* QR Code */}
            <div className="bg-white rounded-2xl p-6 flex items-center justify-center">
              {settings?.premium_qr_url ? (
                <img
                  src={settings.premium_qr_url}
                  alt="Payment QR Code"
                  className="w-64 h-64 object-contain"
                />
              ) : (
                <div className="w-64 h-64 bg-muted rounded-xl flex items-center justify-center">
                  <p className="text-muted-foreground text-body">No QR Code Available</p>
                </div>
              )}
            </div>

            {/* Payment Instructions */}
            {settings?.payment_text && (
              <div className="bg-muted/30 rounded-xl p-4 border border-border/50">
                <p className="text-body text-foreground/90 text-center whitespace-pre-wrap">
                  {settings.payment_text}
                </p>
              </div>
            )}

            {/* Pay Now Button */}
            <Button
              onClick={handlePayNow}
              className="w-full h-14 rounded-xl bg-gradient-primary text-white font-bold text-lg shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
            >
              <CheckCircle className="w-5 h-5" />
              Pay Now
            </Button>

            <p className="text-xs text-center text-muted-foreground">
              After payment, admin will verify and activate your account within 24 hours
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
