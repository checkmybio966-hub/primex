import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { supabase } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Camera, Loader2, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';

export default function EditProfilePage() {
  const { profile, user } = useAuth();
  const navigate = useNavigate();
  
  const [loading, setLoading] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [bio, setBio] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');

  useEffect(() => {
    if (profile) {
      setUsername(profile.username || '');
      setDisplayName(profile.display_name || '');
      setBio(profile.bio || '');
      setAvatarUrl(profile.profile_image || '');
    }
  }, [profile]);

  if (!user) {
    navigate('/login');
    return null;
  }

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !profile) return;

    setUploadingAvatar(true);
    try {
      const fileName = `${profile.id}/avatar-${Date.now()}.jpg`;
      const { data, error } = await supabase.storage.from('primex_images').upload(fileName, file);
      if (error) throw error;

      const { data: { publicUrl } } = supabase.storage.from('primex_images').getPublicUrl(fileName);
      setAvatarUrl(publicUrl);
      toast.success('Avatar uploaded! Click Save to confirm.');
    } catch (error: any) {
      toast.error(error.message || 'Avatar upload failed');
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleSave = async () => {
    if (!profile) return;
    setLoading(true);
    try {
      await api.updateProfile(profile.id, {
        username,
        display_name: displayName,
        bio,
        profile_image: avatarUrl
      });
      toast.success('Profile updated successfully');
      navigate('/profile');
    } catch (error: any) {
      toast.error(error.message || 'Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="py-8 max-w-2xl mx-auto px-4 animate-fade-in space-y-8">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button 
          variant="ghost" 
          size="icon" 
          className="rounded-xl h-10 w-10 border border-border/50 bg-card/40"
          onClick={() => navigate(-1)}
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="heading-main">Edit Profile</h1>
      </div>

      <Card className="glass border-border/50 overflow-hidden rounded-[1.5rem]">
        <CardHeader className="bg-muted/10 pb-8 pt-10 px-8 text-center sm:text-left">
           <CardTitle className="text-section font-black uppercase italic tracking-tighter">Profile Details</CardTitle>
           <CardDescription className="text-meta">Customize your identity on Primex Social</CardDescription>
        </CardHeader>
        <CardContent className="p-8 space-y-8">
          {/* Avatar Section */}
          <div className="flex flex-col items-center sm:flex-row gap-8 pb-8 border-b border-border/50">
             <div className="relative group">
                <Avatar className="w-24 h-24 md:w-32 md:h-32 border-4 border-card ring-4 ring-primary/10 ring-offset-4 ring-offset-background shadow-2xl transition-transform group-hover:scale-105">
                   <AvatarImage src={avatarUrl} className="object-cover" />
                   <AvatarFallback className="bg-muted text-4xl font-black uppercase italic tracking-tighter">
                      {username?.[0]}
                   </AvatarFallback>
                </Avatar>
                <label className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer rounded-full border-2 border-primary/20 backdrop-blur-sm">
                   <Camera className="w-6 h-6 text-white" />
                   <input type="file" className="hidden" accept="image/*" onChange={handleAvatarUpload} disabled={uploadingAvatar} />
                </label>
                {uploadingAvatar && (
                   <div className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-full border-2 border-primary/20 backdrop-blur-sm">
                      <Loader2 className="w-8 h-8 animate-spin text-primary" />
                   </div>
                )}
             </div>
             <div className="flex-1 text-center sm:text-left space-y-2">
                <h3 className="text-section font-bold tracking-tight">Profile Photo</h3>
                <p className="text-meta max-w-xs">We recommend an image of at least 400x400. PNG, JPG, or WEBP.</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="rounded-xl border-border/50 font-bold gap-2 mt-2 h-9 px-4"
                  onClick={() => document.querySelector<HTMLInputElement>('input[type="file"]')?.click()}
                >
                   Change Photo
                </Button>
             </div>
          </div>

          <div className="grid gap-6">
            {/* Display Name */}
            <div className="space-y-2.5">
              <Label htmlFor="displayName" className="text-meta uppercase italic tracking-tighter font-black opacity-80">Display Name</Label>
              <Input 
                id="displayName"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="Full Name"
                className="bg-background/50 border-border/50 h-12 rounded-xl text-normal font-medium px-4 focus:ring-primary/40"
              />
            </div>

            {/* Username */}
            <div className="space-y-2.5">
              <Label htmlFor="username" className="text-meta uppercase italic tracking-tighter font-black opacity-80">Username</Label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground font-bold">@</span>
                <Input 
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="username"
                  className="bg-background/50 border-border/50 h-12 rounded-xl pl-8 pr-4 text-normal font-medium focus:ring-primary/40"
                />
              </div>
            </div>

            {/* Bio */}
            <div className="space-y-2.5">
              <Label htmlFor="bio" className="text-meta uppercase italic tracking-tighter font-black opacity-80">Bio</Label>
              <Textarea 
                id="bio"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Write something about yourself..."
                className="bg-background/50 border-border/50 min-h-[120px] rounded-xl text-normal font-medium p-4 focus:ring-primary/40 resize-none"
              />
              <p className="text-[11px] text-right text-muted-foreground font-medium italic opacity-50">{bio.length}/200</p>
            </div>
          </div>

          <div className="pt-8 border-t border-border/50 flex gap-4">
            <Button 
              className="flex-1 bg-gradient-primary border-none rounded-xl h-14 btn-standard shadow-xl hover:scale-[1.02] transition-transform active:scale-95 disabled:opacity-50"
              onClick={handleSave}
              disabled={loading || uploadingAvatar}
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <CheckCircle2 className="w-5 h-5 mr-2" />}
              Save Changes
            </Button>
            <Button 
              variant="outline"
              className="flex-1 border-border/50 rounded-xl h-14 btn-standard hover:bg-muted/50 transition-all active:scale-95"
              onClick={() => navigate('/profile')}
              disabled={loading}
            >
              Cancel
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
