import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import type { FileItem, Folder } from '@/types';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { FileText, Image as ImageIcon, Video as VideoIcon, FolderOpen, Loader2, Sparkles, Lock, ShieldCheck, Edit3, X, Save, Eye, FolderPlus, Upload, ChevronRight, ArrowLeft, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { Card, CardFooter, CardHeader } from '@/components/ui/card';
import { useNavigate } from 'react-router-dom';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { cn } from '@/lib/utils';

function SecureImagePreview({ url }: { url: string }) {
  const [signedUrl, setSignedUrl] = useState<string>('');
  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await api.getFileSignedUrl(url);
        setSignedUrl(res);
      } catch (e) {
        console.error(e);
      }
    };
    fetch();
  }, [url]);

  if (!signedUrl) return <Skeleton className="w-full h-full rounded-[1.5rem] bg-muted/10" />;
  return <img src={signedUrl} alt="preview" className="w-full h-full object-cover pointer-events-none select-none" onContextMenu={e => e.preventDefault()} />;
}

export default function FilesPage() {
  const { isPremium, isAdmin, user } = useAuth();
  const [files, setFiles] = useState<FileItem[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [currentFolder, setCurrentFolder] = useState<Folder | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  // Dialog States
  const [isCreateFolderOpen, setIsCreateFolderOpen] = useState(false);
  const [isUploadFileOpen, setIsUploadFileOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadFileName, setUploadFileName] = useState('');
  const [uploading, setUploading] = useState(false);

  // Edit/View States
  const [editingFile, setEditingFile] = useState<FileItem | null>(null);
  const [editingFolder, setEditingFolder] = useState<Folder | null>(null);
  const [viewingFile, setViewingFile] = useState<FileItem | null>(null);
  const [viewUrl, setViewUrl] = useState<string>('');
  const [newName, setNewName] = useState('');
  const [loadingView, setLoadingView] = useState(false);

  const hasAccess = isPremium || isAdmin;

  useEffect(() => {
    if (hasAccess) {
      fetchContent();
    } else {
      setLoading(false);
    }
  }, [hasAccess, currentFolder]);

  const fetchContent = async () => {
    setLoading(true);
    try {
      // If at root (currentFolder is null), fetch folders. 
      // Requirement says "Files section must show folders first". 
      // Files inside folders are fetched when folder is opened.
      // Root can technically have files too, but let's assume root is mostly for folders 
      // unless we want mixed content. I'll support mixed content at root just in case.
      
      const [filesData, foldersData] = await Promise.all([
        api.getFiles(currentFolder?.id),
        currentFolder ? Promise.resolve([]) : api.getFolders() // Only fetch folders at root level for now, or maybe folders inside folders? DB schema supports one level or hierarchical?
        // Schema: user_id only. No parent_id. So flat list of folders? 
        // Wait, Requirement 2: "Each folder can contain multiple files".
        // Requirement 1: "Files section must show folders first".
        // My schema has `files.folder_id`. `folders` table has no `parent_id`. 
        // So it's a 1-level folder system. Root -> Folders -> Files.
        // Root can also contain Files (where folder_id is null).
      ]);
      
      setFiles(filesData);
      setFolders(foldersData);
    } catch (error) {
      toast.error('Failed to fetch content');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateFolder = async () => {
    if (!newFolderName || !user) return;
    try {
      await api.createFolder(newFolderName, user.id);
      toast.success('Folder created');
      setNewFolderName('');
      setIsCreateFolderOpen(false);
      fetchContent(); // Refresh
    } catch (error) {
      toast.error('Failed to create folder');
    }
  };

  const handleRenameFolder = async () => {
    if (!editingFolder || !newName) return;
    try {
      await api.updateFolder(editingFolder.id, { name: newName });
      setFolders(folders.map(f => f.id === editingFolder.id ? { ...f, name: newName } : f));
      toast.success('Folder renamed');
      setEditingFolder(null);
    } catch (error) {
      toast.error('Failed to rename folder');
    }
  };

  const handleDeleteFolder = async (folder: Folder) => {
    if (!isAdmin) return;
    if (!confirm('Are you sure you want to delete this folder and all its files?')) return;
    try {
      await api.deleteFolder(folder.id);
      setFolders(folders.filter(f => f.id !== folder.id));
      toast.success('Folder deleted');
    } catch (error) {
      toast.error('Failed to delete folder');
    }
  };

  const handleUploadFile = async () => {
    if (!uploadFile || !user) return;
    setUploading(true);
    try {
      await api.uploadFile(
        user.id, 
        uploadFile, 
        uploadFileName || uploadFile.name, 
        uploadFile.type,
        currentFolder?.id || null
      );
      toast.success('File uploaded');
      setUploadFile(null);
      setUploadFileName('');
      setIsUploadFileOpen(false);
      fetchContent(); // Refresh files
    } catch (error) {
      toast.error('Failed to upload file');
    } finally {
      setUploading(false);
    }
  };

  const handleRenameFile = async () => {
    if (!editingFile || !newName) return;
    try {
      await api.updateFile(editingFile.id, { name: newName });
      setFiles(files.map(f => f.id === editingFile.id ? { ...f, name: newName } : f));
      toast.success('File renamed');
      setEditingFile(null);
    } catch (error) {
      toast.error('Failed to rename file');
    }
  };

  const handleDeleteFile = async (file: FileItem) => {
    if (!isAdmin) return;
    try {
      await api.deleteFile(file.id, file.url);
      setFiles(files.filter(f => f.id !== file.id));
      toast.success('File deleted');
    } catch (error) {
      toast.error('Failed to delete file');
    }
  };

  const handleView = async (file: FileItem) => {
    setViewingFile(file);
    setLoadingView(true);
    try {
      const signedUrl = await api.getFileSignedUrl(file.url);
      setViewUrl(signedUrl);
    } catch (error) {
      toast.error('Failed to load file view');
      setViewingFile(null);
    } finally {
      setLoadingView(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (type: string) => {
    if (type.includes('image')) return <ImageIcon className="w-8 h-8 text-blue-400" />;
    if (type.includes('video')) return <VideoIcon className="w-8 h-8 text-purple-400" />;
    return <FileText className="w-8 h-8 text-orange-400" />;
  };

  if (loading) {
    return (
      <div className="max-w-6xl mx-auto py-8 px-4 space-y-8">
        <Skeleton className="h-14 w-full rounded-2xl" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-32 rounded-3xl" />
          ))}
        </div>
      </div>
    );
  }

  if (!hasAccess) {
    return (
      <div className="min-h-[80vh] flex flex-col items-center justify-center p-6 text-center space-y-8 max-w-md mx-auto">
        <div className="relative">
          <div className="w-32 h-32 bg-primary/10 rounded-[2.5rem] flex items-center justify-center border border-primary/20 shadow-2xl animate-pulse">
            <Lock className="w-16 h-16 text-primary" />
          </div>
          <div className="absolute -top-2 -right-2 bg-yellow-500 rounded-full p-2 shadow-lg border-4 border-background">
            <FolderOpen className="w-6 h-6 text-white" />
          </div>
        </div>
        <div className="space-y-4">
          <h1 className="heading-main text-4xl uppercase italic tracking-tighter">SECURE CLOUD</h1>
          <p className="text-section font-semibold text-muted-foreground">
            Upgrade to Premium to access our secure cloud storage.
          </p>
        </div>
        <Button 
          onClick={() => navigate('/premium')}
          className="w-full h-16 rounded-2xl btn-standard text-2xl bg-gradient-primary border-none shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-primary/20 flex items-center justify-center gap-3"
        >
          UPGRADE NOW
          <Sparkles className="w-6 h-6 animate-pulse" />
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 space-y-8">
      {/* Header & Navigation */}
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-blue-500/10 rounded-2xl flex items-center justify-center border border-blue-500/20 shadow-lg shadow-blue-500/10 animate-in zoom-in duration-500">
              <FolderOpen className="w-8 h-8 text-blue-500 fill-blue-500/20" />
            </div>
            <div className="flex flex-col">
              <h1 className="text-4xl font-black italic uppercase tracking-tighter text-blue-500 leading-none">SECURE FILES</h1>
              <p className="text-[10px] font-black uppercase tracking-[0.3em] text-muted-foreground mt-1">Primex Cloud System</p>
            </div>
          </div>
          {isAdmin && (
             <div className="flex gap-3">
               <Button onClick={() => setIsCreateFolderOpen(true)} className="rounded-xl h-14 w-14 btn-standard shadow-lg border-border/50" variant="outline" size="icon">
                 <FolderPlus className="w-6 h-6" />
               </Button>
               <Button onClick={() => setIsUploadFileOpen(true)} className="rounded-xl h-14 w-14 btn-standard shadow-xl bg-blue-600 hover:bg-blue-700 border-none" size="icon">
                 <Upload className="w-6 h-6" />
               </Button>
             </div>
          )}
        </div>

        {/* Breadcrumb */}
        <div className="flex items-center gap-2 p-2 bg-muted/20 border border-border/30 rounded-2xl w-fit px-6">
          <Button 
            variant="ghost" 
            onClick={() => setCurrentFolder(null)}
            className={cn(
              "h-auto p-0 hover:bg-transparent font-black uppercase italic tracking-tighter text-sm transition-colors",
              !currentFolder ? "text-blue-500" : "text-muted-foreground hover:text-foreground"
            )}
          >
            Root
          </Button>
          {currentFolder && (
            <>
              <ChevronRight className="w-4 h-4 text-muted-foreground/50" />
              <span className="font-black uppercase italic tracking-tighter text-sm text-blue-500">{currentFolder.name}</span>
            </>
          )}
        </div>
      </div>

      {/* Content Grid */}
      <div className="space-y-12">
        {/* Folders Section (Only at Root) */}
        {!currentFolder && folders.length > 0 && (
          <div className="space-y-6">
            <h2 className="text-meta font-black uppercase italic tracking-widest opacity-40 ml-2">Folders</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
              {folders.map(folder => (
                <Card 
                  key={folder.id} 
                  className="bg-card/30 hover:bg-card border-border/30 hover:border-blue-500/30 transition-all cursor-pointer group relative overflow-hidden rounded-[2rem] p-4"
                  onClick={() => setCurrentFolder(folder)}
                >
                  <CardHeader className="p-6 flex flex-col items-center text-center gap-6">
                    <div className="w-24 h-24 bg-blue-500/10 rounded-3xl flex items-center justify-center border border-blue-500/20 group-hover:scale-110 group-hover:bg-blue-500/20 transition-all duration-500 shadow-inner">
                      <FolderOpen className="w-12 h-12 text-blue-500 fill-blue-500/20" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="text-lg font-black uppercase italic tracking-tighter truncate w-full group-hover:text-blue-500 transition-colors">{folder.name}</h3>
                      <p className="text-[10px] font-black uppercase tracking-tighter text-muted-foreground">Directory</p>
                    </div>
                  </CardHeader>
                  {isAdmin && (
                    <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0" onClick={e => e.stopPropagation()}>
                       <Button size="icon" variant="ghost" className="h-10 w-10 rounded-xl hover:bg-blue-500/10 hover:text-blue-500 border border-transparent hover:border-blue-500/20" onClick={() => { setEditingFolder(folder); setNewName(folder.name); }}>
                         <Edit3 className="w-5 h-5" />
                       </Button>
                       <Button size="icon" variant="ghost" className="h-10 w-10 rounded-xl hover:bg-destructive/10 hover:text-destructive border border-transparent hover:border-destructive/20" onClick={() => handleDeleteFolder(folder)}>
                         <Trash2 className="w-5 h-5" />
                       </Button>
                    </div>
                  )}
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Files Section */}
        {files.length > 0 ? (
          <div className="space-y-6">
            <h2 className="text-meta font-black uppercase italic tracking-widest opacity-40 ml-2">Files</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {files.map((file) => (
                <Card key={file.id} className="bg-card/30 border-border/30 overflow-hidden rounded-[2rem] shadow-card hover:shadow-hover transition-all duration-300 group relative p-2">
                  <div className="aspect-square bg-muted/20 rounded-[1.8rem] overflow-hidden relative group-hover:rounded-[1.5rem] transition-all duration-500">
                    <div className="w-full h-full flex items-center justify-center">
                       {file.file_type.includes('image') ? (
                         <SecureImagePreview url={file.url} />
                       ) : (
                         <div className="flex flex-col items-center gap-4">
                           {getFileIcon(file.file_type)}
                           <p className="text-[10px] font-black uppercase italic tracking-tighter text-muted-foreground">{file.file_type.split('/')[1]}</p>
                         </div>
                       )}
                    </div>
                    {/* Hover Overlay */}
                    <div className="absolute inset-0 bg-blue-600/80 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                       <Button onClick={() => handleView(file)} className="rounded-full w-16 h-16 bg-white text-blue-600 hover:bg-blue-50 hover:scale-110 transition-all shadow-xl">
                         <Eye className="w-8 h-8" />
                       </Button>
                    </div>
                  </div>
                  
                  <CardHeader className="p-6 flex flex-row items-center gap-4">
                    <div className="flex-1 min-w-0">
                      <h3 className="text-normal font-black uppercase italic tracking-tighter truncate group-hover:text-blue-500 transition-colors">{file.name}</h3>
                      <p className="text-meta font-black uppercase tracking-tighter text-muted-foreground/60">{formatFileSize(file.size)}</p>
                    </div>
                    {isAdmin && (
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-all duration-300">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            setEditingFile(file);
                            setNewName(file.name);
                          }}
                          className="h-10 w-10 rounded-xl text-muted-foreground hover:text-blue-500 hover:bg-blue-500/10"
                        >
                          <Edit3 className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteFile(file)}
                          className="h-10 w-10 rounded-xl text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                  </CardHeader>
                </Card>
              ))}
            </div>
          </div>
        ) : (
          (!currentFolder && folders.length === 0) || (currentFolder && files.length === 0) ? (
            <div className="flex flex-col items-center justify-center py-32 text-center space-y-8 animate-in fade-in zoom-in duration-700">
              <div className="w-32 h-32 bg-muted/10 rounded-[3rem] flex items-center justify-center border border-border/30 shadow-inner relative">
                <FolderOpen className="w-16 h-16 text-muted-foreground/30" />
                <div className="absolute -top-2 -right-2 w-10 h-10 bg-blue-500/20 rounded-full flex items-center justify-center border border-blue-500/30">
                   <Lock className="w-5 h-5 text-blue-500" />
                </div>
              </div>
              <div className="space-y-3">
                <h2 className="text-4xl font-black italic uppercase tracking-tighter leading-none">EMPTY FOLDER</h2>
                <p className="text-section font-bold text-muted-foreground opacity-60">No content uploaded yet.</p>
              </div>
            </div>
          ) : null
        )}
      </div>

      {/* --- Modals --- */}

      {/* Create Folder Dialog */}
      <Dialog open={isCreateFolderOpen} onOpenChange={setIsCreateFolderOpen}>
        <DialogContent className="glass border-border shadow-2xl rounded-3xl">
          <DialogHeader>
            <DialogTitle className="heading-main text-2xl">New Folder</DialogTitle>
          </DialogHeader>
          <div className="py-6 space-y-4">
            <div className="space-y-2">
               <label className="text-meta uppercase font-black italic tracking-tighter ml-1 opacity-70">Folder Name</label>
               <Input 
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                placeholder="Enter folder name"
                className="bg-background/50 border-border/50 h-14 rounded-2xl text-normal font-bold"
               />
            </div>
          </div>
          <DialogFooter className="flex flex-row gap-3">
             <Button variant="ghost" onClick={() => setIsCreateFolderOpen(false)} className="flex-1 h-14 rounded-2xl text-meta uppercase font-black italic tracking-tighter">
               CANCEL
             </Button>
             <Button onClick={handleCreateFolder} className="flex-1 h-14 rounded-2xl btn-standard">
               CREATE
             </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Upload File Dialog */}
      <Dialog open={isUploadFileOpen} onOpenChange={setIsUploadFileOpen}>
        <DialogContent className="glass border-border shadow-2xl rounded-3xl">
          <DialogHeader>
            <DialogTitle className="heading-main text-2xl">Upload File</DialogTitle>
          </DialogHeader>
          <div className="py-6 space-y-4">
            <div className="space-y-2">
               <label className="text-meta uppercase font-black italic tracking-tighter ml-1 opacity-70">File Name (Optional)</label>
               <Input 
                value={uploadFileName}
                onChange={(e) => setUploadFileName(e.target.value)}
                placeholder="Custom file name"
                className="bg-background/50 border-border/50 h-14 rounded-2xl text-normal font-bold"
               />
            </div>
            <div 
              className="border-2 border-dashed border-border/50 rounded-2xl p-8 text-center cursor-pointer hover:border-primary/50 transition-all group"
              onClick={() => document.getElementById('dialog-upload-input')?.click()}
            >
              <Upload className="w-10 h-10 text-muted-foreground mx-auto mb-2 group-hover:text-primary transition-colors" />
              <p className="text-meta font-bold uppercase tracking-widest truncate">
                {uploadFile ? uploadFile.name : 'Click to select file'}
              </p>
              <input id="dialog-upload-input" type="file" className="hidden" onChange={(e) => setUploadFile(e.target.files?.[0] || null)} />
            </div>
          </div>
          <DialogFooter className="flex flex-row gap-3">
             <Button variant="ghost" onClick={() => setIsUploadFileOpen(false)} className="flex-1 h-14 rounded-2xl text-meta uppercase font-black italic tracking-tighter">
               CANCEL
             </Button>
             <Button onClick={handleUploadFile} disabled={!uploadFile || uploading} className="flex-1 h-14 rounded-2xl btn-standard">
               {uploading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'UPLOAD'}
             </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Rename File/Folder Dialog (Shared logic roughly) */}
      <Dialog open={!!editingFile || !!editingFolder} onOpenChange={() => { setEditingFile(null); setEditingFolder(null); }}>
        <DialogContent className="glass border-border shadow-2xl rounded-3xl">
          <DialogHeader>
            <DialogTitle className="heading-main text-2xl">Rename {editingFolder ? 'Folder' : 'File'}</DialogTitle>
          </DialogHeader>
          <div className="py-6 space-y-4">
            <div className="space-y-2">
               <label className="text-meta uppercase font-black italic tracking-tighter ml-1 opacity-70">New Name</label>
               <Input 
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="Enter new name"
                className="bg-background/50 border-border/50 h-14 rounded-2xl text-normal font-bold"
               />
            </div>
          </div>
          <DialogFooter className="flex flex-row gap-3">
             <Button variant="ghost" onClick={() => { setEditingFile(null); setEditingFolder(null); }} className="flex-1 h-14 rounded-2xl text-meta uppercase font-black italic tracking-tighter">
               CANCEL
             </Button>
             <Button onClick={editingFolder ? handleRenameFolder : handleRenameFile} className="flex-1 h-14 rounded-2xl btn-standard">
               SAVE
             </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={!!viewingFile} onOpenChange={() => { setViewingFile(null); setViewUrl(''); }}>
        <DialogContent className="glass border-border shadow-2xl rounded-[2rem] max-w-4xl p-0 overflow-hidden bg-black/90">
          <div className="absolute top-4 right-4 z-50">
             <Button variant="ghost" size="icon" onClick={() => setViewingFile(null)} className="rounded-xl h-10 w-10 bg-black/40 text-white hover:bg-black/60">
               <X className="w-6 h-6" />
             </Button>
          </div>
          
          <div className="flex flex-col h-full min-h-[400px]">
            <div className="flex-1 flex items-center justify-center p-4">
              {loadingView ? (
                <div className="flex flex-col items-center gap-4 text-white">
                  <Loader2 className="w-12 h-12 animate-spin text-primary" />
                  <p className="text-meta font-black uppercase italic tracking-tighter">Securing content...</p>
                </div>
              ) : viewUrl ? (
                <div 
                  className="w-full h-full flex items-center justify-center relative group"
                  onContextMenu={(e) => e.preventDefault()}
                >
                  {viewingFile?.file_type.includes('image') ? (
                    <img 
                      src={viewUrl} 
                      alt={viewingFile.name} 
                      className="max-h-[80vh] w-auto object-contain pointer-events-none select-none rounded-xl"
                      onDragStart={(e) => e.preventDefault()}
                    />
                  ) : viewingFile?.file_type.includes('video') ? (
                    <video 
                      src={viewUrl} 
                      className="max-h-[80vh] w-full rounded-xl" 
                      controls 
                      controlsList="nodownload"
                      autoPlay
                      onContextMenu={(e) => e.preventDefault()}
                    />
                  ) : (
                    <div className="flex flex-col items-center gap-6 text-white p-12 text-center">
                      <div className="w-24 h-24 bg-primary/20 rounded-full flex items-center justify-center border-2 border-primary/40">
                         <FileText className="w-12 h-12 text-primary" />
                      </div>
                      <div className="space-y-2">
                        <h2 className="heading-main text-2xl">{viewingFile?.name}</h2>
                        <p className="text-meta text-muted-foreground uppercase italic tracking-tighter font-black">Secure Document Viewing</p>
                      </div>
                      <Button asChild className="rounded-xl px-8 h-12 btn-standard">
                        <a href={viewUrl} target="_blank" rel="noopener noreferrer">OPEN IN NEW TAB</a>
                      </Button>
                    </div>
                  )}
                </div>
              ) : null}
            </div>
            
            <div className="bg-muted/10 border-t border-border/20 p-6 flex items-center justify-between">
               <div className="flex items-center gap-4">
                  <div className="p-3 bg-primary/10 rounded-xl">
                    {viewingFile && getFileIcon(viewingFile.file_type)}
                  </div>
                  <div>
                    <h3 className="text-white font-bold text-lg">{viewingFile?.name}</h3>
                    <p className="text-meta text-white/50">{viewingFile && formatFileSize(viewingFile.size)}</p>
                  </div>
               </div>
               <div className="bg-primary/20 px-4 py-2 rounded-xl border border-primary/30 flex items-center gap-2">
                  <Lock className="w-4 h-4 text-primary" />
                  <span className="text-[10px] font-black uppercase italic tracking-tighter text-primary">SECURE VIEW ONLY</span>
               </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
