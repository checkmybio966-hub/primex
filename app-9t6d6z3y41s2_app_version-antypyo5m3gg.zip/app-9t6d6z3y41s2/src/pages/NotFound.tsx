import { Link } from "react-router-dom";
import { Home, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-background">
      <Card className="w-full max-w-md glass border-border/50">
        <CardContent className="pt-8 pb-8 text-center space-y-6">
          {/* Error Icon */}
          <div className="w-24 h-24 mx-auto rounded-full bg-destructive/20 flex items-center justify-center">
            <AlertCircle className="w-12 h-12 text-destructive" />
          </div>

          {/* Error Code */}
          <div>
            <h1 className="text-6xl font-black text-primary mb-2">404</h1>
            <h2 className="text-heading font-bold text-foreground">Page Not Found</h2>
          </div>

          {/* Error Message */}
          <p className="text-body text-muted-foreground max-w-sm mx-auto">
            The page you're looking for doesn't exist or has been moved. Please check the URL or return to the homepage.
          </p>

          {/* Back Button */}
          <Link to="/">
            <Button className="h-12 px-8 rounded-xl bg-primary hover:bg-primary/90 flex items-center gap-2 mx-auto">
              <Home className="w-5 h-5" />
              Back to Home
            </Button>
          </Link>

          {/* Footer */}
          <p className="text-small text-muted-foreground pt-4">
            &copy; {new Date().getFullYear()} Primex
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
