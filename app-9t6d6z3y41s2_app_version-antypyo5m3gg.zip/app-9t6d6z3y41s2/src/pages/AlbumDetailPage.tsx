import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import type { Album, MediaItem } from '@/types';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { ArrowLeft, Play, Lock, Sparkles, Image as ImageIcon, Video as VideoIcon } from 'lucide-react';
import { toast } from 'sonner';
import { FullScreenViewer } from '@/components/media/FullScreenViewer';
import { cn } from '@/lib/utils';

export default function AlbumDetailPage() {
  const { albumId } = useParams<{ albumId: string }>();
  const { isPremium, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [album, setAlbum] = useState<Album | null>(null);
  const [loading, setLoading] = useState(true);
  const [viewerOpen, setViewerOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);

  const hasAccess = isPremium || isAdmin;

  useEffect(() => {
    if (!albumId) {
      navigate('/premium-feed');
      return;
    }
    fetchAlbum();
  }, [albumId]);

  const fetchAlbum = async () => {
    if (!albumId) return;
    
    setLoading(true);
    try {
      const { data, error } = await api.supabase
        .from('albums')
        .select('*, profiles(*)')
        .eq('id', albumId)
        .single();

      if (error) throw error;
      setAlbum(data);
    } catch (error) {
      console.error('Failed to fetch album:', error);
      toast.error('Failed to load album');
      navigate('/premium-feed');
    } finally {
      setLoading(false);
    }
  };

  const openMedia = (index: number) => {
    setSelectedIndex(index);
    setViewerOpen(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen pb-20 md:pb-4">
        <div className="sticky top-0 z-50 bg-card/95 backdrop-blur-xl border-b border-border/50 px-3 py-2">
          <div className="flex items-center gap-2">
            <Skeleton className="w-8 h-8 rounded-lg bg-muted/20" />
            <Skeleton className="h-5 w-40 bg-muted/20" />
          </div>
        </div>
        <div className="max-w-4xl mx-auto px-3 py-4">
          <Skeleton className="h-20 w-full rounded-xl bg-muted/20 mb-4" />
          <div className="grid grid-cols-2 gap-2">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Skeleton key={i} className="aspect-square rounded-xl bg-muted/20" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!album) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="text-center space-y-3">
          <div className="w-16 h-16 bg-muted/20 rounded-full flex items-center justify-center mx-auto">
            <ImageIcon className="w-8 h-8 text-muted-foreground" />
          </div>
          <h2 className="text-section font-bold">Album not found</h2>
          <Button onClick={() => navigate('/premium-feed')} className="h-10">
            Go Back
          </Button>
        </div>
      </div>
    );
  }

  if (!hasAccess && album.is_premium) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center space-y-6">
        <div className="relative">
          <div className="w-24 h-24 bg-primary/10 rounded-3xl flex items-center justify-center border border-primary/20 shadow-2xl animate-pulse">
            <Lock className="w-12 h-12 text-primary" />
          </div>
          <div className="absolute -top-2 -right-2 bg-yellow-500 rounded-full p-2 shadow-lg border-4 border-background">
            <Sparkles className="w-5 h-5 text-white fill-white" />
          </div>
        </div>
        <div className="space-y-2">
          <h1 className="text-xl font-black uppercase italic tracking-tighter">PREMIUM ALBUM</h1>
          <p className="text-small text-muted-foreground max-w-xs">
            Upgrade to Premium to access this exclusive album
          </p>
        </div>
        <Button 
          onClick={() => navigate('/premium')}
          className="h-11 px-6 rounded-xl bg-gradient-primary"
        >
          <Sparkles className="w-4 h-4 mr-2" />
          Upgrade Now
        </Button>
      </div>
    );
  }

  const mediaItems = album.media_items || [];

  return (
    <div className="min-h-screen pb-20 md:pb-4">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-card/95 backdrop-blur-xl border-b border-border/50 px-3 py-2">
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/premium-feed')}
            className="h-8 w-8"
          >
            <ArrowLeft className="w-4.5 h-4.5" />
          </Button>
          <div className="flex-1 min-w-0">
            <h1 className="text-section font-bold uppercase italic tracking-tighter truncate">
              {album.title || 'Untitled Album'}
            </h1>
          </div>
          {album.is_premium && (
            <div className="flex items-center gap-1 bg-primary/10 px-2 py-1 rounded-lg">
              <Sparkles className="w-3 h-3 text-primary" />
              <span className="text-[10px] font-bold text-primary uppercase">Premium</span>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-3 py-4">
        {/* Album Info */}
        {album.description && (
          <Card className="glass border-border/50 p-3 mb-4">
            <p className="text-small text-muted-foreground leading-relaxed">
              {album.description}
            </p>
          </Card>
        )}

        {/* Media Count */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-small">
              <ImageIcon className="w-4 h-4 text-muted-foreground" />
              <span className="font-bold">{mediaItems.filter(m => m.type === 'image').length}</span>
              <span className="text-muted-foreground">Photos</span>
            </div>
            <div className="flex items-center gap-1.5 text-small">
              <VideoIcon className="w-4 h-4 text-muted-foreground" />
              <span className="font-bold">{mediaItems.filter(m => m.type === 'video').length}</span>
              <span className="text-muted-foreground">Videos</span>
            </div>
          </div>
          <span className="text-small font-bold text-muted-foreground">
            {mediaItems.length} Total
          </span>
        </div>

        {/* 2-Column Grid Layout */}
        {mediaItems.length > 0 ? (
          <div className="grid grid-cols-2 gap-2">
            {mediaItems.map((media, index) => (
              <MediaCard
                key={index}
                media={media}
                index={index}
                onClick={() => openMedia(index)}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-16 h-16 bg-muted/20 rounded-full flex items-center justify-center mb-3">
              <ImageIcon className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-section font-bold mb-1">No Media</h3>
            <p className="text-small text-muted-foreground">This album is empty</p>
          </div>
        )}
      </div>

      {/* Full Screen Viewer */}
      <FullScreenViewer
        media={mediaItems}
        initialIndex={selectedIndex}
        open={viewerOpen}
        onOpenChange={setViewerOpen}
      />
    </div>
  );
}

interface MediaCardProps {
  media: MediaItem;
  index: number;
  onClick: () => void;
}

function MediaCard({ media, index, onClick }: MediaCardProps) {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);

  return (
    <div
      onClick={onClick}
      className={cn(
        "relative aspect-square rounded-xl overflow-hidden bg-muted/20 cursor-pointer group",
        "border border-border/30 hover:border-primary/30 transition-all",
        "active:scale-95"
      )}
    >
      {/* Loading Skeleton */}
      {!imageLoaded && !imageError && (
        <div className="absolute inset-0 animate-pulse bg-muted/30" />
      )}

      {/* Media Content */}
      {media.type === 'image' ? (
        <>
          <img
            src={media.url}
            alt={`Media ${index + 1}`}
            className={cn(
              "w-full h-full object-cover transition-all duration-300",
              imageLoaded ? "opacity-100" : "opacity-0",
              "group-hover:scale-105"
            )}
            loading="lazy"
            onLoad={() => setImageLoaded(true)}
            onError={() => {
              setImageError(true);
              setImageLoaded(true);
            }}
          />
          {imageError && (
            <div className="absolute inset-0 flex items-center justify-center">
              <ImageIcon className="w-8 h-8 text-muted-foreground" />
            </div>
          )}
        </>
      ) : (
        <>
          <video
            src={media.url}
            className="w-full h-full object-cover"
            preload="metadata"
            onLoadedData={() => setImageLoaded(true)}
          />
          {/* Play Icon Overlay */}
          <div className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/40 transition-colors">
            <div className="w-12 h-12 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
              <Play className="w-6 h-6 text-black ml-0.5" fill="currentColor" />
            </div>
          </div>
        </>
      )}

      {/* Index Badge */}
      <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-sm px-2 py-0.5 rounded-lg">
        <span className="text-[10px] font-bold text-white">{index + 1}</span>
      </div>
    </div>
  );
}
