import { useEffect, useState, useRef } from 'react';
import { api } from '@/db/api';
import { useAuth } from '@/contexts/AuthContext';
import type { Post } from '@/types';
import { ReelCard } from '@/components/common/ReelCard';
import { toast } from 'sonner';
import { Skeleton } from '@/components/ui/skeleton';
import { Play, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function ReelsPage() {
  const [reels, setReels] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeIndex, setActiveIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const { isAdmin } = useAuth();
  const navigate = useNavigate();


  const fetchReels = async () => {
    try {
      const data = await api.getPosts('reel', 20);
      setReels(data);
    } catch (error) {
      toast.error('Failed to fetch reels');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReels();
  }, []);

  const handleDelete = async (reelId: string) => {
    try {
      await api.deletePost(reelId);
      setReels(prev => prev.filter(r => r.id !== reelId));
      toast.success('Reel deleted successfully');
    } catch (error) {
      console.error('Failed to delete reel:', error);
      toast.error('Failed to delete reel');
    }
  };

  const handleScroll = () => {
    if (!containerRef.current) return;
    const { scrollTop, clientHeight } = containerRef.current;
    const index = Math.round(scrollTop / clientHeight);
    if (index !== activeIndex && index >= 0 && index < reels.length) {
      setActiveIndex(index);
    }
  };

  // Prevent fast scrolling - snap to one reel at a time
  const handleScrollEnd = () => {
    if (!containerRef.current) return;
    const { scrollTop, clientHeight } = containerRef.current;
    const index = Math.round(scrollTop / clientHeight);
    containerRef.current.scrollTo({
      top: index * clientHeight,
      behavior: 'smooth'
    });
  };

  // Throttle scroll handler for better performance
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    let ticking = false;
    const throttledScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          handleScroll();
          ticking = false;
        });
        ticking = true;
      }
    };

    container.addEventListener('scroll', throttledScroll, { passive: true });
    container.addEventListener('scrollend', handleScrollEnd, { passive: true });
    
    return () => {
      container.removeEventListener('scroll', throttledScroll);
      container.removeEventListener('scrollend', handleScrollEnd);
    };
  }, [activeIndex, reels.length]);

  if (loading) {
    return (
      <div className="h-screen w-full bg-black flex flex-col items-center justify-center p-6 space-y-3">
        <Skeleton className="h-[70vh] w-full max-w-sm rounded-3xl bg-muted/20" />
        <Skeleton className="h-9 w-40 rounded-xl bg-muted/20" />
      </div>
    );
  }

  return (
    <div className="h-full w-full bg-black relative">
      {/* Back Button */}
      <button 
        onClick={() => navigate('/')} 
        className="absolute top-4 left-4 z-50 w-8 h-8 rounded-full bg-black/30 backdrop-blur-md flex items-center justify-center text-white hover:bg-black/50 transition-all border border-white/10"
      >
        <ArrowLeft className="w-5 h-5" />
      </button>

      {reels.length > 0 ? (
        <div
          ref={containerRef}
          className="h-full w-full overflow-y-scroll snap-y snap-mandatory scrollbar-hide"
          style={{
            WebkitOverflowScrolling: 'touch',
            scrollBehavior: 'smooth',
            transform: 'translateZ(0)',
            willChange: 'scroll-position'
          }}
        >
          {reels.map((reel, index) => (
            <div key={reel.id} className="h-full w-full snap-start shrink-0 relative">
              <ReelCard 
                reel={reel} 
                isActive={activeIndex === index} 
                onDelete={isAdmin ? handleDelete : undefined}
                // Preload current, previous and next
                preload={Math.abs(activeIndex - index) <= 1}
              />
            </div>
          ))}
        </div>
      ) : (
        <div className="h-full w-full flex flex-col items-center justify-center text-center p-6 bg-black">
          <div className="w-20 h-20 bg-muted/20 rounded-[1.5rem] flex items-center justify-center mb-6 border-2 border-primary/20 animate-pulse">
            <Play className="w-10 h-10 text-primary fill-primary" />
          </div>
          <h2 className="heading-main text-2xl mb-3 text-white">No Reels Found</h2>
          <p className="text-normal text-muted-foreground max-w-xs mb-6">Be the first to share an amazing reel on Primex!</p>
          <button 
            onClick={() => navigate('/create')} 
            className="rounded-xl h-11 px-8 bg-primary text-white text-small font-bold shadow-xl hover:scale-105 active:scale-95 transition-all uppercase tracking-tight italic"
          >
             CREATE REEL
          </button>
        </div>
      )}
    </div>
  );
}
