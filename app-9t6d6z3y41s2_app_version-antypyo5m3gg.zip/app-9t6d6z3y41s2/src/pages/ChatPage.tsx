import { MessageCircle, Search, Users, MoreVertical, Send, Plus, Loader2, Trash2, AlertCircle, File, X, Image as ImageIcon, Video as VideoIcon } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useState, useEffect, useRef } from 'react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { FilePickerModal } from '@/components/chat/FilePickerModal';
import type { FileItem } from '@/types';
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuTrigger,
} from "@/components/ui/context-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Skeleton } from '@/components/ui/skeleton';
import { formatDistanceToNow } from 'date-fns';

function MessageMedia({ url, type, name }: { url: string, type: string, name?: string }) {
  const [signedUrl, setSignedUrl] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUrl = async () => {
      try {
        const url_str = await api.getFileSignedUrl(url);
        setSignedUrl(url_str);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchUrl();
  }, [url]);

  if (loading) return <Skeleton className="w-64 h-48 rounded-xl bg-white/10" />;
  if (!signedUrl) return <div className="p-4 text-xs text-white/50 italic">Media unavailable</div>;

  if (type.includes('image')) {
    return (
      <img 
        src={signedUrl} 
        alt={name || 'image'} 
        className="max-w-full h-auto max-h-80 object-contain pointer-events-none select-none rounded-lg" 
        onContextMenu={e => e.preventDefault()}
        onDragStart={e => e.preventDefault()}
      />
    );
  }

  if (type.includes('video')) {
    return (
      <video 
        src={signedUrl} 
        className="max-w-full max-h-80 rounded-lg" 
        controls 
        controlsList="nodownload" 
        onContextMenu={e => e.preventDefault()}
      />
    );
  }

  return (
    <div className="flex items-center gap-3 p-4 bg-black/40 rounded-xl border border-white/10 group">
       <div className="p-2 bg-primary/20 rounded-lg group-hover:bg-primary/30 transition-colors">
         <File className="w-5 h-5 text-primary" />
       </div>
       <div className="flex-1 min-w-0">
         <p className="text-xs font-black uppercase italic tracking-tighter truncate text-white">{name || 'document'}</p>
         <p className="text-[10px] text-white/50 uppercase font-black tracking-tighter">Secure File</p>
       </div>
    </div>
  );
}

export default function ChatPage() {
  const { user } = useAuth();
  const [activeChat, setActiveChat] = useState<string | null>(null);
  const [conversations, setConversations] = useState<any[]>([]);
  const [messages, setMessages] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [msgLoading, setMsgLoading] = useState(false);
  const [newMsg, setNewMsg] = useState('');
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [chatToDelete, setChatToDelete] = useState<string | null>(null);
  const [isFilePickerOpen, setIsFilePickerOpen] = useState(false);
  const [attachment, setAttachment] = useState<{ url: string, type: string, name: string } | null>(null);
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const fetchConversations = async () => {
    if (!user) return;
    try {
      const data = await api.getConversations(user.id);
      setConversations(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const fetchMessages = async (convId: string) => {
    setMsgLoading(true);
    try {
      const data = await api.getMessages(convId);
      setMessages(data);
    } catch (error) {
      console.error(error);
    } finally {
      setMsgLoading(false);
    }
  };

  useEffect(() => {
    fetchConversations();
    
    // Subscribe to changes
    const sub = supabase.channel('chat-updates')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, () => {
        fetchConversations();
        if (activeChat) fetchMessages(activeChat);
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'conversation_members' }, () => {
        fetchConversations();
      })
      .subscribe();
    
    return () => {
      supabase.removeChannel(sub);
    };
  }, [user?.id, activeChat]);

  useEffect(() => {
    if (activeChat) {
      fetchMessages(activeChat);
    } else {
      setMessages([]);
    }
  }, [activeChat]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!activeChat || (!newMsg.trim() && !attachment) || !user) return;
    setSending(true);
    try {
      await api.sendMessage(
        activeChat, 
        user.id, 
        newMsg.trim(), 
        attachment?.url, 
        attachment?.type,
        attachment?.name
      );
      setNewMsg('');
      setAttachment(null);
    } catch (error) {
      toast.error('Failed to send message');
    } finally {
      setSending(false);
    }
  };

  const handleFileSelect = (file: FileItem) => {
    setAttachment({
      url: file.url,
      type: file.file_type,
      name: file.name
    });
    setIsFilePickerOpen(false);
  };

  const handleFileUpload = async (file: File) => {
    if (!user) return;
    try {
      const uploadedFile = await api.uploadFile(user.id, file, file.name, file.type, null);
      setAttachment({
        url: uploadedFile.url,
        type: uploadedFile.file_type,
        name: uploadedFile.name
      });
      setIsFilePickerOpen(false);
    } catch (error) {
      toast.error('Upload failed');
    }
  };

  const [deletingId, setDeletingId] = useState<string | null>(null);

  const handleDeleteChat = async () => {
    if (!chatToDelete || !user) return;
    try {
      // Start exit animation
      setDeletingId(chatToDelete);
      
      // Wait for animation to finish
      await new Promise(resolve => setTimeout(resolve, 300));
      
      // Optimitic UI update
      setConversations(prev => prev.filter(c => c.id !== chatToDelete));
      if (activeChat === chatToDelete) setActiveChat(null);
      
      await api.deleteConversation(chatToDelete, user.id);
      toast.success('Chat deleted successfully');
    } catch (error) {
      toast.error('Failed to delete chat');
      fetchConversations(); // Rollback
    } finally {
      setChatToDelete(null);
      setDeleteConfirmOpen(false);
      setDeletingId(null);
    }
  };

  const activeChatData = conversations.find(c => c.id === activeChat);

  if (loading) return (
    <div className="h-screen flex items-center justify-center">
      <Loader2 className="w-12 h-12 animate-spin text-primary" />
    </div>
  );

  return (
    <div className="h-screen md:h-[calc(100vh-1rem)] py-2 flex overflow-hidden animate-fade-in gap-3 px-2 md:px-0">
      {/* Sidebar - Chats List */}
      <Card className={cn("glass border-border/50 shadow-card flex flex-col w-full md:w-72 shrink-0 rounded-2xl overflow-hidden", activeChat !== null && "max-md:hidden")}>
        <div className="p-4 border-b border-border/50 bg-muted/20">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-section font-bold">Messages</h2>
            <Button variant="ghost" size="icon" className="rounded-lg h-8 w-8">
              <Plus className="w-4 h-4 text-primary" />
            </Button>
          </div>
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input className="bg-background/50 border-border/50 pl-8 h-9 rounded-lg text-sm" placeholder="Search chats..." />
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {conversations.map(chat => (
            <ContextMenu key={chat.id}>
              <ContextMenuTrigger>
                <div 
                  onClick={() => setActiveChat(chat.id)}
                  className={cn(
                    "flex items-center gap-4 p-4 rounded-2xl cursor-pointer transition-all hover:bg-muted/50 group animate-in slide-in-from-left-4 duration-300",
                    activeChat === chat.id ? "bg-primary/10 border border-primary/20" : "border border-transparent",
                    deletingId === chat.id && "animate-out slide-out-to-left-full fade-out-0 duration-300"
                  )}
                >
                  <div className="relative shrink-0">
                    <Avatar className="w-12 h-12 border-2 border-border group-hover:border-primary transition-colors">
                      <AvatarImage src={chat.otherParticipant?.profile_image || `https://api.dicebear.com/7.x/avataaars/svg?seed=${chat.otherParticipant?.username}`} />
                      <AvatarFallback>{chat.otherParticipant?.username?.[0]}</AvatarFallback>
                    </Avatar>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-center mb-0.5">
                      <p className="font-bold text-sm truncate uppercase tracking-tight">{chat.otherParticipant?.username}</p>
                      <span className="text-meta uppercase font-black tracking-tighter">
                        {chat.lastMessage ? formatDistanceToNow(new Date(chat.lastMessage.created_at), { addSuffix: true }) : ''}
                      </span>
                    </div>
                    <p className={cn("text-xs truncate font-medium", activeChat === chat.id ? "text-foreground" : "text-muted-foreground")}>
                      {chat.lastMessage?.content || 'No messages yet'}
                    </p>
                  </div>
                </div>
              </ContextMenuTrigger>
              <ContextMenuContent className="bg-card border-border shadow-2xl rounded-xl p-1 w-48">
                <ContextMenuItem 
                  className="flex items-center gap-2 text-destructive focus:text-destructive focus:bg-destructive/10 rounded-lg cursor-pointer"
                  onClick={() => {
                    setChatToDelete(chat.id);
                    setDeleteConfirmOpen(true);
                  }}
                >
                  <Trash2 className="w-4 h-4" />
                  <span className="btn-standard text-xs">Delete Chat</span>
                </ContextMenuItem>
              </ContextMenuContent>
            </ContextMenu>
          ))}
          {conversations.length === 0 && (
            <div className="flex flex-col items-center justify-center py-12 text-center opacity-40">
               <MessageCircle className="w-12 h-12 mb-4" />
               <p className="text-meta font-black uppercase italic tracking-tighter">No active chats</p>
            </div>
          )}
        </div>
      </Card>

      {/* Main Chat Window */}
      <Card className={cn("glass border-border/50 shadow-card flex-1 flex flex-col rounded-3xl overflow-hidden", activeChat === null && "max-md:hidden")}>
        {activeChat !== null ? (
          <>
            {/* Header */}
            <div className="p-4 border-b border-border/50 flex items-center justify-between bg-muted/20">
              <div className="flex items-center gap-4">
                <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setActiveChat(null)}>
                  <Plus className="w-5 h-5 rotate-45" />
                </Button>
                <div className="relative">
                  <Avatar className="w-10 h-10 border-2 border-primary">
                    <AvatarImage src={activeChatData?.otherParticipant?.profile_image || `https://api.dicebear.com/7.x/avataaars/svg?seed=${activeChatData?.otherParticipant?.username}`} />
                  </Avatar>
                </div>
                <div>
                  <p className="text-section font-black uppercase italic tracking-tighter leading-none">{activeChatData?.otherParticipant?.username}</p>
                  <p className="text-meta text-primary font-black uppercase italic tracking-tighter">Premium User</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="rounded-xl h-10 w-10 text-muted-foreground" onClick={() => {
                   setChatToDelete(activeChat);
                   setDeleteConfirmOpen(true);
                }}>
                  <Trash2 className="w-5 h-5" />
                </Button>
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6 flex flex-col bg-black/10">
               <div className="flex flex-col items-center gap-4 mb-8">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center border border-primary/20">
                     <Users className="w-8 h-8 text-primary" />
                  </div>
                  <div className="text-center">
                     <p className="text-section font-black uppercase italic tracking-tighter mb-1">Encrypted Chat</p>
                     <p className="text-meta font-medium">Messages are end-to-end encrypted for your safety.</p>
                  </div>
               </div>

               {messages.map((msg, idx) => (
                  <div 
                    key={msg.id} 
                    className={cn(
                      "flex max-w-[80%] animate-in slide-in-from-bottom-2 duration-300",
                      msg.sender_id === user?.id ? "self-end justify-end" : "justify-start"
                    )}
                  >
                    <div className={cn(
                      "p-4 rounded-2xl shadow-md border overflow-hidden",
                      msg.sender_id === user?.id 
                        ? "bg-primary text-white border-primary/50 rounded-br-none shadow-primary/20" 
                        : "bg-muted/40 text-foreground border-border/30 rounded-bl-none"
                    )}>
                       {msg.media_url && (
                         <div className="mb-3 rounded-xl overflow-hidden bg-black/20 border border-white/10">
                            <MessageMedia url={msg.media_url} type={msg.media_type} name={msg.file_name} />
                         </div>
                       )}
                       {msg.content && (
                         <p className={cn("text-normal leading-relaxed", msg.sender_id === user?.id ? "font-black italic tracking-tight" : "font-medium")}>
                           {msg.content}
                         </p>
                       )}
                       <span className={cn(
                         "text-meta font-black uppercase mt-2 block",
                         msg.sender_id === user?.id ? "text-white/80" : ""
                       )}>
                         {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                       </span>
                    </div>
                  </div>
               ))}
               <div ref={messagesEndRef} />
            </div>

            {/* Footer Input */}
            <div className="p-6 border-t border-border/50 bg-muted/20 space-y-4">
               {/* Attachment Preview */}
               {attachment && (
                 <div className="flex items-center gap-4 p-4 bg-background border border-primary/30 rounded-2xl animate-in zoom-in-95 duration-200">
                    <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center border border-primary/20">
                      {attachment.type.includes('image') ? <ImageIcon className="w-6 h-6 text-primary" /> : attachment.type.includes('video') ? <VideoIcon className="w-6 h-6 text-primary" /> : <File className="w-6 h-6 text-primary" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-black uppercase italic tracking-tighter truncate">{attachment.name}</p>
                      <p className="text-[10px] text-muted-foreground uppercase font-black tracking-tighter">Ready to send</p>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => setAttachment(null)} className="rounded-xl h-8 w-8 text-muted-foreground hover:text-destructive transition-colors">
                      <X className="w-4 h-4" />
                    </Button>
                 </div>
               )}

               <form 
                 onSubmit={(e) => {
                   e.preventDefault();
                   handleSend();
                 }}
                 className="flex gap-4 items-center"
               >
                  <Button 
                    type="button"
                    variant="ghost" 
                    size="icon" 
                    onClick={() => setIsFilePickerOpen(true)}
                    className="w-14 h-14 rounded-2xl bg-muted/20 border border-border/30 hover:bg-blue-500/10 hover:border-blue-500/30 transition-all active:scale-90 group shrink-0"
                  >
                     <Plus className="w-8 h-8 text-muted-foreground group-hover:text-blue-500 transition-colors" />
                  </Button>
                  <div className="flex-1 relative group">
                     <Input 
                       value={newMsg}
                       onChange={(e) => setNewMsg(e.target.value)}
                       className="bg-background/80 border-border/50 h-14 rounded-2xl px-6 text-base font-medium focus:ring-primary/50 transition-all shadow-inner" 
                       placeholder="Type a message..." 
                     />
                  </div>
                  <Button 
                    type="submit"
                    size="icon" 
                    disabled={(!newMsg.trim() && !attachment) || sending}
                    className="w-14 h-14 rounded-2xl bg-primary hover:bg-primary/90 shadow-xl transition-all active:scale-90 flex items-center justify-center shrink-0 disabled:opacity-50"
                  >
                     {sending ? <Loader2 className="w-6 h-6 animate-spin text-white" /> : <Send className="w-6 h-6 text-white ml-0.5" />}
                  </Button>
               </form>
            </div>
            
            <FilePickerModal 
              open={isFilePickerOpen} 
              onOpenChange={setIsFilePickerOpen}
              onSelect={handleFileSelect}
              onUpload={handleFileUpload}
            />
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-12">
            <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mb-8 border-2 border-primary/20 animate-pulse">
               <MessageCircle className="w-12 h-12 text-primary" />
            </div>
            <h2 className="text-3xl font-black uppercase italic tracking-tighter mb-4 gradient-text italic">Your Messages</h2>
            <p className="text-muted-foreground max-w-sm mb-8 font-medium">Connect with other premium users and the Primex team in real-time.</p>
            <Button className="rounded-2xl h-14 px-10 font-black text-xl italic tracking-tight shadow-xl">
               START CHATTING
            </Button>
          </div>
        )}
      </Card>

      <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <AlertDialogContent className="bg-card border-border rounded-3xl shadow-2xl p-8 max-w-sm mx-auto">
          <AlertDialogHeader className="flex flex-col items-center text-center gap-4">
            <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center border border-destructive/20 mb-2">
               <AlertCircle className="w-8 h-8 text-destructive" />
            </div>
            <AlertDialogTitle className="text-2xl font-black uppercase italic tracking-tighter leading-none">Delete Chat?</AlertDialogTitle>
            <AlertDialogDescription className="text-muted-foreground font-medium">
              Are you sure you want to delete this chat? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-col sm:flex-row gap-3 mt-8">
            <AlertDialogCancel className="flex-1 rounded-2xl h-12 font-bold uppercase italic tracking-tighter border-border hover:bg-muted transition-all">Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteChat}
              className="flex-1 rounded-2xl h-12 bg-destructive hover:bg-destructive/90 text-white font-bold uppercase italic tracking-tighter shadow-lg shadow-destructive/20 transition-all"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
