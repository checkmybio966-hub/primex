import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { supabase } from '@/db/supabase';
import type { Profile, Settings } from '@/types';
import { BannerManagement } from '@/components/admin/BannerManagement';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ShieldCheck, Users, Image as ImageIcon, Eye, Heart, Zap, CheckCircle2, XCircle, Plus, Loader2, Save, Upload, UserX, FolderOpen, FileText, Search, Star } from 'lucide-react';
import { toast } from 'sonner';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function AdminPage() {
  const { isAdmin, user: currentUser } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState<any>(null);
  const [pendingUsers, setPendingUsers] = useState<Profile[]>([]);
  const [premiumRequests, setPremiumRequests] = useState<Profile[]>([]);
  const [allProfiles, setAllProfiles] = useState<Profile[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [settings, setSettings] = useState<Settings | null>(null);
  const [loading, setLoading] = useState(true);
  const [updatingSettings, setUpdatingSettings] = useState(false);
  const [uploadingQR, setUploadingQR] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [fileName, setFileName] = useState('');

  const fetchData = async () => {
    try {
      const [statsData, pendingData, premiumData, settingsData, profilesData] = await Promise.all([
        api.getAdminStats(),
        api.getPendingUsers(),
        api.getPremiumRequests(),
        api.getSettings(),
        api.getAllProfiles()
      ]);
      setStats(statsData);
      setPendingUsers(pendingData);
      setPremiumRequests(premiumData);
      setSettings(settingsData);
      setAllProfiles(profilesData);
    } catch (error) {
      toast.error('Failed to fetch admin data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!isAdmin) {
      navigate('/');
      return;
    }

    fetchData();

    // Real-time subscriptions
    const channel = supabase.channel('admin-updates')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, () => fetchData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'posts' }, () => fetchData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'likes' }, () => fetchData())
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [isAdmin, navigate]);

  const handleApproveUser = async (userId: string) => {
    try {
      await api.updateProfile(userId, { status: 'approved' });
      toast.success('User approved');
    } catch (error) {
      toast.error('Failed to approve user');
    }
  };

  const handleRejectUser = async (userId: string) => {
    try {
      const { error } = await supabase.rpc('delete_user', { user_id: userId });
      if (error) throw error;
      toast.success('User rejected and deleted');
    } catch (error: any) {
      console.error('Failed to reject user:', error);
      toast.error(error.message || 'Failed to reject user');
    }
  };

  const handleApprovePremium = async (userId: string) => {
    try {
      await api.updateProfile(userId, { 
        subscription_status: 'active', 
        role: 'premium_user',
        is_premium: true 
      });
      toast.success('Premium subscription approved');
    } catch (error) {
      toast.error('Failed to approve premium');
    }
  };

  const handleRejectPremium = async (userId: string) => {
    try {
      await api.updateProfile(userId, { subscription_status: 'rejected' });
      toast.success('Premium subscription rejected');
    } catch (error) {
      toast.error('Failed to reject premium');
    }
  };

  const handleUpdateSettings = async () => {
    if (!settings) return;
    setUpdatingSettings(true);
    try {
      await api.updateSettings({ payment_text: settings.payment_text });
      toast.success('Settings updated');
    } catch (error) {
      toast.error('Failed to update settings');
    } finally {
      setUpdatingSettings(false);
    }
  };

  const handleQRUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingQR(true);
    try {
      const fileName = `admin/qr-${Date.now()}.jpg`;
      const { data, error } = await supabase.storage.from('primex_images').upload(fileName, file);
      if (error) throw error;

      const { data: { publicUrl } } = supabase.storage.from('primex_images').getPublicUrl(fileName);
      await api.updateSettings({ premium_qr_url: publicUrl });
      setSettings((prev: Settings | null) => prev ? { ...prev, premium_qr_url: publicUrl } : null);
      toast.success('QR Code updated');
    } catch (error: any) {
      toast.error(error.message || 'QR upload failed');
    } finally {
      setUploadingQR(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentUser) return;

    setUploadingFile(true);
    try {
      await api.uploadFile(currentUser.id, file, fileName || file.name, file.type);
      toast.success('File uploaded to secure storage');
      setFileName('');
      fetchData();
    } catch (error: any) {
      toast.error(error.message || 'File upload failed');
    } finally {
      setUploadingFile(false);
    }
  };

  const handleUpdateRole = async (userId: string, role: string) => {
    try {
      await api.updateProfile(userId, { 
        role: role as any,
        is_premium: role === 'premium_user' || role === 'admin'
      });
      toast.success(`User role updated to ${role}`);
      setAllProfiles(prev => prev.map(p => p.id === userId ? { ...p, role: role as any, is_premium: role === 'premium_user' || role === 'admin' } : p));
    } catch (error) {
      toast.error('Failed to update user role');
    }
  };

  const filteredProfiles = allProfiles.filter(p => 
    p.username.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.email.toLowerCase().includes(searchQuery.toLowerCase())
  ).slice(0, 5);

  if (loading) return (
    <div className="py-8 space-y-8 animate-pulse">
      <Skeleton className="h-12 w-64 rounded-xl bg-muted" />
      <div className="grid grid-cols-2 gap-4">
        {[1, 2, 3, 4, 5, 6].map(i => <Skeleton key={i} className="h-32 rounded-3xl bg-muted" />)}
      </div>
    </div>
  );

  return (
    <div className="py-8 max-w-4xl mx-auto px-4 space-y-12 animate-fade-in pb-20 md:pb-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center border border-primary/20 shadow-lg">
            <ShieldCheck className="w-7 h-7 text-primary" />
          </div>
          <h2 className="heading-main">Admin Panel</h2>
        </div>
        <div className="flex gap-3">
          <Button onClick={() => navigate('/files')} variant="outline" className="rounded-2xl h-14 px-8 btn-standard shadow-xl border-border/50">
            <FolderOpen className="w-6 h-6 mr-2" />
            MANAGE FILES
          </Button>
          <Button onClick={() => navigate('/create')} className="rounded-2xl h-14 px-8 btn-standard shadow-xl bg-gradient-primary border-none">
            <Plus className="w-6 h-6 mr-2" />
            CREATE CONTENT
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <section>
        <h3 className="text-section font-black uppercase italic tracking-tighter mb-6 flex items-center gap-3">
           <Zap className="w-6 h-6 text-primary fill-primary" />
           Stats Overview
        </h3>
        <div className="grid grid-cols-2 gap-6">
          <StatCard icon={Users} label="Subscribers" value={stats.subscribers} color="text-blue-500" />
          <StatCard icon={ImageIcon} label="Total Posts" value={stats.totalPosts} color="text-orange-500" />
          <StatCard icon={Eye} label="Total Views" value={stats.totalViews} color="text-cyan-500" />
          <StatCard icon={Heart} label="Total Likes" value={stats.totalLikes} color="text-pink-500" />
          <StatCard icon={ShieldCheck} label="Admin Posts" value={stats.adminPosts} color="text-green-500" />
          <StatCard icon={Heart} label="Admin Likes" value={stats.adminLikes} color="text-purple-500" />
        </div>
      </section>

      {/* Banner Management */}
      <BannerManagement />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Manual Role Assignment */}
        <section className="space-y-6">
          <h3 className="text-section font-black uppercase italic tracking-tighter flex items-center gap-3">
            <Users className="w-6 h-6 text-primary" />
            Manage User Roles
          </h3>
          <Card className="glass border-border/50 shadow-card rounded-3xl p-8">
            <div className="space-y-6">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  placeholder="Search users..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-background/50 border-border/50 h-14 rounded-2xl pl-12 text-normal font-bold"
                />
              </div>
              <div className="space-y-3">
                {filteredProfiles.map(profile => (
                  <div key={profile.id} className="flex items-center justify-between p-3 rounded-2xl bg-muted/20 border border-border/50">
                    <div className="flex items-center gap-3 min-w-0">
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={profile.profile_image || ''} />
                        <AvatarFallback>{profile.username?.[0]}</AvatarFallback>
                      </Avatar>
                      <span className="text-sm font-bold truncate">{profile.username}</span>
                    </div>
                    <Select
                      defaultValue={profile.role}
                      onValueChange={(val) => handleUpdateRole(profile.id, val)}
                    >
                      <SelectTrigger className="w-[140px] h-10 bg-background border-border/50 rounded-xl text-xs font-black uppercase tracking-tighter">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-border">
                        <SelectItem value="user">User</SelectItem>
                        <SelectItem value="premium_user">Premium</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                ))}
                {searchQuery && filteredProfiles.length === 0 && (
                  <p className="text-center text-meta italic opacity-50 py-4">No users found</p>
                )}
              </div>
            </div>
          </Card>
        </section>

        {/* Payment Settings */}
        <section className="space-y-6">
          <h3 className="text-section font-black uppercase italic tracking-tighter flex items-center gap-3">
            <Plus className="w-6 h-6 text-primary rotate-45" />
            Premium Settings
          </h3>
          <Card className="glass border-border/50 shadow-card rounded-3xl p-8">
            <div className="space-y-8">
              <div className="space-y-4">
                <label className="text-meta uppercase italic tracking-tighter font-black ml-1">Premium QR Code</label>
                <div className="relative group">
                   <div className="w-full aspect-square bg-white p-4 rounded-3xl shadow-inner border border-border/50 overflow-hidden">
                      <img src={settings?.premium_qr_url || ''} alt="QR" className="w-full h-full object-contain" />
                   </div>
                   <label className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer rounded-3xl">
                      <Upload className="w-10 h-10 text-white mb-2" />
                      <span className="text-white font-black text-sm uppercase italic tracking-tighter">Change QR Code</span>
                      <input type="file" className="hidden" accept="image/*" onChange={handleQRUpload} disabled={uploadingQR} />
                   </label>
                   {uploadingQR && <div className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-3xl">
                      <Loader2 className="w-10 h-10 animate-spin text-primary" />
                   </div>}
                </div>
              </div>

              <div className="space-y-4">
                <label className="text-meta uppercase italic tracking-tighter font-black ml-1">Payment Instructions</label>
                <Textarea
                  value={settings?.payment_text || ''}
                  onChange={(e) => setSettings((prev: Settings | null) => prev ? { ...prev, payment_text: e.target.value } : null)}
                  className="bg-background/50 border-border/50 min-h-[120px] rounded-2xl p-4 focus:ring-primary/50 transition-all text-normal font-medium"
                />
              </div>

              <Button 
                onClick={handleUpdateSettings} 
                className="w-full h-14 rounded-2xl btn-standard shadow-xl"
                disabled={updatingSettings}
              >
                {updatingSettings ? <Loader2 className="w-6 h-6 animate-spin" /> : <><Save className="w-6 h-6 mr-2" /> SAVE CHANGES</>}
              </Button>
            </div>
          </Card>
        </section>
      </div>

      <div className="space-y-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
           {/* Premium Requests */}
          <section className="space-y-6">
            <h3 className="text-section font-black uppercase italic tracking-tighter flex items-center gap-3">
              <ShieldCheck className="w-6 h-6 text-primary" />
              Premium Requests ({premiumRequests.length})
            </h3>
            <div className="space-y-4">
              {premiumRequests.length > 0 ? premiumRequests.map(user => (
                <RequestCard 
                  key={user.id} 
                  user={user} 
                  onApprove={() => handleApprovePremium(user.id)} 
                  onReject={() => handleRejectPremium(user.id)} 
                  type="premium"
                />
              )) : (
                <div className="p-8 text-center bg-muted/20 border border-dashed border-border/50 rounded-3xl font-bold text-meta uppercase italic tracking-tighter">
                   No premium requests pending
                </div>
              )}
            </div>
          </section>

          {/* Pending Users */}
          <section className="space-y-6">
            <h3 className="text-section font-black uppercase italic tracking-tighter flex items-center gap-3 text-yellow-500">
              <Users className="w-6 h-6" />
              User Approvals ({pendingUsers.length})
            </h3>
            <div className="space-y-4">
              {pendingUsers.length > 0 ? pendingUsers.map(user => (
                <RequestCard 
                  key={user.id} 
                  user={user} 
                  onApprove={() => handleApproveUser(user.id)} 
                  onReject={() => handleRejectUser(user.id)} 
                  type="user"
                />
              )) : (
                <div className="p-8 text-center bg-muted/20 border border-dashed border-border/50 rounded-3xl font-bold text-meta uppercase italic tracking-tighter">
                   No user approvals pending
                </div>
              )}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }: { icon: any, label: string, value: number, color: string }) {
  return (
    <Card className="glass border-border/50 shadow-card rounded-3xl p-6 group hover:border-primary/30 transition-all hover:scale-[1.05]">
      <div className="flex flex-col gap-4">
        <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center bg-muted/50 border border-border/50 group-hover:scale-110 transition-transform", color)}>
          <Icon className="w-6 h-6" />
        </div>
        <div>
          <p className="text-[28px] font-black uppercase italic tracking-tighter gradient-text leading-none">{value}</p>
          <p className="text-meta uppercase font-black tracking-tighter mt-1">{label}</p>
        </div>
      </div>
    </Card>
  );
}

function RequestCard({ user, onApprove, onReject, type }: { user: Profile, onApprove: () => void, onReject: () => void, type: 'premium' | 'user' }) {
  return (
    <Card className="glass border-border/50 shadow-card rounded-2xl p-4 overflow-hidden relative">
      <div className="flex items-center gap-4">
        <Avatar className="w-12 h-12 border-2 border-border group-hover:border-primary transition-colors">
          <AvatarImage src={user.profile_image || ''} />
          <AvatarFallback>{user.username?.[0]?.toUpperCase()}</AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <p className="font-bold text-normal truncate uppercase tracking-tight leading-none mb-1">
            {user.username}
          </p>
          <p className="text-meta truncate leading-none mb-2">{user.email}</p>
          {type === 'premium' && (
            <div className="flex items-center gap-1 text-yellow-500">
               <div className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse" />
               <span className="text-[10px] font-black uppercase italic tracking-tighter">
                 clicked I HAVE PAID
               </span>
            </div>
          )}
        </div>
        <div className="flex items-center gap-2">
           <Button 
            size="icon" 
            variant="ghost" 
            onClick={onApprove} 
            className="rounded-xl h-12 w-12 text-primary hover:bg-primary/10 transition-colors"
          >
            <CheckCircle2 className="w-7 h-7" />
          </Button>
          <Button 
            size="icon" 
            variant="ghost" 
            onClick={onReject} 
            className="rounded-xl h-12 w-12 text-destructive hover:bg-destructive/10 transition-colors"
          >
            {type === 'premium' ? <XCircle className="w-7 h-7" /> : <UserX className="w-7 h-7" />}
          </Button>
        </div>
      </div>
    </Card>
  );
}
