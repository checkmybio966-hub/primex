import { supabase } from './supabase';
import type { Post, Profile, Like, Comment, Settings, UserRole, UserStatus, SubscriptionStatus, FileItem, Folder, Album } from '@/types';

export const api = {
  supabase, // Export supabase for direct access in components
  
  // Profiles
  async getProfile(userId: string): Promise<Profile | null> {
    const { data } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle();
    return data;
  },

  async getAllProfiles(): Promise<Profile[]> {
    const { data } = await supabase.from('profiles').select('*').order('username', { ascending: true });
    return data || [];
  },

  async updateProfile(userId: string, updates: Partial<Profile>) {
    return supabase.from('profiles').update(updates).eq('id', userId);
  },

  async getPendingUsers(): Promise<Profile[]> {
    const { data } = await supabase.from('profiles').select('*').eq('status', 'pending').order('created_at', { ascending: false });
    return data || [];
  },

  async getPremiumRequests(): Promise<Profile[]> {
    const { data } = await supabase.from('profiles').select('*').eq('subscription_status', 'payment_pending').order('created_at', { ascending: false });
    return data || [];
  },

  // Posts
  async getPosts(type: 'post' | 'reel', limit = 10, offset = 0, premiumOnly = false): Promise<Post[]> {
    let query = supabase
      .from('posts')
      .select('*, profiles(*)')
      .eq('type', type)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);
    
    if (premiumOnly) {
      query = query.eq('is_premium', true);
    } else {
      query = query.eq('is_premium', false);
    }
    
    const { data } = await query;
    return data || [];
  },

  async getPremiumPosts(limit = 10, offset = 0): Promise<Post[]> {
    const { data } = await supabase
      .from('posts')
      .select('*, profiles(*)')
      .eq('is_premium', true)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);
    return data || [];
  },

  async createPost(post: Omit<Post, 'id' | 'created_at' | 'likes_count' | 'comments_count' | 'views_count'>) {
    const { data: profile } = await supabase.from('profiles').select('role').eq('id', post.user_id).single();
    return supabase.from('posts').insert({
      ...post,
      user_role: profile?.role || 'user',
      is_premium: post.is_premium || false
    });
  },

  // Folders
  async getFolders(): Promise<Folder[]> {
    const { data } = await supabase.from('folders').select('*').order('name', { ascending: true });
    return data || [];
  },

  async createFolder(name: string, userId: string) {
    return supabase.from('folders').insert({ name, user_id: userId }).select().single();
  },

  async updateFolder(folderId: string, updates: Partial<Folder>) {
    return supabase.from('folders').update(updates).eq('id', folderId);
  },

  async deleteFolder(folderId: string) {
    return supabase.from('folders').delete().eq('id', folderId);
  },

  // Files
  async getFiles(folderId?: string): Promise<FileItem[]> {
    let query = supabase.from('files').select('*').order('created_at', { ascending: false });
    if (folderId) {
      query = query.eq('folder_id', folderId);
    } else {
      query = query.is('folder_id', null);
    }
    const { data } = await query;
    return data || [];
  },

  async uploadFile(userId: string, file: File, name: string, type: string, folderId: string | null = null) {
    // 1. Upload to storage
    const path = `${userId}/${Date.now()}_${file.name}`;
    const { data: storageData, error: storageError } = await supabase.storage
      .from('premium_files')
      .upload(path, file);
    
    if (storageError) throw storageError;

    // 2. Get public URL (though it might not be public if we want to protect it, but we can use signed URLs or just rely on RLS)
    const { data: urlData } = await supabase.storage.from('premium_files').getPublicUrl(path);

    // 3. Save to database
    const { data: fileData, error: dbError } = await supabase.from('files').insert({
      name,
      file_type: type,
      url: path, // We store path so we can generate signed URL later
      size: file.size,
      user_id: userId,
      folder_id: folderId
    }).select().single();

    if (dbError) throw dbError;
    return fileData;
  },

  async getFileSignedUrl(path: string) {
    const { data, error } = await supabase.storage
      .from('premium_files')
      .createSignedUrl(path, 3600); // 1 hour
    
    if (error) throw error;
    return data.signedUrl;
  },

  async updateFile(fileId: string, updates: Partial<FileItem>) {
    return supabase.from('files').update(updates).eq('id', fileId);
  },

  async deleteFile(fileId: string, path: string) {
    // If path is provided, delete from storage
    if (path) {
      await supabase.storage.from('premium_files').remove([path]);
    }
    return supabase.from('files').delete().eq('id', fileId);
  },

  async deletePost(postId: string) {
    return supabase.from('posts').delete().eq('id', postId);
  },

  async incrementViews(postId: string) {
    // We use RPC for atomicity if needed, but simple update is fine for this app
    const { data } = await supabase.rpc('increment_views', { post_id: postId });
    return data;
  },

  // Likes
  async toggleLike(userId: string, postId: string) {
    const { data: existing } = await supabase.from('likes').select('*').eq('user_id', userId).eq('post_id', postId).maybeSingle();
    if (existing) {
      await supabase.from('likes').delete().eq('id', existing.id);
      await supabase.rpc('decrement_likes', { post_id: postId });
      return false;
    } else {
      await supabase.from('likes').insert({ user_id: userId, post_id: postId });
      await supabase.rpc('increment_likes', { post_id: postId });
      return true;
    }
  },

  async isLiked(userId: string, postId: string): Promise<boolean> {
    const { data } = await supabase.from('likes').select('id').eq('user_id', userId).eq('post_id', postId).maybeSingle();
    return !!data;
  },

  // Comments
  async getComments(postId: string): Promise<Comment[]> {
    const { data } = await supabase.from('comments').select('*, profiles(*)').eq('post_id', postId).order('created_at', { ascending: true });
    return data || [];
  },

  async addComment(userId: string, postId: string, content: string) {
    const { data } = await supabase.from('comments').insert({ user_id: userId, post_id: postId, content }).select('*, profiles(*)').single();
    await supabase.rpc('increment_comments', { post_id: postId });
    return data;
  },

  async deleteComment(commentId: string) {
    const { error } = await supabase.from('comments').delete().eq('id', commentId);
    if (error) throw error;
    return true;
  },

  // Settings
  async getSettings(): Promise<Settings | null> {
    const { data } = await supabase.from('settings').select('*').eq('id', 1).maybeSingle();
    return data;
  },

  async updateSettings(updates: Partial<Settings>) {
    return supabase.from('settings').update(updates).eq('id', 1);
  },

  // Admin Stats
  async getAdminStats() {
    const { count: subscribersCount } = await supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('status', 'approved');
    const { count: postsCount } = await supabase.from('posts').select('*', { count: 'exact', head: true }).eq('type', 'post');
    const { data: allPosts } = await supabase.from('posts').select('views_count, likes_count, user_id, user_role');
    
    const totalViews = allPosts?.reduce((sum, p) => sum + (p.views_count || 0), 0) || 0;
    const totalLikes = allPosts?.reduce((sum, p) => sum + (p.likes_count || 0), 0) || 0;
    
    const adminPosts = allPosts?.filter(p => p.user_role === 'admin') || [];
    const adminPostsCount = adminPosts.length;
    const adminLikesTotal = adminPosts.reduce((sum, p) => sum + (p.likes_count || 0), 0) || 0;

    return {
      subscribers: subscribersCount || 0,
      totalPosts: postsCount || 0,
      totalViews,
      totalLikes,
      adminPosts: adminPostsCount,
      adminLikes: adminLikesTotal
    };
  },

  // Chats / Messages
  async getConversations(userId: string) {
    const { data } = await supabase
      .from('conversation_members')
      .select('*, conversations(*)')
      .eq('profile_id', userId)
      .eq('is_deleted', false);
    
    // We also need the other participant for each conversation
    if (!data) return [];
    
    const conversations = await Promise.all(data.map(async (member) => {
      const { data: otherMember } = await supabase
        .from('conversation_members')
        .select('*, profiles(*)')
        .eq('conversation_id', member.conversation_id)
        .neq('profile_id', userId)
        .maybeSingle();
      
      const { data: lastMsg } = await supabase
        .from('messages')
        .select('*')
        .eq('conversation_id', member.conversation_id)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      return {
        id: member.conversation_id,
        otherParticipant: otherMember?.profiles || null,
        lastMessage: lastMsg,
        created_at: member.conversations?.created_at,
        last_message_at: member.conversations?.last_message_at
      };
    }));

    // Sort by last_message_at
    return conversations.sort((a, b) => 
      new Date(b.last_message_at).getTime() - new Date(a.last_message_at).getTime()
    );
  },

  async getMessages(conversationId: string) {
    const { data } = await supabase
      .from('messages')
      .select('*, profiles:sender_id(*)')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true });
    return data || [];
  },

  async sendMessage(conversationId: string, senderId: string, content: string, mediaUrl?: string, mediaType?: string, fileName?: string) {
    const { data } = await supabase
      .from('messages')
      .insert({ 
        conversation_id: conversationId, 
        sender_id: senderId, 
        content, 
        media_url: mediaUrl, 
        media_type: mediaType,
        file_name: fileName
      })
      .select('*, profiles:sender_id(*)')
      .single();
    
    // Update last_message_at in conversation
    await supabase.from('conversations').update({ last_message_at: new Date().toISOString() }).eq('id', conversationId);
    
    return data;
  },

  async deleteConversation(conversationId: string, userId: string) {
    const { error } = await supabase
      .from('conversation_members')
      .update({ is_deleted: true })
      .eq('conversation_id', conversationId)
      .eq('profile_id', userId);
    
    if (error) throw error;
    return true;
  },

  async startConversation(userId: string, targetId: string) {
    // We'll use a transaction approach since we can't easily do it in one RPC without DDL
    // Check if conversation already exists by querying conversation_members for both users
    const { data: common } = await supabase.rpc('find_conversation', { 
      u1: userId, 
      u2: targetId 
    });

    if (common && common.length > 0) {
      // Re-enable if it was deleted
      await supabase.from('conversation_members').update({ is_deleted: false }).eq('conversation_id', common[0].id).eq('profile_id', userId);
      return common[0].id;
    }

    // Create new conversation
    const { data: conversation, error: convError } = await supabase
      .from('conversations')
      .insert({})
      .select()
      .single();
    
    if (convError) throw convError;

    // Add members
    await supabase.from('conversation_members').insert([
      { conversation_id: conversation.id, profile_id: userId },
      { conversation_id: conversation.id, profile_id: targetId }
    ]);

    return conversation.id;
  },

  // Albums
  async getAlbums(premiumOnly = false, limit = 20, offset = 0): Promise<Album[]> {
    console.log(`[API] Fetching albums - premiumOnly: ${premiumOnly}, limit: ${limit}, offset: ${offset}`);
    
    let query = supabase
      .from('albums')
      .select('*, profiles(*)')
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);
    
    if (premiumOnly) {
      query = query.eq('is_premium', true);
    }
    
    const { data, error } = await query;
    
    if (error) {
      console.error('[API ERROR] Failed to fetch albums:', error);
      return [];
    }

    console.log(`[API] ✓ Fetched ${data?.length || 0} albums`, {
      premiumOnly,
      albums: data?.map(a => ({
        id: a.id,
        title: a.title,
        is_premium: a.is_premium,
        media_count: a.media_items?.length || 0
      }))
    });

    return data || [];
  },

  async createAlbum(album: Omit<Album, 'id' | 'created_at' | 'updated_at' | 'user_id' | 'likes_count' | 'comments_count' | 'views_count'>) {
    console.log('[API] ═══════════════════════════════════════');
    console.log('[API] createAlbum() CALLED');
    console.log('[API] ═══════════════════════════════════════');
    
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      console.error('[API] ❌ Not authenticated');
      throw new Error('Not authenticated');
    }
    
    console.log('[API] User authenticated:', user.id);
    console.log('[API] Album data to insert:', {
      title: album.title,
      description: album.description,
      media_items_count: album.media_items?.length || 0,
      is_premium: album.is_premium,
      thumbnail_url: album.thumbnail_url,
      user_id: user.id
    });
    
    console.log('[API] Calling supabase.from("albums").insert()...');
    const { data, error } = await supabase.from('albums').insert({
      ...album,
      user_id: user.id
    }).select('*').single();

    console.log('[API] Insert completed');
    console.log('[API] Error:', error);
    console.log('[API] Data:', data);

    if (error) {
      console.error('[API] ═══════════════════════════════════════');
      console.error('[API] ❌ FAILED TO CREATE ALBUM');
      console.error('[API] ═══════════════════════════════════════');
      console.error('[API] Error code:', error.code);
      console.error('[API] Error message:', error.message);
      console.error('[API] Error details:', error.details);
      console.error('[API] Error hint:', error.hint);
      console.error('[API] ═══════════════════════════════════════');
      throw error;
    }

    if (!data) {
      console.error('[API] ═══════════════════════════════════════');
      console.error('[API] ❌ NO DATA RETURNED');
      console.error('[API] ═══════════════════════════════════════');
      throw new Error('No data returned from insert');
    }

    console.log('[API] ═══════════════════════════════════════');
    console.log('[API] ✓✓✓ ALBUM CREATED SUCCESSFULLY ✓✓✓');
    console.log('[API] ═══════════════════════════════════════');
    console.log('[API] Album ID:', data.id);
    console.log('[API] Album Title:', data.title);
    console.log('[API] Is Premium:', data.is_premium);
    console.log('[API] Media Count:', data.media_items?.length || 0);
    console.log('[API] Created At:', data.created_at);
    console.log('[API] ═══════════════════════════════════════');

    return { data, error: null };
  },

  async deleteAlbum(albumId: string) {
    return supabase.from('albums').delete().eq('id', albumId);
  },

  // Search
  async searchPosts(query: string, isPremium: boolean): Promise<Post[]> {
    if (!isPremium) {
      return []; // Only premium users can search
    }

    const { data } = await supabase
      .from('posts')
      .select('*, profiles(*)')
      .ilike('caption', `%${query}%`)
      .order('created_at', { ascending: false })
      .limit(50);
    
    return data || [];
  }

};
