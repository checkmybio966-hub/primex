export interface Option {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
  withCount?: boolean;
}

export type UserRole = 'user' | 'admin' | 'premium_user';
export type UserStatus = 'approved' | 'pending';
export type SubscriptionStatus = 'none' | 'payment_pending' | 'active' | 'rejected';
export type MediaType = 'image' | 'video';
export type PostType = 'post' | 'reel';

export interface Profile {
  id: string;
  username: string;
  email: string;
  profile_image: string | null;
  display_name: string | null;
  bio: string | null;
  role: UserRole;
  status: UserStatus;
  subscription_status: SubscriptionStatus;
  is_premium: boolean;
  created_at: string;
}

export interface MediaItem {
  url: string;
  type: MediaType;
  thumbnail_url?: string; // For video thumbnails
}

export interface Post {
  id: string;
  user_id: string;
  type: PostType;
  media_url: string;
  media_type: MediaType;
  media_items?: MediaItem[]; // Support for multiple media
  thumbnail_url?: string; // For video thumbnails
  caption: string | null;
  likes_count: number;
  comments_count: number;
  views_count: number;
  created_at: string;
  is_premium?: boolean;
  user_role?: UserRole;
  profiles?: Profile;
}

export interface FileItem {
  id: string;
  name: string;
  file_type: string;
  url: string;
  size: number;
  user_id: string;
  folder_id: string | null;
  created_at: string;
}

export interface Folder {
  id: string;
  name: string;
  user_id: string;
  created_at: string;
}

export interface Like {
  id: string;
  user_id: string;
  post_id: string;
  created_at: string;
}

export interface Comment {
  id: string;
  user_id: string;
  post_id: string;
  content: string;
  created_at: string;
  profiles?: Profile;
}

export interface Settings {
  id: number;
  premium_qr_url: string | null;
  payment_text: string | null;
  qr_updated_at?: string;
}

export interface Banner {
  id: string;
  media_url: string;
  media_type: MediaType;
  title: string | null;
  description: string | null;
  link_url: string | null;
  order_index: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export type NotificationType = 'banner' | 'reel' | 'album' | 'file' | 'post' | 'system';

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: NotificationType;
  reference_id: string | null;
  icon: string | null;
  is_read: boolean;
  created_at: string;
}

export interface UserNotification {
  id: string;
  user_id: string;
  notification_id: string;
  is_read: boolean;
  read_at: string | null;
  created_at: string;
  notifications?: Notification;
}

export interface Album {
  id: string;
  user_id: string;
  title: string | null;
  description: string | null;
  media_items: MediaItem[];
  thumbnail_url: string | null;
  is_premium: boolean;
  likes_count: number;
  comments_count: number;
  views_count: number;
  created_at: string;
  updated_at: string;
  profiles?: Profile;
}
