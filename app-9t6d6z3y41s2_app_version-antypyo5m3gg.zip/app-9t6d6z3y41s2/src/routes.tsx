import HomePage from './pages/HomePage';
import ReelsPage from './pages/ReelsPage';
import CreatePage from './pages/CreatePage';
import UploadPage from './pages/UploadPage';
import AlbumDetailPage from './pages/AlbumDetailPage';
import ProfilePage from './pages/ProfilePage';
import EditProfilePage from './pages/EditProfilePage';
import ChatPage from './pages/ChatPage';
import AdminPage from './pages/AdminPage';
import PremiumPage from './pages/PremiumPage';
import PremiumFeedPage from './pages/PremiumFeedPage';
import FilesPage from './pages/FilesPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import QRPaymentPage from './pages/QRPaymentPage';
import NotFound from './pages/NotFound';
import { Layout } from './components/layout/Layout';
import { ProtectedRoute } from './components/auth/ProtectedRoute';
import type { ReactNode } from 'react';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  children?: RouteConfig[];
}

const routes: RouteConfig[] = [
  {
    name: 'Layout',
    path: '/',
    element: <Layout />,
    children: [
      { name: 'Home', path: '/', element: <HomePage /> },
      { name: 'Reels', path: '/reels', element: <ReelsPage /> },
      { 
        name: 'Upload', 
        path: '/upload', 
        element: (
          <ProtectedRoute requireAdmin>
            <UploadPage />
          </ProtectedRoute>
        ) 
      },
      { 
        name: 'Album Detail', 
        path: '/album/:albumId', 
        element: (
          <ProtectedRoute requirePremium>
            <AlbumDetailPage />
          </ProtectedRoute>
        ) 
      },
      { 
        name: 'Premium Feed', 
        path: '/premium-feed', 
        element: (
          <ProtectedRoute requirePremium>
            <PremiumFeedPage />
          </ProtectedRoute>
        ) 
      },
      { 
        name: 'Files', 
        path: '/files', 
        element: (
          <ProtectedRoute requirePremium>
            <FilesPage />
          </ProtectedRoute>
        ) 
      },
      { name: 'Create', path: '/create', element: <CreatePage /> },
      { name: 'Profile', path: '/profile', element: <ProfilePage /> },
      { name: 'Edit Profile', path: '/edit-profile', element: <EditProfilePage /> },
      { name: 'Chat', path: '/chat', element: <ChatPage /> },
      { 
        name: 'Admin', 
        path: '/admin', 
        element: (
          <ProtectedRoute requireAdmin>
            <AdminPage />
          </ProtectedRoute>
        ) 
      },
    ]
  },
  { name: 'Login', path: '/login', element: <LoginPage /> },
  { name: 'Register', path: '/register', element: <RegisterPage /> },
  { name: 'Premium', path: '/premium', element: <PremiumPage /> },
  { name: 'QR Payment', path: '/qr-payment', element: <QRPaymentPage /> },
  { name: 'NotFound', path: '*', element: <NotFound /> },
];

export default routes;
