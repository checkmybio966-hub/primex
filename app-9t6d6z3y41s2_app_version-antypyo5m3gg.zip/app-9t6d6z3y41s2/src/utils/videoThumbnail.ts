/**
 * Video Thumbnail Generation Utility
 * Extracts first frame from video as thumbnail
 */

export interface ThumbnailResult {
  blob: Blob;
  dataUrl: string;
  width: number;
  height: number;
}

/**
 * Generate thumbnail from video file
 * @param videoFile - Video file to extract thumbnail from
 * @param seekTime - Time in seconds to capture frame (default: 0)
 * @param quality - JPEG quality 0-1 (default: 0.8)
 * @returns Promise with thumbnail blob and data URL
 */
export async function generateVideoThumbnail(
  videoFile: File,
  seekTime: number = 0,
  quality: number = 0.8
): Promise<ThumbnailResult> {
  return new Promise((resolve, reject) => {
    try {
      // Create video element
      const video = document.createElement('video');
      video.preload = 'metadata';
      video.muted = true;
      video.playsInline = true;

      // Create object URL for video
      const videoUrl = URL.createObjectURL(videoFile);
      video.src = videoUrl;

      // Wait for video metadata to load
      video.addEventListener('loadedmetadata', () => {
        // Seek to specified time
        video.currentTime = Math.min(seekTime, video.duration);
      });

      // Capture frame when seeked
      video.addEventListener('seeked', async () => {
        try {
          // Create canvas
          const canvas = document.createElement('canvas');
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;

          // Draw video frame to canvas
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            throw new Error('Failed to get canvas context');
          }

          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

          // Convert canvas to blob
          canvas.toBlob(
            (blob) => {
              if (!blob) {
                reject(new Error('Failed to create thumbnail blob'));
                return;
              }

              // Create data URL for preview
              const dataUrl = canvas.toDataURL('image/jpeg', quality);

              // Cleanup
              URL.revokeObjectURL(videoUrl);
              video.remove();

              resolve({
                blob,
                dataUrl,
                width: canvas.width,
                height: canvas.height
              });
            },
            'image/jpeg',
            quality
          );
        } catch (error) {
          URL.revokeObjectURL(videoUrl);
          video.remove();
          reject(error);
        }
      });

      // Error handling
      video.addEventListener('error', (e) => {
        URL.revokeObjectURL(videoUrl);
        video.remove();
        reject(new Error(`Video loading error: ${e}`));
      });

      // Start loading
      video.load();
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * Generate multiple thumbnails from video at different timestamps
 * @param videoFile - Video file
 * @param count - Number of thumbnails to generate
 * @param quality - JPEG quality
 * @returns Array of thumbnail results
 */
export async function generateMultipleThumbnails(
  videoFile: File,
  count: number = 3,
  quality: number = 0.8
): Promise<ThumbnailResult[]> {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.muted = true;
    video.playsInline = true;

    const videoUrl = URL.createObjectURL(videoFile);
    video.src = videoUrl;

    const thumbnails: ThumbnailResult[] = [];
    let currentIndex = 0;

    video.addEventListener('loadedmetadata', () => {
      const duration = video.duration;
      const interval = duration / (count + 1);

      const captureNext = () => {
        if (currentIndex >= count) {
          URL.revokeObjectURL(videoUrl);
          video.remove();
          resolve(thumbnails);
          return;
        }

        video.currentTime = interval * (currentIndex + 1);
      };

      video.addEventListener('seeked', () => {
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Failed to get canvas context'));
          return;
        }

        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        canvas.toBlob(
          (blob) => {
            if (!blob) {
              reject(new Error('Failed to create thumbnail blob'));
              return;
            }

            const dataUrl = canvas.toDataURL('image/jpeg', quality);

            thumbnails.push({
              blob,
              dataUrl,
              width: canvas.width,
              height: canvas.height
            });

            currentIndex++;
            captureNext();
          },
          'image/jpeg',
          quality
        );
      });

      captureNext();
    });

    video.addEventListener('error', (e) => {
      URL.revokeObjectURL(videoUrl);
      video.remove();
      reject(new Error(`Video loading error: ${e}`));
    });

    video.load();
  });
}

/**
 * Create File object from Blob
 * @param blob - Thumbnail blob
 * @param fileName - Name for the file
 * @returns File object
 */
export function blobToFile(blob: Blob, fileName: string): File {
  return new File([blob], fileName, { type: 'image/jpeg' });
}
