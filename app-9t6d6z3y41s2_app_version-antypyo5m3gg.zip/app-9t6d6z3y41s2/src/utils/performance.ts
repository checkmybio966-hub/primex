/**
 * Performance Monitoring Utility
 * Helps track and optimize app performance for 120fps
 */

export class PerformanceMonitor {
  private static instance: PerformanceMonitor;
  private frameCount = 0;
  private lastTime = performance.now();
  private fps = 0;

  private constructor() {
    this.startMonitoring();
  }

  public static getInstance(): PerformanceMonitor {
    if (!PerformanceMonitor.instance) {
      PerformanceMonitor.instance = new PerformanceMonitor();
    }
    return PerformanceMonitor.instance;
  }

  private startMonitoring() {
    const measureFPS = () => {
      this.frameCount++;
      const currentTime = performance.now();
      const elapsed = currentTime - this.lastTime;

      if (elapsed >= 1000) {
        this.fps = Math.round((this.frameCount * 1000) / elapsed);
        this.frameCount = 0;
        this.lastTime = currentTime;

        // Log if FPS drops below 60
        if (this.fps < 60) {
          console.warn(`⚠️ Low FPS detected: ${this.fps}fps`);
        }
      }

      requestAnimationFrame(measureFPS);
    };

    requestAnimationFrame(measureFPS);
  }

  public getFPS(): number {
    return this.fps;
  }

  public static optimizeElement(element: HTMLElement) {
    element.style.transform = 'translateZ(0)';
    element.style.willChange = 'transform';
    element.style.backfaceVisibility = 'hidden';
  }

  public static enableHardwareAcceleration() {
    // Enable hardware acceleration globally
    document.body.style.transform = 'translateZ(0)';
    document.body.style.backfaceVisibility = 'hidden';
    
    // Optimize scrolling
    const bodyStyle = document.body.style as CSSStyleDeclaration & { webkitOverflowScrolling?: string };
    bodyStyle.webkitOverflowScrolling = 'touch';
    
    console.log('✅ Hardware acceleration enabled');
  }

  public static debounce<T extends (...args: unknown[]) => void>(
    func: T,
    wait: number
  ): (...args: Parameters<T>) => void {
    let timeout: ReturnType<typeof setTimeout>;
    return (...args: Parameters<T>) => {
      clearTimeout(timeout);
      timeout = setTimeout(() => func(...args), wait);
    };
  }

  public static throttle<T extends (...args: unknown[]) => void>(
    func: T,
    limit: number
  ): (...args: Parameters<T>) => void {
    let inThrottle: boolean;
    return (...args: Parameters<T>) => {
      if (!inThrottle) {
        func(...args);
        inThrottle = true;
        setTimeout(() => (inThrottle = false), limit);
      }
    };
  }

  public static requestIdleCallback(callback: () => void) {
    if ('requestIdleCallback' in window) {
      window.requestIdleCallback(callback);
    } else {
      setTimeout(callback, 1);
    }
  }
}

// Initialize performance monitoring
if (typeof window !== 'undefined') {
  PerformanceMonitor.getInstance();
  PerformanceMonitor.enableHardwareAcceleration();
}
