ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_premium BOOLEAN DEFAULT FALSE;

-- Update existing premium users if any
UPDATE public.profiles SET is_premium = TRUE WHERE role = 'premium_user';
