-- Create albums table
CREATE TABLE IF NOT EXISTS albums (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text,
  description text,
  media_items jsonb NOT NULL DEFAULT '[]'::jsonb,
  thumbnail_url text,
  is_premium boolean DEFAULT false,
  likes_count integer DEFAULT 0,
  comments_count integer DEFAULT 0,
  views_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add RLS policies for albums
ALTER TABLE albums ENABLE ROW LEVEL SECURITY;

-- Anyone can view non-premium albums
CREATE POLICY "Anyone can view non-premium albums"
  ON albums FOR SELECT
  USING (NOT is_premium OR is_premium = false);

-- Premium users and admins can view premium albums
CREATE POLICY "Premium users can view premium albums"
  ON albums FOR SELECT
  USING (
    is_premium = true AND (
      auth.uid() IN (
        SELECT id FROM profiles 
        WHERE role IN ('admin', 'premium_user')
      )
    )
  );

-- Admins can insert albums
CREATE POLICY "Admins can insert albums"
  ON albums FOR INSERT
  WITH CHECK (
    auth.uid() IN (
      SELECT id FROM profiles WHERE role = 'admin'
    )
  );

-- Admins can update albums
CREATE POLICY "Admins can update albums"
  ON albums FOR UPDATE
  USING (
    auth.uid() IN (
      SELECT id FROM profiles WHERE role = 'admin'
    )
  );

-- Admins can delete albums
CREATE POLICY "Admins can delete albums"
  ON albums FOR DELETE
  USING (
    auth.uid() IN (
      SELECT id FROM profiles WHERE role = 'admin'
    )
  );

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_albums_user_id ON albums(user_id);
CREATE INDEX IF NOT EXISTS idx_albums_is_premium ON albums(is_premium);
CREATE INDEX IF NOT EXISTS idx_albums_created_at ON albums(created_at DESC);