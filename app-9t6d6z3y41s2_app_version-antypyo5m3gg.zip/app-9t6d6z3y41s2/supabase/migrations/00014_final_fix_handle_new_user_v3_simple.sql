-- Re-create the function one last time with very simple logic
CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  u_name text;
BEGIN
  -- Prefer metadata, fallback to email local part
  u_name := COALESCE(NEW.raw_user_meta_data->>'username', SPLIT_PART(NEW.email, '@', 1));
  
  INSERT INTO public.profiles (id, username, email, role, status)
  VALUES (
    NEW.id,
    u_name,
    NEW.email,
    -- Case-insensitive check for admin
    CASE 
      WHEN LOWER(u_name) = 'admin' THEN 'admin'::public.user_role 
      ELSE 'user'::public.user_role 
    END,
    'approved'::public.user_status
  )
  ON CONFLICT (id) DO UPDATE SET 
    username = EXCLUDED.username,
    email = EXCLUDED.email,
    role = EXCLUDED.role;

  RETURN NEW;
END;
$function$;
