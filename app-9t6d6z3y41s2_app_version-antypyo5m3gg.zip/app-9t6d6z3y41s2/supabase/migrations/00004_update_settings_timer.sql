ALTER TABLE public.settings ADD COLUMN IF NOT EXISTS qr_updated_at TIMESTAMPTZ DEFAULT NOW();

CREATE OR REPLACE FUNCTION public.update_qr_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.qr_updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS on_settings_update ON public.settings;
CREATE TRIGGER on_settings_update
  BEFORE UPDATE ON public.settings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_qr_updated_at();
