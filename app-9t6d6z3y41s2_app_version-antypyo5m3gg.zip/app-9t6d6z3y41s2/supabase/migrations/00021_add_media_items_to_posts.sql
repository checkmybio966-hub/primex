-- Add media_items column to support multiple media per post
ALTER TABLE posts ADD COLUMN IF NOT EXISTS media_items JSONB DEFAULT '[]'::jsonb;

-- Add index for better query performance
CREATE INDEX IF NOT EXISTS idx_posts_media_items ON posts USING GIN (media_items);

-- Update existing posts to have media_items array with single item
UPDATE posts 
SET media_items = jsonb_build_array(
  jsonb_build_object(
    'url', media_url,
    'type', media_type
  )
)
WHERE media_items = '[]'::jsonb OR media_items IS NULL;
