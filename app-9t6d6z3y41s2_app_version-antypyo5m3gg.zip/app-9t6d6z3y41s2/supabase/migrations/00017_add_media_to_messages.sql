ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS media_url TEXT;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS media_type TEXT; -- 'image', 'video', 'file'
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS file_name TEXT;
