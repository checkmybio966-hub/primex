ALTER TABLE public.profiles 
ADD COLUMN bio TEXT,
ADD COLUMN display_name TEXT;
