CREATE OR REPLACE FUNCTION public.find_conversation(u1 UUID, u2 UUID)
RETURNS TABLE (id UUID) AS $$
BEGIN
  RETURN QUERY
  SELECT cm1.conversation_id
  FROM public.conversation_members cm1
  JOIN public.conversation_members cm2 ON cm1.conversation_id = cm2.conversation_id
  WHERE cm1.profile_id = u1 AND cm2.profile_id = u2;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
