-- Create banners table
CREATE TABLE IF NOT EXISTS banners (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  media_url TEXT NOT NULL,
  media_type TEXT NOT NULL CHECK (media_type IN ('image', 'video')),
  title TEXT,
  description TEXT,
  link_url TEXT,
  order_index INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('banner', 'reel', 'album', 'file', 'post', 'system')),
  reference_id UUID,
  icon TEXT,
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create user_notifications junction table for tracking read status per user
CREATE TABLE IF NOT EXISTS user_notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  notification_id UUID NOT NULL REFERENCES notifications(id) ON DELETE CASCADE,
  is_read BOOLEAN DEFAULT false,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, notification_id)
);

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_banners_active ON banners(is_active, order_index);
CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_user_notifications_user ON user_notifications(user_id, is_read);

-- Enable RLS
ALTER TABLE banners ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_notifications ENABLE ROW LEVEL SECURITY;

-- Banners policies (public read, admin write)
CREATE POLICY "Anyone can view active banners" ON banners
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage banners" ON banners
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

-- Notifications policies (public read)
CREATE POLICY "Anyone can view notifications" ON notifications
  FOR SELECT USING (true);

CREATE POLICY "Admins can create notifications" ON notifications
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

-- User notifications policies
CREATE POLICY "Users can view their notifications" ON user_notifications
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update their notifications" ON user_notifications
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "System can create user notifications" ON user_notifications
  FOR INSERT WITH CHECK (true);

-- Function to create notification for all users
CREATE OR REPLACE FUNCTION create_notification_for_all_users(
  p_title TEXT,
  p_message TEXT,
  p_type TEXT,
  p_reference_id UUID DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
  v_notification_id UUID;
BEGIN
  -- Create the notification
  INSERT INTO notifications (title, message, type, reference_id)
  VALUES (p_title, p_message, p_type, p_reference_id)
  RETURNING id INTO v_notification_id;
  
  -- Create user_notification entries for all users
  INSERT INTO user_notifications (user_id, notification_id)
  SELECT id, v_notification_id FROM auth.users;
  
  RETURN v_notification_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to send notification when admin uploads content
CREATE OR REPLACE FUNCTION notify_new_content()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_TABLE_NAME = 'banners' THEN
    PERFORM create_notification_for_all_users(
      'New Banner Added',
      'Admin uploaded a new banner to the home page',
      'banner',
      NEW.id
    );
  ELSIF TG_TABLE_NAME = 'posts' AND NEW.type = 'reel' THEN
    PERFORM create_notification_for_all_users(
      'New Reel Available',
      'Admin posted a new reel',
      'reel',
      NEW.id
    );
  ELSIF TG_TABLE_NAME = 'files' THEN
    PERFORM create_notification_for_all_users(
      'New File Uploaded',
      'Admin uploaded new content to files',
      'file',
      NEW.id
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers
DROP TRIGGER IF EXISTS trigger_notify_banner ON banners;
CREATE TRIGGER trigger_notify_banner
  AFTER INSERT ON banners
  FOR EACH ROW
  EXECUTE FUNCTION notify_new_content();

DROP TRIGGER IF EXISTS trigger_notify_reel ON posts;
CREATE TRIGGER trigger_notify_reel
  AFTER INSERT ON posts
  FOR EACH ROW
  WHEN (NEW.type = 'reel')
  EXECUTE FUNCTION notify_new_content();

DROP TRIGGER IF EXISTS trigger_notify_file ON files;
CREATE TRIGGER trigger_notify_file
  AFTER INSERT ON files
  FOR EACH ROW
  EXECUTE FUNCTION notify_new_content();
