ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS user_role public.user_role;

-- Update existing posts if any
UPDATE public.posts p
SET user_role = pr.role
FROM public.profiles pr
WHERE p.user_id = pr.id;
