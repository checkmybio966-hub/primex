CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
  username_val text;
BEGIN
  SELECT COUNT(*) INTO user_count FROM public.profiles;
  -- Try to get username from metadata, or fallback to email part
  username_val := COALESCE(NEW.raw_user_meta_data->>'username', SPLIT_PART(NEW.email, '@', 1));
  
  INSERT INTO public.profiles (id, username, email, role, status)
  VALUES (
    NEW.id,
    username_val,
    NEW.email,
    CASE WHEN user_count = 0 THEN 'admin'::public.user_role ELSE 'user'::public.user_role END,
    'approved'::public.user_status -- Updated to approved by default as per new requirement
  );
  RETURN NEW;
END;
$$;
