-- Re-create the function with better logging or at least simplified logic
CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  u_name text;
BEGIN
  -- Always prefer username from metadata
  u_name := COALESCE(NEW.raw_user_meta_data->>'username', SPLIT_PART(NEW.email, '@', 1));
  
  -- If it starts with px_, remove it for the username in profiles if we used it in email
  IF u_name LIKE 'px_%' THEN
     u_name := SUBSTRING(u_name FROM 4);
  END IF;

  INSERT INTO public.profiles (id, username, email, role, status)
  VALUES (
    NEW.id,
    u_name,
    NEW.email,
    -- Case-insensitive check for admin
    CASE 
      WHEN LOWER(u_name) = 'admin' THEN 'admin'::public.user_role 
      ELSE 'user'::public.user_role 
    END,
    'approved'::public.user_status
  )
  ON CONFLICT (id) DO UPDATE SET 
    username = EXCLUDED.username,
    email = EXCLUDED.email,
    role = EXCLUDED.role;

  RETURN NEW;
END;
$function$;
