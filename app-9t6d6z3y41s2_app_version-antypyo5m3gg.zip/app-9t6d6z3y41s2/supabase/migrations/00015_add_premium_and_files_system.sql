-- Add is_premium to posts
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS is_premium BOOLEAN DEFAULT FALSE;

-- Create files table
CREATE TABLE IF NOT EXISTS public.files (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  file_type TEXT NOT NULL, -- image, video, document
  url TEXT NOT NULL,
  size BIGINT,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Enable RLS on files
ALTER TABLE public.files ENABLE ROW LEVEL SECURITY;

-- Policy: Admin can do everything on files
CREATE POLICY "Admin can manage files" ON public.files
FOR ALL TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  )
);

-- Policy: Premium users and Admins can read files
CREATE POLICY "Premium users can read files" ON public.files
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE profiles.id = auth.uid() AND (profiles.role = 'premium_user' OR profiles.role = 'admin')
  )
);

-- Policy for Storage: Only premium/admin can read from premium_files bucket
-- First create the bucket if it doesn't exist via SQL (though UI/API is preferred)
INSERT INTO storage.buckets (id, name, public) VALUES ('premium_files', 'premium_files', false) ON CONFLICT (id) DO NOTHING;

-- Storage policies for the bucket
CREATE POLICY "Authenticated users can access premium_files if premium" ON storage.objects
FOR SELECT TO authenticated
USING (
  bucket_id = 'premium_files' AND
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE profiles.id = auth.uid() AND (profiles.role = 'premium_user' OR profiles.role = 'admin')
  )
);

CREATE POLICY "Admin can upload to premium_files" ON storage.objects
FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'premium_files' AND
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  )
);

CREATE POLICY "Admin can delete from premium_files" ON storage.objects
FOR DELETE TO authenticated
USING (
  bucket_id = 'premium_files' AND
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  )
);
