UPDATE auth.users 
SET encrypted_password = crypt('password', gen_salt('bf')) 
WHERE email = 'admin@primex-social-final.com';
