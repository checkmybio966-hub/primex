-- Reset password for the primary admin account to admin123
UPDATE auth.users 
SET encrypted_password = crypt('admin123', gen_salt('bf')) 
WHERE email = 'admin@primex-social-final.com';

-- Ensure the profile is correctly set up as admin with premium access
UPDATE public.profiles
SET 
    role = 'admin',
    status = 'approved',
    is_premium = true,
    subscription_status = 'active'
WHERE email = 'admin@primex-social-final.com';
