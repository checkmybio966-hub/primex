# Primex Design System

## 🎨 Overview
A comprehensive, professional design system for the Primex social platform with consistent typography, spacing, components, and interactions.

---

## 📐 Typography Scale

### Font Family
- **Primary**: Inter (Google Fonts)
- **Fallback**: System fonts (-apple-system, BlinkMacSystemFont, Segoe UI, Roboto)

### Type Scale
```css
--text-heading: 1.375rem (22px)      /* Headings (h1, h2, h3) */
--text-subheading: 1.125rem (18px)   /* Subheadings (h4, h5) */
--text-body: 0.9375rem (15px)        /* Body text, paragraphs */
--text-small: 0.8125rem (13px)       /* Small text, captions */
--text-xs: 0.6875rem (11px)          /* Extra small, labels */
```

### Font Weights
- **Regular**: 400 (body text)
- **Medium**: 500 (emphasis)
- **Semibold**: 600 (subheadings)
- **Bold**: 700 (headings)
- **Extrabold**: 800 (special emphasis)
- **Black**: 900 (display text)

### Line Heights
- **Headings**: 1.3 (tight)
- **Subheadings**: 1.4
- **Body**: 1.6 (comfortable reading)
- **Small**: 1.5
- **Extra Small**: 1.4

### Usage Classes
```tsx
<h1 className="text-heading">Main Heading</h1>
<h4 className="text-subheading">Section Title</h4>
<p className="text-body">Body content goes here</p>
<span className="text-small">Caption text</span>
<small className="text-xs">Metadata</small>
```

---

## 📏 Spacing System

### Fixed Spacing Scale
```css
--spacing-xs: 0.5rem (8px)    /* Tight spacing */
--spacing-sm: 0.75rem (12px)  /* Small spacing */
--spacing-md: 1rem (16px)     /* Medium spacing (default) */
--spacing-lg: 1.5rem (24px)   /* Large spacing */
--spacing-xl: 2rem (32px)     /* Extra large spacing */
```

### Tailwind Equivalents
- `gap-2` = 8px (xs)
- `gap-3` = 12px (sm)
- `gap-4` = 16px (md)
- `gap-6` = 24px (lg)
- `gap-8` = 32px (xl)

### Usage Guidelines
- **Card padding**: 16px (p-4)
- **Section margins**: 24px (mb-6)
- **Element gaps**: 12px-16px (gap-3 to gap-4)
- **Icon spacing**: 8px (gap-2)

---

## 🔘 Button System

### Standard Button
```css
--button-height: 3rem (48px)
border-radius: 0.75rem (12px)
padding: 0 1.5rem (24px horizontal)
font-weight: 600 (semibold)
font-size: var(--text-body)
```

### Button Variants
```tsx
<Button variant="default">Primary Action</Button>
<Button variant="secondary">Secondary Action</Button>
<Button variant="outline">Outlined Button</Button>
<Button variant="destructive">Delete</Button>
<Button variant="ghost">Subtle Action</Button>
<Button variant="link">Link Button</Button>
```

### Button Sizes
```tsx
<Button size="sm">Small (40px)</Button>
<Button size="default">Default (48px)</Button>
<Button size="lg">Large (56px)</Button>
<Button size="icon">Icon Only (48x48px)</Button>
```

### Button States
- **Default**: Full opacity, primary color
- **Hover**: 90% opacity, slight scale
- **Active**: 95% scale (pressed effect)
- **Disabled**: 50% opacity, no pointer events
- **Focus**: 2px ring, ring-offset-2

---

## 📝 Input System

### Standard Input
```css
height: 3rem (48px)
border-radius: 0.75rem (12px)
border: 2px solid
padding: 0.75rem 1rem (12px 16px)
font-size: var(--text-body)
font-weight: 500 (medium)
```

### Input States
- **Default**: Border color `border-input`
- **Focus**: Border `primary`, ring-2
- **Error**: Border `destructive`
- **Disabled**: 50% opacity

### Textarea
```css
min-height: 120px
border-radius: 0.75rem (12px)
padding: 0.75rem 1rem
resize: none (fixed height)
```

---

## 🃏 Card System

### Standard Card
```css
border-radius: 1rem (16px)
border: 2px solid
padding: 1rem (16px)
box-shadow: 0 2px 8px rgba(0,0,0,0.3)
```

### Card Components
```tsx
<Card>
  <CardHeader>
    <CardTitle>Title</CardTitle>
    <CardDescription>Description</CardDescription>
  </CardHeader>
  <CardContent>
    Main content
  </CardContent>
  <CardFooter>
    Footer actions
  </CardFooter>
</Card>
```

### Card Padding
- **Header**: 16px (p-4)
- **Content**: 16px horizontal, 0 top (p-4 pt-0)
- **Footer**: 16px horizontal, 0 top (p-4 pt-0)

---

## 🎯 Icon System

### Standard Icon Size
```css
--icon-size: 1.5rem (24px)
```

### Icon Sizes by Context
- **Navigation**: 24px (w-6 h-6)
- **Buttons**: 20px (w-5 h-5)
- **Small actions**: 16px (w-4 h-4)
- **Large display**: 32px (w-8 h-8)

### Icon Spacing
- **With text**: 8px gap (gap-2)
- **Icon-only buttons**: Centered, 48x48px container

---

## 🎨 Color System

### Primary Colors
```css
--primary: hsl(217 91% 60%)           /* Blue accent */
--primary-foreground: hsl(222 47% 11%) /* Dark text on primary */
```

### Semantic Colors
```css
--background: hsl(222 47% 11%)        /* Dark background */
--foreground: hsl(210 40% 98%)        /* Light text */
--card: hsl(222 47% 11%)              /* Card background */
--border: hsl(217 33% 17%)            /* Border color */
--muted: hsl(223 47% 11%)             /* Muted background */
--muted-foreground: hsl(215 20% 65%)  /* Muted text */
--destructive: hsl(0 63% 31%)         /* Error/delete */
```

### Usage Guidelines
- **Backgrounds**: Use `bg-background`, `bg-card`
- **Text**: Use `text-foreground`, `text-muted-foreground`
- **Borders**: Use `border-border`
- **Accents**: Use `bg-primary`, `text-primary`
- **Errors**: Use `bg-destructive`, `text-destructive`

---

## 📐 Border Radius

### Standard Radii
```css
--radius-sm: 0.5rem (8px)    /* Small elements */
--radius-md: 0.75rem (12px)  /* Buttons, inputs */
--radius-lg: 1rem (16px)     /* Cards */
--radius-xl: 1.5rem (24px)   /* Large containers */
```

### Usage
- **Buttons**: 12px (rounded-xl)
- **Inputs**: 12px (rounded-xl)
- **Cards**: 16px (rounded-2xl)
- **Media**: 12px (rounded-xl)
- **Avatars**: 50% (rounded-full)

---

## 🎭 Component Sizes

### Avatar Sizes
```css
--avatar-sm: 2rem (32px)
--avatar-md: 2.5rem (40px)
--avatar-lg: 3rem (48px)
```

### Usage
```tsx
<Avatar className="w-8 h-8">Small</Avatar>
<Avatar className="w-10 h-10">Medium</Avatar>
<Avatar className="w-12 h-12">Large</Avatar>
```

---

## 🌊 Shadows

### Shadow Scale
```css
.shadow-card {
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
}

.shadow-hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
}
```

### Usage
- **Cards**: `shadow-card`
- **Hover states**: `shadow-hover`
- **Elevated elements**: `shadow-lg`

---

## ⚡ Transitions

### Standard Transitions
```css
transition: all 0.2s ease;
```

### Specific Transitions
- **Colors**: `transition-colors duration-200`
- **Transform**: `transition-transform duration-200`
- **All properties**: `transition-all duration-200`

### Hover Effects
```tsx
<button className="hover:scale-105 transition-transform">
  Hover me
</button>
```

---

## 📱 Responsive Breakpoints

### Tailwind Breakpoints
```css
sm: 640px   /* Small devices */
md: 768px   /* Tablets */
lg: 1024px  /* Laptops */
xl: 1280px  /* Desktops */
2xl: 1536px /* Large screens */
```

### Usage
```tsx
<div className="text-sm md:text-base lg:text-lg">
  Responsive text
</div>
```

---

## 🎯 Layout Guidelines

### Container Widths
- **Feed**: `max-w-xl` (576px)
- **Content**: `max-w-2xl` (672px)
- **Wide**: `max-w-4xl` (896px)
- **Full**: `max-w-7xl` (1280px)

### Padding
- **Mobile**: `px-4` (16px)
- **Desktop**: `px-6` (24px)

### Vertical Spacing
- **Section gaps**: `space-y-4` (16px)
- **Large gaps**: `space-y-6` (24px)
- **Page padding**: `py-4` (16px top/bottom)

---

## 🔤 Text Utilities

### Font Weights
```tsx
<p className="font-normal">Regular (400)</p>
<p className="font-medium">Medium (500)</p>
<p className="font-semibold">Semibold (600)</p>
<p className="font-bold">Bold (700)</p>
<p className="font-extrabold">Extrabold (800)</p>
<p className="font-black">Black (900)</p>
```

### Text Alignment
```tsx
<p className="text-left">Left aligned</p>
<p className="text-center">Center aligned</p>
<p className="text-right">Right aligned</p>
```

### Text Truncation
```tsx
<p className="truncate">Single line truncate...</p>
<p className="line-clamp-2">Two line truncate...</p>
<p className="line-clamp-3">Three line truncate...</p>
```

---

## 🎨 Utility Classes

### Custom Utilities
```css
.gradient-text          /* Gradient text effect */
.gradient-background    /* Gradient background */
.gradient-primary       /* Primary gradient */
.glass                  /* Glassmorphism effect */
.btn-standard          /* Standard button styling */
.btn-icon              /* Icon button styling */
.icon-standard         /* Standard icon size */
.card-standard         /* Standard card styling */
```

---

## ✅ Best Practices

### Typography
- ✅ Use semantic heading levels (h1-h6)
- ✅ Maintain consistent line heights
- ✅ Use font weights purposefully
- ❌ Don't use too many font sizes
- ❌ Avoid mixing font families

### Spacing
- ✅ Use spacing scale consistently
- ✅ Align elements to grid
- ✅ Maintain visual hierarchy
- ❌ Don't use random pixel values
- ❌ Avoid inconsistent gaps

### Colors
- ✅ Use semantic color tokens
- ✅ Maintain sufficient contrast (WCAG AA)
- ✅ Limit color palette
- ❌ Don't use direct color values
- ❌ Avoid too many accent colors

### Components
- ✅ Use standard component sizes
- ✅ Maintain consistent border radius
- ✅ Apply proper shadows
- ❌ Don't create custom variants unnecessarily
- ❌ Avoid mixing design patterns

---

## 📦 Component Examples

### Button Examples
```tsx
// Primary action
<Button>Submit</Button>

// Secondary action
<Button variant="secondary">Cancel</Button>

// Icon button
<Button size="icon" variant="ghost">
  <Heart className="w-5 h-5" />
</Button>

// Small button
<Button size="sm">Small Action</Button>
```

### Input Examples
```tsx
// Standard input
<Input placeholder="Enter username" />

// With label
<div className="space-y-2">
  <Label>Username</Label>
  <Input placeholder="Enter username" />
</div>

// Textarea
<Textarea placeholder="Write a caption..." />
```

### Card Examples
```tsx
<Card>
  <CardHeader>
    <CardTitle>Post Title</CardTitle>
    <CardDescription>Posted 2 hours ago</CardDescription>
  </CardHeader>
  <CardContent>
    <p>Post content goes here</p>
  </CardContent>
  <CardFooter>
    <Button>Like</Button>
    <Button variant="ghost">Comment</Button>
  </CardFooter>
</Card>
```

---

## 🚀 Implementation Checklist

- ✅ Typography scale defined
- ✅ Spacing system implemented
- ✅ Button variants standardized
- ✅ Input components consistent
- ✅ Card system unified
- ✅ Icon sizes standardized
- ✅ Color tokens defined
- ✅ Border radius consistent
- ✅ Shadows applied
- ✅ Transitions smooth
- ✅ Responsive breakpoints
- ✅ Utility classes created

---

**Design System Version**: 2.0.0  
**Last Updated**: 2026-03-29  
**Status**: Production Ready
